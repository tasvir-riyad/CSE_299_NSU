-- Migration: Scheduler Overhaul
-- Description: Allow course_sections to have nullable scheduling columns, and add preferred timing/rooms to faculty preferences

-- 1. Make scheduling columns nullable in course_sections
ALTER TABLE course_sections 
ALTER COLUMN day_of_week DROP NOT NULL,
ALTER COLUMN start_time DROP NOT NULL,
ALTER COLUMN end_time DROP NOT NULL;

-- 2. Add preference choice columns to faculty_course_preferences
ALTER TABLE faculty_course_preferences
ADD COLUMN IF NOT EXISTS preferred_day_of_week INT[],
ADD COLUMN IF NOT EXISTS preferred_start_time TIME,
ADD COLUMN IF NOT EXISTS preferred_end_time TIME,
ADD COLUMN IF NOT EXISTS preferred_room_id UUID REFERENCES classrooms(room_id) ON DELETE SET NULL;
