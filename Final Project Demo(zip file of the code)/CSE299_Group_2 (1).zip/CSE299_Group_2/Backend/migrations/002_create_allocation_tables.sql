-- Migration: Add Bulk Semester Allocation Tables
-- Description: Create tables for courses, sections, and semester allocations

-- 1. Courses table
CREATE TABLE IF NOT EXISTS courses (
  course_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_code VARCHAR(20) NOT NULL UNIQUE,
  course_name VARCHAR(255) NOT NULL,
  dept_id UUID NOT NULL REFERENCES departments(dept_id),
  credits INT DEFAULT 3,
  course_level INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Course Sections table
CREATE TABLE IF NOT EXISTS course_sections (
  section_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID NOT NULL REFERENCES courses(course_id) ON DELETE CASCADE,
  semester VARCHAR(20) NOT NULL,
  section_number VARCHAR(10) NOT NULL,
  enrollment_size INT NOT NULL,
  day_of_week INT[],
  start_time TIME,
  end_time TIME,
  facility_type VARCHAR(50) DEFAULT 'Any',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(course_id, semester, section_number)
);

-- 3. Allocation Batch
CREATE TABLE IF NOT EXISTS allocation_batches (
  batch_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  semester VARCHAR(20) NOT NULL,
  created_by UUID NOT NULL REFERENCES faculty(faculty_id),
  status VARCHAR(50) DEFAULT 'Draft',
  total_sections INT DEFAULT 0,
  successfully_allocated INT DEFAULT 0,
  failed_allocations INT DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Semester Allocations
CREATE TABLE IF NOT EXISTS semester_allocations (
  allocation_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id UUID NOT NULL REFERENCES allocation_batches(batch_id) ON DELETE CASCADE,
  section_id UUID NOT NULL REFERENCES course_sections(section_id),
  room_id UUID NOT NULL REFERENCES classrooms(room_id),
  allocated_day_of_week INT,
  allocated_start_time TIME,
  allocated_end_time TIME,
  status VARCHAR(50) DEFAULT 'Allocated',
  allocation_reason TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Allocation Conflicts
CREATE TABLE IF NOT EXISTS allocation_conflicts (
  conflict_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id UUID NOT NULL REFERENCES allocation_batches(batch_id) ON DELETE CASCADE,
  section_id UUID NOT NULL REFERENCES course_sections(section_id),
  conflict_type VARCHAR(50),
  description TEXT,
  suggested_solutions TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_course_sections_semester ON course_sections(semester);
CREATE INDEX IF NOT EXISTS idx_semester_allocations_batch_id ON semester_allocations(batch_id);
CREATE INDEX IF NOT EXISTS idx_allocation_batches_semester ON allocation_batches(semester);

