-- Migration: Choices and Assignments
-- Description: Add assigned_faculty_id to course_sections and create faculty_course_preferences table

-- 1. Alter course_sections to add assigned_faculty_id
ALTER TABLE course_sections 
ADD COLUMN IF NOT EXISTS assigned_faculty_id UUID REFERENCES faculty(faculty_id) ON DELETE SET NULL;

-- 2. Create faculty_course_preferences table
CREATE TABLE IF NOT EXISTS faculty_course_preferences (
  preference_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  faculty_id UUID NOT NULL REFERENCES faculty(faculty_id) ON DELETE CASCADE,
  section_id UUID NOT NULL REFERENCES course_sections(section_id) ON DELETE CASCADE,
  choice_rank INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(faculty_id, section_id),
  UNIQUE(faculty_id, choice_rank)
);

-- 3. Alter semester_allocations to add allocated_faculty_id
ALTER TABLE semester_allocations 
ADD COLUMN IF NOT EXISTS allocated_faculty_id UUID REFERENCES faculty(faculty_id) ON DELETE SET NULL;
