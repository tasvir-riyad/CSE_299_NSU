const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

async function seedData() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // 1. Ensure a campus exists
    const campusRes = await client.query(`
      INSERT INTO campuses (campus_name, geographic_scope) 
      VALUES ('Main Campus', 'Local') 
      ON CONFLICT DO NOTHING 
      RETURNING campus_id;
    `);
    
    let campusId;
    if (campusRes.rows.length > 0) {
      campusId = campusRes.rows[0].campus_id;
    } else {
      const existingCampus = await client.query('SELECT campus_id FROM campuses LIMIT 1;');
      campusId = existingCampus.rows[0].campus_id;
    }

    // 2. Ensure buildings exist
    const b1Res = await client.query(`
      INSERT INTO buildings (campus_id, building_code, building_name) 
      VALUES ($1, 'NAC', 'North Academic Center') 
      ON CONFLICT (building_code) DO NOTHING
      RETURNING building_id;
    `, [campusId]);
    
    let b1Id = b1Res.rows.length > 0 ? b1Res.rows[0].building_id : (await client.query("SELECT building_id FROM buildings WHERE building_code = 'NAC'")).rows[0].building_id;

    const b2Res = await client.query(`
      INSERT INTO buildings (campus_id, building_code, building_name) 
      VALUES ($1, 'SAC', 'South Academic Center') 
      ON CONFLICT (building_code) DO NOTHING
      RETURNING building_id;
    `, [campusId]);
    let b2Id = b2Res.rows.length > 0 ? b2Res.rows[0].building_id : (await client.query("SELECT building_id FROM buildings WHERE building_code = 'SAC'")).rows[0].building_id;

    const b3Res = await client.query(`
      INSERT INTO buildings (campus_id, building_code, building_name) 
      VALUES ($1, 'LAB', 'Laboratory Building') 
      ON CONFLICT (building_code) DO NOTHING
      RETURNING building_id;
    `, [campusId]);
    let b3Id = b3Res.rows.length > 0 ? b3Res.rows[0].building_id : (await client.query("SELECT building_id FROM buildings WHERE building_code = 'LAB'")).rows[0].building_id;

    // 3. Ensure rooms exist matching the CSV
    const rooms = [
      { b_id: b1Id, room: 'NAC-101', cap: 50, type: 'LectureHall' },
      { b_id: b1Id, room: 'NAC-201', cap: 50, type: 'LectureHall' },
      { b_id: b1Id, room: 'NAC-301', cap: 60, type: 'LectureHall' },
      { b_id: b1Id, room: 'NAC-402', cap: 40, type: 'SeminarRoom' },
      { b_id: b2Id, room: 'SAC-101', cap: 50, type: 'LectureHall' },
      { b_id: b2Id, room: 'SAC-201', cap: 40, type: 'LectureHall' },
      { b_id: b2Id, room: 'SAC-301', cap: 45, type: 'LectureHall' },
      { b_id: b3Id, room: 'LAB-101', cap: 35, type: 'ComputerLab' },
      { b_id: b3Id, room: 'LAB-201', cap: 35, type: 'ComputerLab' },
      { b_id: b3Id, room: 'LAB-301', cap: 35, type: 'ComputerLab' },
    ];

    for (const r of rooms) {
      await client.query(`
        INSERT INTO classrooms (building_id, room_number, floor, capacity, room_type) 
        VALUES ($1, $2, $3, $4, $5)
        ON CONFLICT (building_id, room_number) DO NOTHING;
      `, [r.b_id, r.room, parseInt(r.room.split('-')[1].charAt(0)), r.cap, r.type]);
    }

    // 4. Ensure Faculty exist matching the CSV
    const faculties = [
      { email: 'arshad@university.edu', name: 'Dr. Arshad Rahman', desig: 'Professor', rank: 1, emp: 'EMP001', user: 'arshad' },
      { email: 'nusrat@university.edu', name: 'Dr. Nusrat Jahan', desig: 'AssociateProfessor', rank: 2, emp: 'EMP002', user: 'nusrat' },
      { email: 'kamal@university.edu', name: 'Dr. Kamal Hossain', desig: 'AssociateProfessor', rank: 2, emp: 'EMP003', user: 'kamal' },
      { email: 'ruhul@university.edu', name: 'Dr. Ruhul Amin', desig: 'AssistantProfessor', rank: 3, emp: 'EMP004', user: 'ruhul' },
      { email: 'samia@university.edu', name: 'Dr. Samia Islam', desig: 'AssistantProfessor', rank: 3, emp: 'EMP005', user: 'samia' },
      { email: 'farhan@university.edu', name: 'Farhan Chowdhury', desig: 'Lecturer', rank: 4, emp: 'EMP006', user: 'farhan' },
      { email: 'samiul@university.edu', name: 'Samiul Hasan', desig: 'Lecturer', rank: 4, emp: 'EMP007', user: 'samiul' },
      { email: 'tasneem@university.edu', name: 'Tasneem Akter', desig: 'Lecturer', rank: 4, emp: 'EMP008', user: 'tasneem' },
      { email: 'rafiq@university.edu', name: 'Rafiqul Islam', desig: 'Lecturer', rank: 4, emp: 'EMP009', user: 'rafiq' },
      { email: 'mehrin@university.edu', name: 'Mehrin Nahar', desig: 'AssistantProfessor', rank: 3, emp: 'EMP010', user: 'mehrin' },
      { email: 'nadia@university.edu', name: 'Nadia Rahman', desig: 'Lecturer', rank: 4, emp: 'EMP011', user: 'nadia' },
      { email: 'junaid@university.edu', name: 'Junaid Ahmed', desig: 'Lecturer', rank: 4, emp: 'EMP012', user: 'junaid' },
      { email: 'fahim@university.edu', name: 'Fahim Shahriar', desig: 'AssistantProfessor', rank: 3, emp: 'EMP013', user: 'fahim' },
      { email: 'rubina@university.edu', name: 'Rubina Akhter', desig: 'Lecturer', rank: 4, emp: 'EMP014', user: 'rubina' },
      { email: 'kazi@university.edu', name: 'Dr. Kazi Mahbub', desig: 'Professor', rank: 1, emp: 'EMP015', user: 'kazi' },
      { email: 'sara@university.edu', name: 'Dr. Sara Ferdous', desig: 'AssociateProfessor', rank: 2, emp: 'EMP016', user: 'sara' },
      { email: 'tariq@university.edu', name: 'Tariq Hasan', desig: 'Lecturer', rank: 4, emp: 'EMP017', user: 'tariq' },
      { email: 'monira@university.edu', name: 'Dr. Monira Khatun', desig: 'Professor', rank: 1, emp: 'EMP018', user: 'monira' },
      { email: 'hasan@university.edu', name: 'Hasan Mahmud', desig: 'AssistantProfessor', rank: 3, emp: 'EMP019', user: 'hasan' },
      { email: 'sayeed@university.edu', name: 'Sayeed Anwar', desig: 'Lecturer', rank: 4, emp: 'EMP020', user: 'sayeed' },
      { email: 'zaman@university.edu', name: 'Dr. Zaman Khan', desig: 'Professor', rank: 1, emp: 'EMP021', user: 'zaman' },
      { email: 'farzana@university.edu', name: 'Farzana Haque', desig: 'Lecturer', rank: 4, emp: 'EMP022', user: 'farzana' },
      { email: 'imran@university.edu', name: 'Imran Hossain', desig: 'Lecturer', rank: 4, emp: 'EMP023', user: 'imran' },
      { email: 'nafis@university.edu', name: 'Nafis Ahmed', desig: 'AssistantProfessor', rank: 3, emp: 'EMP024', user: 'nafis' },
      { email: 'sadia@university.edu', name: 'Sadia Islam', desig: 'Lecturer', rank: 4, emp: 'EMP025', user: 'sadia' },
      { email: 'tahmid@university.edu', name: 'Tahmidur Rahman', desig: 'Lecturer', rank: 4, emp: 'EMP026', user: 'tahmid' },
      { email: 'anis@university.edu', name: 'Dr. Anisur Rahman', desig: 'Professor', rank: 1, emp: 'EMP027', user: 'anis' },
      { email: 'salman@university.edu', name: 'Salman Farsi', desig: 'Lecturer', rank: 4, emp: 'EMP028', user: 'salman' },
      { email: 'maliha@university.edu', name: 'Maliha Tabassum', desig: 'Lecturer', rank: 4, emp: 'EMP029', user: 'maliha' },
      { email: 'rezwan@university.edu', name: 'Rezwanul Haque', desig: 'Lecturer', rank: 4, emp: 'EMP030', user: 'rezwan' }
    ];

    for (const f of faculties) {
      await client.query(`
        INSERT INTO faculty (employee_id, full_name_en, full_name_bn, email, designation, seniority_rank, username)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT (email) DO NOTHING;
      `, [f.emp, f.name, f.name, f.email, f.desig, f.rank, f.user]);
    }
    
    // 5. Create a department placeholder if needed to match frontend hardcoded id
    // e381fcfa-3cd6-43a7-ab3c-586d4d1c2525 

    await client.query('COMMIT');
    console.log('✅ Base seed data inserted (Campuses, Buildings, Rooms, Faculty).');
    console.log('Now your teammates can import the two CSV files to load courses and preferences!');
    
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('❌ Seeding error:', e);
  } finally {
    client.release();
    pool.end();
  }
}

seedData();
