-- Classroom Booking System (CBS) Database Schema
-- Last updated: 2026-07-04

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- =========================================================================
-- ENUMS & CUSTOM TYPES
-- =========================================================================

CREATE TYPE public.booking_status_enum AS ENUM (
    'Draft',
    'Pending',
    'Confirmed',
    'Waitlisted',
    'CancelledByFaculty',
    'CancelledByAdmin',
    'AutoCancelledNoShow',
    'Completed',
    'PendingAdminApproval'
);

CREATE TYPE public.booking_type_enum AS ENUM (
    'OneTime',
    'Recurring'
);

CREATE TYPE public.event_type_enum AS ENUM (
    'PublicHoliday',
    'InstitutionalHoliday',
    'ExamPeriodMidterm',
    'ExamPeriodFinal',
    'SemesterStart',
    'SemesterEnd',
    'BlackoutEvent'
);

CREATE TYPE public.faculty_designation_enum AS ENUM (
    'Professor',
    'AssociateProfessor',
    'AssistantProfessor',
    'Lecturer',
    'Adjunct',
    'Emeritus',
    'Visiting'
);

CREATE TYPE public.pattern_enum AS ENUM (
    'Weekly',
    'BiWeekly',
    'CustomDates'
);

CREATE TYPE public.room_status_enum AS ENUM (
    'Active',
    'Maintenance',
    'Inactive',
    'TemporarilyClosed'
);

CREATE TYPE public.room_type_enum AS ENUM (
    'LectureHall',
    'SeminarRoom',
    'ComputerLab',
    'ExamHall',
    'ConferenceRoom',
    'StudioLab'
);

CREATE TYPE public.waitlist_status_enum AS ENUM (
    'Waiting',
    'AutoPromoted',
    'ManualOverridePromoted',
    'Expired',
    'Removed'
);

-- =========================================================================
-- TABLES
-- =========================================================================

-- 1. Campuses
CREATE TABLE public.campuses (
    campus_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    campus_name character varying(100) NOT NULL,
    geographic_scope character varying(100) NOT NULL,
    CONSTRAINT campuses_pkey PRIMARY KEY (campus_id)
);

-- 2. Buildings
CREATE TABLE public.buildings (
    building_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    campus_id uuid REFERENCES public.campuses(campus_id) ON DELETE RESTRICT,
    building_code character varying(20) NOT NULL,
    building_name character varying(100) NOT NULL,
    address text,
    operating_hours jsonb DEFAULT '{"default": {"open": "08:00", "close": "20:00"}}'::jsonb NOT NULL,
    CONSTRAINT buildings_pkey PRIMARY KEY (building_id),
    CONSTRAINT buildings_building_code_key UNIQUE (building_code)
);

-- 4. Classrooms
CREATE TABLE public.classrooms (
    room_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    building_id uuid REFERENCES public.buildings(building_id) ON DELETE RESTRICT,
    room_number character varying(30) NOT NULL,
    floor integer NOT NULL,
    capacity integer NOT NULL,
    room_type public.room_type_enum NOT NULL,
    status public.room_status_enum DEFAULT 'Active'::public.room_status_enum NOT NULL,
    equipment jsonb DEFAULT '{}'::jsonb NOT NULL,
    operating_hours jsonb,
    photos text[] DEFAULT '{}'::text[],
    CONSTRAINT classrooms_pkey PRIMARY KEY (room_id),
    CONSTRAINT unique_building_room UNIQUE (building_id, room_number),
    CONSTRAINT chk_positive_capacity CHECK (capacity > 0)
);

-- 5. Faculty
CREATE TABLE public.faculty (
    faculty_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    employee_id character varying(50) NOT NULL,
    full_name_en character varying(120) NOT NULL,
    full_name_bn character varying(120) NOT NULL,
    email character varying(150) NOT NULL,
    designation public.faculty_designation_enum NOT NULL,
    seniority_rank integer NOT NULL,
    dept_head_flag boolean DEFAULT false NOT NULL,
    status character varying(30) DEFAULT 'Active'::character varying NOT NULL,
    hr_sync_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    password character varying(255) DEFAULT 'password123'::character varying,
    username character varying(100) NOT NULL,
    joining_date date,
    department character varying(100),
    phone character varying(20),
    profile_photo_url character varying(255),
    rank_justification text,
    CONSTRAINT faculty_pkey PRIMARY KEY (faculty_id),
    CONSTRAINT faculty_email_key UNIQUE (email),
    CONSTRAINT faculty_employee_id_key UNIQUE (employee_id),
    CONSTRAINT faculty_username_key UNIQUE (username),
    CONSTRAINT chk_seniority CHECK ((seniority_rank >= 1) AND (seniority_rank <= 4))
);

-- 6. Courses
CREATE TABLE public.courses (
    course_id uuid DEFAULT gen_random_uuid() NOT NULL,
    course_code character varying(20) NOT NULL,
    course_name character varying(255) NOT NULL,
    credits integer DEFAULT 3,
    course_level integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT courses_pkey PRIMARY KEY (course_id),
    CONSTRAINT courses_course_code_key UNIQUE (course_code)
);

-- 7. Course Sections
CREATE TABLE public.course_sections (
    section_id uuid DEFAULT gen_random_uuid() NOT NULL,
    course_id uuid NOT NULL REFERENCES public.courses(course_id) ON DELETE CASCADE,
    semester character varying(20) NOT NULL,
    section_number character varying(10) NOT NULL,
    enrollment_size integer NOT NULL,
    day_of_week integer[],
    start_time time without time zone,
    end_time time without time zone,
    facility_type character varying(50) DEFAULT 'Any'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    assigned_faculty_id uuid REFERENCES public.faculty(faculty_id) ON DELETE SET NULL,
    CONSTRAINT course_sections_pkey PRIMARY KEY (section_id),
    CONSTRAINT course_sections_course_id_semester_section_number_key UNIQUE (course_id, semester, section_number)
);

-- 8. Recurring Series
CREATE TABLE public.recurring_series (
    series_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    faculty_id uuid REFERENCES public.faculty(faculty_id) ON DELETE RESTRICT,
    room_id uuid REFERENCES public.classrooms(room_id) ON DELETE RESTRICT,
    pattern public.pattern_enum NOT NULL,
    days_of_week integer[] NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    total_instances integer NOT NULL,
    confirmed_count integer DEFAULT 0 NOT NULL,
    skipped_count integer DEFAULT 0 NOT NULL,
    status character varying(30) DEFAULT 'Active'::character varying NOT NULL,
    CONSTRAINT recurring_series_pkey PRIMARY KEY (series_id),
    CONSTRAINT chk_series_dates CHECK (start_date <= end_date),
    CONSTRAINT chk_series_times CHECK (start_time < end_time)
);

-- 9. Bookings
CREATE TABLE public.bookings (
    booking_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    booking_request_id character varying(40) NOT NULL,
    faculty_id uuid REFERENCES public.faculty(faculty_id) ON DELETE RESTRICT,
    room_id uuid REFERENCES public.classrooms(room_id) ON DELETE RESTRICT,
    course_code character varying(30) NOT NULL,
    course_name character varying(150) NOT NULL,
    class_size integer NOT NULL,
    start_dt timestamp with time zone NOT NULL,
    end_dt timestamp with time zone NOT NULL,
    booking_type public.booking_type_enum NOT NULL,
    status public.booking_status_enum DEFAULT 'Pending'::public.booking_status_enum NOT NULL,
    notes text,
    series_id uuid REFERENCES public.recurring_series(series_id) ON DELETE SET NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    checkin_at timestamp with time zone,
    CONSTRAINT bookings_pkey PRIMARY KEY (booking_id),
    CONSTRAINT bookings_booking_request_id_key UNIQUE (booking_request_id),
    CONSTRAINT chk_booking_timestamps CHECK (start_dt < end_dt),
    CONSTRAINT chk_positive_size CHECK (class_size > 0)
);

-- 10. Waitlist Entries
CREATE TABLE public.waitlist_entries (
    waitlist_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    booking_id uuid REFERENCES public.bookings(booking_id) ON DELETE CASCADE,
    room_id uuid REFERENCES public.classrooms(room_id) ON DELETE RESTRICT,
    faculty_id uuid REFERENCES public.faculty(faculty_id) ON DELETE RESTRICT,
    seniority_rank_at_time integer NOT NULL,
    submission_ts timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    priority_position integer,
    reason text,
    status public.waitlist_status_enum DEFAULT 'Waiting'::public.waitlist_status_enum NOT NULL,
    CONSTRAINT waitlist_entries_pkey PRIMARY KEY (waitlist_id),
    CONSTRAINT waitlist_entries_booking_id_key UNIQUE (booking_id)
);

-- 11. Allocation Batches
CREATE TABLE public.allocation_batches (
    batch_id uuid DEFAULT gen_random_uuid() NOT NULL,
    semester character varying(20) NOT NULL,
    created_by uuid NOT NULL REFERENCES public.faculty(faculty_id),
    status character varying(50) DEFAULT 'Draft'::character varying,
    is_published boolean DEFAULT false,

    total_sections integer DEFAULT 0,
    successfully_allocated integer DEFAULT 0,
    failed_allocations integer DEFAULT 0,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT allocation_batches_pkey PRIMARY KEY (batch_id)
);

-- 12. Semester Allocations
CREATE TABLE public.semester_allocations (
    allocation_id uuid DEFAULT gen_random_uuid() NOT NULL,
    batch_id uuid NOT NULL REFERENCES public.allocation_batches(batch_id) ON DELETE CASCADE,
    section_id uuid NOT NULL REFERENCES public.course_sections(section_id),
    room_id uuid NOT NULL REFERENCES public.classrooms(room_id),
    allocated_day_of_week integer,
    allocated_start_time time without time zone,
    allocated_end_time time without time zone,
    status character varying(50) DEFAULT 'Allocated'::character varying,
    is_published boolean DEFAULT false,

    allocation_reason text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    allocated_faculty_id uuid REFERENCES public.faculty(faculty_id) ON DELETE SET NULL,
    allocated_faculty_name character varying(150),
    allocated_faculty_email character varying(150),
    CONSTRAINT semester_allocations_pkey PRIMARY KEY (allocation_id)
);

-- 13. Allocation Conflicts
CREATE TABLE public.allocation_conflicts (
    conflict_id uuid DEFAULT gen_random_uuid() NOT NULL,
    batch_id uuid NOT NULL REFERENCES public.allocation_batches(batch_id) ON DELETE CASCADE,
    section_id uuid NOT NULL REFERENCES public.course_sections(section_id),
    conflict_type character varying(50),
    description text,
    suggested_solutions text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT allocation_conflicts_pkey PRIMARY KEY (conflict_id)
);

-- 14. Faculty Course Preferences
CREATE TABLE public.faculty_course_preferences (
    preference_id uuid DEFAULT gen_random_uuid() NOT NULL,
    faculty_id uuid REFERENCES public.faculty(faculty_id) ON DELETE CASCADE,
    section_id uuid NOT NULL REFERENCES public.course_sections(section_id) ON DELETE CASCADE,
    choice_rank integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    preferred_day_of_week integer[],
    preferred_start_time time without time zone,
    preferred_end_time time without time zone,
    preferred_room_id uuid REFERENCES public.classrooms(room_id) ON DELETE SET NULL,
    faculty_name character varying(150),
    faculty_designation character varying(100),
    seniority_rank integer,
    faculty_email character varying(150),
    CONSTRAINT faculty_course_preferences_pkey PRIMARY KEY (preference_id),
    CONSTRAINT faculty_course_preferences_email_choice_rank_key UNIQUE (faculty_email, choice_rank),
    CONSTRAINT faculty_course_preferences_email_section_id_key UNIQUE (faculty_email, section_id)
);

-- 15. Academic Calendar
CREATE TABLE public.academic_calendar (
    event_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    event_type public.event_type_enum NOT NULL,
    name character varying(150) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    description text,
    source character varying(30) DEFAULT 'API'::character varying NOT NULL,
    synced_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT academic_calendar_pkey PRIMARY KEY (event_id),
    CONSTRAINT chk_calendar_dates CHECK (start_date <= end_date)
);

-- 16. Maintenance Windows
CREATE TABLE public.maintenance_windows (
    maintenance_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    room_id uuid REFERENCES public.classrooms(room_id) ON DELETE CASCADE,
    start_dt timestamp with time zone NOT NULL,
    end_dt timestamp with time zone NOT NULL,
    reason text NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT maintenance_windows_pkey PRIMARY KEY (maintenance_id),
    CONSTRAINT chk_maintenance_timestamps CHECK (start_dt < end_dt)
);

-- 17. Notifications
CREATE TABLE public.notifications (
    notif_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid REFERENCES public.faculty(faculty_id) ON DELETE CASCADE,
    type character varying(50) NOT NULL,
    channel character varying(20) NOT NULL,
    subject character varying(200) NOT NULL,
    body text NOT NULL,
    status character varying(20) DEFAULT 'Pending'::character varying NOT NULL,
    sent_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    read_at timestamp with time zone,
    booking_id uuid REFERENCES public.bookings(booking_id) ON DELETE SET NULL,
    CONSTRAINT notifications_pkey PRIMARY KEY (notif_id)
);

-- 18. System Config
CREATE TABLE public.system_config (
    config_key character varying(50) NOT NULL,
    config_value jsonb NOT NULL,
    description text,
    last_updated_by uuid,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT system_config_pkey PRIMARY KEY (config_key)
);

-- 19. Audit Logs
CREATE TABLE public.audit_logs (
    log_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    user_role character varying(50) NOT NULL,
    action character varying(100) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id uuid NOT NULL,
    field_changed character varying(100),
    old_value jsonb,
    new_value jsonb,
    ip_address inet,
    user_agent text,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT audit_logs_pkey PRIMARY KEY (log_id)
);

-- =========================================================================
-- INDEXES
-- =========================================================================

CREATE INDEX IF NOT EXISTS idx_course_sections_semester ON public.course_sections(semester);
CREATE INDEX IF NOT EXISTS idx_semester_allocations_batch_id ON public.semester_allocations(batch_id);
CREATE INDEX IF NOT EXISTS idx_allocation_batches_semester ON public.allocation_batches(semester);

-- Foreign Key Indexes for Performance
CREATE INDEX IF NOT EXISTS idx_bookings_faculty_id ON public.bookings(faculty_id);
CREATE INDEX IF NOT EXISTS idx_bookings_room_id ON public.bookings(room_id);
CREATE INDEX IF NOT EXISTS idx_bookings_series_id ON public.bookings(series_id);
CREATE INDEX IF NOT EXISTS idx_course_sections_course_id ON public.course_sections(course_id);
CREATE INDEX IF NOT EXISTS idx_waitlist_entries_booking_id ON public.waitlist_entries(booking_id);
CREATE INDEX IF NOT EXISTS idx_waitlist_entries_faculty_id ON public.waitlist_entries(faculty_id);
CREATE INDEX IF NOT EXISTS idx_waitlist_entries_room_id ON public.waitlist_entries(room_id);

-- =========================================================================
-- TRIGGERS & FUNCTIONS
-- =========================================================================

CREATE OR REPLACE FUNCTION trigger_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to relevant tables
DROP TRIGGER IF EXISTS set_updated_at_courses ON public.courses;
CREATE TRIGGER set_updated_at_courses
BEFORE UPDATE ON public.courses
FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_course_sections ON public.course_sections;
CREATE TRIGGER set_updated_at_course_sections
BEFORE UPDATE ON public.course_sections
FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_bookings ON public.bookings;
CREATE TRIGGER set_updated_at_bookings
BEFORE UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_allocation_batches ON public.allocation_batches;
CREATE TRIGGER set_updated_at_allocation_batches
BEFORE UPDATE ON public.allocation_batches
FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_semester_allocations ON public.semester_allocations;
CREATE TRIGGER set_updated_at_semester_allocations
BEFORE UPDATE ON public.semester_allocations
FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_system_config ON public.system_config;
CREATE TRIGGER set_updated_at_system_config
BEFORE UPDATE ON public.system_config
FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

