import pool from './db';
import { resolvePriority, promoteWaitlist } from './priorityEngine';

async function runTest() {
  console.log('🧪 Starting Priority Conflict and Promotion Engine Tests...');

  try {
    // 1. Clean up any existing test bookings for our NAC-301 room to prevent interference
    const roomId = '66075005-71c7-4679-946e-8b777d2dc175'; // NAC-301 from seeds
    await pool.query(
      `DELETE FROM waitlist_entries WHERE room_id = $1`,
      [roomId]
    );
    await pool.query(
      `DELETE FROM bookings WHERE room_id = $1`,
      [roomId]
    );

    // 2. Fetch test faculties
    const facRes = await pool.query(`SELECT faculty_id, seniority_rank, full_name_en FROM faculty ORDER BY seniority_rank ASC`);
    const prof = facRes.rows[0]; // Rank 1 (Professor) e.g., Dr. Arshad
    const assoc = facRes.rows[1]; // Rank 2 (Associate Professor) e.g., Dr. Nusrat
    const lecturer = facRes.rows[3]; // Rank 4 (Lecturer) e.g., Samiul

    console.log(`Using test profiles: \n- ${prof.full_name_en} (Professor, Rank ${prof.seniority_rank})\n- ${assoc.full_name_en} (Assoc Professor, Rank ${assoc.seniority_rank})\n- ${lecturer.full_name_en} (Lecturer, Rank ${lecturer.seniority_rank})`);

    // Test case: Book NAC-301 for 10:00 AM - 12:00 PM today
    const today = new Date().toISOString().split('T')[0];
    const startDt = `${today}T10:00:00`;
    const endDt = `${today}T12:00:00`;

    // 3. Lecturer Samiul books the slot first
    console.log('\nStep 1: Lecturer Samiul submits a booking request for NAC-301 at 10:00-12:00...');
    const booking1Res = await pool.query(
      `INSERT INTO bookings (booking_request_id, faculty_id, room_id, course_code, course_name, class_size, start_dt, end_dt, booking_type, status, notes)
       VALUES ('TEST-BR-01', $1, $2, 'CSE-101', 'Intro to CS', 30, $3, $4, 'OneTime', 'Pending', 'Test booking 1')
       RETURNING booking_id, status`,
      [lecturer.faculty_id, roomId, startDt, endDt]
    );
    const booking1Id = booking1Res.rows[0].booking_id;

    // Resolve priority
    const res1 = await resolvePriority(booking1Id);
    console.log(`Result: Booking status set to ${res1.status}. Reason: ${res1.reason}`);

    if (res1.status !== 'Confirmed') {
      throw new Error('Test failed: Initial booking should have been Confirmed!');
    }

    // 4. Professor Arshad Rahman submits an overlapping booking request (No-Bump Policy check)
    console.log('\nStep 2: Professor Arshad (higher priority rank 1) requests the same slot (No-Bump check)...');
    const booking2Res = await pool.query(
      `INSERT INTO bookings (booking_request_id, faculty_id, room_id, course_code, course_name, class_size, start_dt, end_dt, booking_type, status, notes)
       VALUES ('TEST-BR-02', $1, $2, 'CSE-401', 'Advanced AI', 35, $3, $4, 'OneTime', 'Pending', 'Test booking 2')
       RETURNING booking_id, status`,
      [prof.faculty_id, roomId, startDt, endDt]
    );
    const booking2Id = booking2Res.rows[0].booking_id;

    // Resolve priority
    const res2 = await resolvePriority(booking2Id);
    console.log(`Result: Booking status set to ${res2.status}. Reason: ${res2.reason}`);

    if (res2.status !== 'Waitlisted') {
      throw new Error('Test failed: High seniority late request should be Waitlisted (No-Bump Policy)!');
    }
    console.log('✓ No-Bump Policy successfully verified (Professor waitlisted behind Lecturer).');

    // 5. Associate Professor Nusrat Jahan requests the same slot (Waitlist queue sorting check)
    console.log('\nStep 3: Associate Professor Nusrat (rank 2) also requests the same slot...');
    const booking3Res = await pool.query(
      `INSERT INTO bookings (booking_request_id, faculty_id, room_id, course_code, course_name, class_size, start_dt, end_dt, booking_type, status, notes)
       VALUES ('TEST-BR-03', $1, $2, 'CSE-202', 'Data Structures', 32, $3, $4, 'OneTime', 'Pending', 'Test booking 3')
       RETURNING booking_id, status`,
      [assoc.faculty_id, roomId, startDt, endDt]
    );
    const booking3Id = booking3Res.rows[0].booking_id;

    const res3 = await resolvePriority(booking3Id);
    console.log(`Result: Booking status set to ${res3.status}. Reason: ${res3.reason}`);

    // 6. Samiul cancels his booking -> triggers waitlist promotion (Arshad has rank 1, Nusrat has rank 2. Arshad should be promoted)
    console.log('\nStep 4: Lecturer Samiul cancels his confirmed booking...');
    await pool.query(
      `UPDATE bookings SET status = 'CancelledByFaculty' WHERE booking_id = $1`,
      [booking1Id]
    );
    console.log('Confirmed slot released. Invoking waitlist promotion...');
    await promoteWaitlist(roomId, startDt, endDt);

    // Verify booking 2 (Professor Arshad) is promoted
    const checkBooking2 = await pool.query(`SELECT status FROM bookings WHERE booking_id = $1`, [booking2Id]);
    console.log(`Professor Arshad's booking status after promotion check: ${checkBooking2.rows[0].status}`);

    if (checkBooking2.rows[0].status !== 'Confirmed') {
      throw new Error('Test failed: Professor Arshad should have been promoted to Confirmed!');
    }
    console.log('✓ Waitlist promotion successfully verified (Professor Arshad promoted).');

    // Verify booking 3 (Nusrat) is still waitlisted
    const checkBooking3 = await pool.query(`SELECT status FROM bookings WHERE booking_id = $1`, [booking3Id]);
    console.log(`Associate Professor Nusrat's booking status: ${checkBooking3.rows[0].status}`);

    if (checkBooking3.rows[0].status !== 'Waitlisted') {
      throw new Error('Test failed: Nusrat should have remained Waitlisted!');
    }
    console.log('✓ Nusrat correctly remained waitlisted.');

    // 7. Cleanup test records
    console.log('\nCleaning up test records...');
    await pool.query(`DELETE FROM waitlist_entries WHERE room_id = $1`, [roomId]);
    await pool.query(`DELETE FROM bookings WHERE room_id = $1`, [roomId]);

    console.log('\n🎉 ALL TESTS PASSED SUCCESSFULLY! The Priority Resolution Engine is working flawlessly according to the SRS specifications.');

  } catch (err) {
    console.error('\n❌ Test execution failed with error:', err);
  } finally {
    await pool.end();
  }
}

runTest();
