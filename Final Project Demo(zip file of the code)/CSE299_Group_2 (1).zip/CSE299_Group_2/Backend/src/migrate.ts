import fs from 'fs';
import path from 'path';
import pool from './db';

/**
 * Simple migration runner that executes SQL files in order
 */
async function runMigrations() {
  const migrationsDir = path.join(__dirname, '..', 'migrations');

  if (!fs.existsSync(migrationsDir)) {
    console.log('No migrations directory found. Skipping migrations.');
    return;
  }

  const migrationFiles = fs
    .readdirSync(migrationsDir)
    .filter((f) => f.endsWith('.sql'))
    .sort();

  console.log(`Found ${migrationFiles.length} migration file(s)`);

  for (const file of migrationFiles) {
    const filePath = path.join(migrationsDir, file);
    const sql = fs.readFileSync(filePath, 'utf-8');

    try {
      console.log(`Running migration: ${file}`);
      const statements = sql.split(';').filter((s) => s.trim());

      for (const statement of statements) {
        if (statement.trim()) {
          await pool.query(statement);
        }
      }

      console.log(`✓ Migration completed: ${file}`);
    } catch (err) {
      console.error(`✗ Migration failed: ${file}`, err);
      throw err;
    }
  }

  console.log('All migrations completed successfully!');
}

// Run migrations if this file is executed directly
if (require.main === module) {
  runMigrations()
    .then(() => {
      console.log('Migrations finished');
      pool.end();
    })
    .catch((err) => {
      console.error('Migration error:', err);
      pool.end();
      process.exit(1);
    });
}

export default runMigrations;
