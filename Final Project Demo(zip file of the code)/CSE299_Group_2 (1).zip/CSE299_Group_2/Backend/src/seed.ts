import pool from './db';

async function seed() {
  console.log('Seeding default admin, system configurations, and academic calendar...');
  try {
    // 0. Seed default admin in faculty table
    await pool.query(`
      INSERT INTO faculty (
        faculty_id, employee_id, full_name_en, full_name_bn, email, 
        designation, seniority_rank, dept_head_flag, 
        status, password, username
      )
      VALUES (
        '00000000-0000-0000-0000-000000000000', 
        'EMP-ADMIN', 
        'Registrar Admin', 
        'রেজিস্ট্রার এডমিন', 
        'admin@university.edu', 
        'Lecturer', 
        4, 
        false, 
        'Active', 
        'admin123', 
        'admin'
      )
      ON CONFLICT (faculty_id) DO NOTHING
    `);

    // 1. Seed system_config
    const configs = [
      { key: 'booking_window_days', val: { days: '60' }, desc: 'Max days in advance faculty can book' },
      { key: 'no_show_grace_period', val: { minutes: '15' }, desc: 'Grace period for no-show auto-cancellation' },
      { key: 'recurring_max_weeks', val: { weeks: '18' }, desc: 'Max weeks for recurring bookings' }
    ];

    for (const config of configs) {
      await pool.query(
        `INSERT INTO system_config (config_key, config_value, description, last_updated_by)
         VALUES ($1, $2, $3, '00000000-0000-0000-0000-000000000000'::uuid)
         ON CONFLICT (config_key) DO UPDATE
         SET config_value = EXCLUDED.config_value, description = EXCLUDED.description`,
        [config.key, JSON.stringify(config.val), config.desc]
      );
    }

    // 2. Seed academic_calendar events
    const events = [
      { etype: 'SemesterStart', name: 'Summer Semester 2026 Start', start: '2026-05-01', end: '2026-05-05', desc: 'Start of Summer semester classes' },
      { etype: 'SemesterEnd', name: 'Summer Semester 2026 End', start: '2026-08-31', end: '2026-08-31', desc: 'End of Summer semester classes' },
      { etype: 'PublicHoliday', name: 'Eid-ul-Adha Holiday', start: '2026-06-17', end: '2026-06-19', desc: 'Eid public holiday' },
      { etype: 'ExamPeriodMidterm', name: 'Mid-Term Examinations', start: '2026-06-25', end: '2026-07-02', desc: 'Mid-term exam blackout period' },
      { etype: 'ExamPeriodFinal', name: 'Final Examinations', start: '2026-08-15', end: '2026-08-25', desc: 'Final exam blackout period' }
    ];

    await pool.query(`DELETE FROM academic_calendar WHERE source = 'Manual' OR source = 'API'`);

    for (const e of events) {
      await pool.query(
        `INSERT INTO academic_calendar (event_type, name, start_date, end_date, description, source)
         VALUES ($1, $2, $3, $4, $5, 'Manual')`,
        [e.etype, e.name, e.start, e.end, e.desc]
      );
    }

    // 3. Seed demo faculty preferences (choices) for semester Spring2026
    const arshadRes = await pool.query("SELECT faculty_id FROM faculty WHERE email = 'arshad@university.edu'");
    const nusratRes = await pool.query("SELECT faculty_id FROM faculty WHERE email = 'nusrat@university.edu'");
    const roomRes = await pool.query("SELECT room_id FROM classrooms WHERE room_number = 'NAC-402' LIMIT 1");
    const sec1Res = await pool.query("SELECT cs.section_id FROM course_sections cs JOIN courses c ON cs.course_id = c.course_id WHERE c.course_code = 'CSE101' AND cs.section_number = '01' LIMIT 1");
    const sec2Res = await pool.query("SELECT cs.section_id FROM course_sections cs JOIN courses c ON cs.course_id = c.course_id WHERE c.course_code = 'CSE201' AND cs.section_number = '01' LIMIT 1");

    if (arshadRes.rows.length > 0 && nusratRes.rows.length > 0 && roomRes.rows.length > 0 && sec1Res.rows.length > 0 && sec2Res.rows.length > 0) {
      const arshadId = arshadRes.rows[0].faculty_id;
      const nusratId = nusratRes.rows[0].faculty_id;
      const roomId = roomRes.rows[0].room_id;
      const sec1Id = sec1Res.rows[0].section_id;
      const sec2Id = sec2Res.rows[0].section_id;

      // Clear existing preferences first to avoid unique key conflicts
      await pool.query("DELETE FROM faculty_course_preferences");

      // Insert choices for Dr. Arshad (Rank 1 - Professor)
      await pool.query(
        `INSERT INTO faculty_course_preferences (faculty_id, section_id, choice_rank, preferred_day_of_week, preferred_start_time, preferred_end_time, preferred_room_id, faculty_name, faculty_designation, seniority_rank)
         VALUES ($1, $2, 1, ARRAY[0, 3], '10:00:00', '11:30:00', $3, 'Dr. Arshad Rahman', 'Professor', 1)`,
        [arshadId, sec1Id, roomId]
      );

      // Insert choices for Dr. Nusrat (Rank 2 - Associate Professor)
      await pool.query(
        `INSERT INTO faculty_course_preferences (faculty_id, section_id, choice_rank, preferred_day_of_week, preferred_start_time, preferred_end_time, preferred_room_id, faculty_name, faculty_designation, seniority_rank)
         VALUES ($1, $2, 1, ARRAY[1, 3], '11:30:00', '13:00:00', $3, 'Dr. Nusrat Jahan', 'Associate Professor', 2)`,
        [nusratId, sec2Id, roomId]
      );
      console.log('Demo faculty choices/preferences seeded successfully!');
    }

    console.log('Seeding completed successfully!');
  } catch (err) {
    console.error('Error during seeding:', err);
  } finally {
    pool.end();
  }
}

seed();
