import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import pool from './db';
import classroomsRouter from './routes/classrooms';
import bookingsRouter from './routes/bookings';
import facultyRouter from './routes/faculty';
import adminRouter from './routes/admin';
import reportsRouter from './routes/reports';
import authRouter from './routes/auth';
import { startBackgroundJobs } from './jobs';

dotenv.config();

const app = express();
const port = process.env.PORT || 5001;

app.use(cors());
app.use(express.json());

// Root Welcoming Route
app.get('/', (req, res) => {
  res.json({ message: 'Classroom Booking System Backend Engine is running.', healthCheck: '/api/health' });
});

// API Health Check
app.get('/api/health', async (req, res) => {
  try {
    const dbTest = await pool.query('SELECT NOW();');
    res.json({ status: 'ok', serverTime: dbTest.rows[0].now });
  } catch (err) {
    res.status(500).json({ status: 'error', message: (err as Error).message });
  }
});

// Register routers
app.use('/api/classrooms', classroomsRouter);
app.use('/api/bookings', bookingsRouter);
app.use('/api/faculty', facultyRouter);
app.use('/api/admin', adminRouter);
app.use('/api/reports', reportsRouter);
app.use('/api/auth', authRouter);

// Start listening and run background jobs
app.listen(port, () => {
  console.log(`🚀 Backend Engine spinning up on port ${port}`);
  startBackgroundJobs();
});