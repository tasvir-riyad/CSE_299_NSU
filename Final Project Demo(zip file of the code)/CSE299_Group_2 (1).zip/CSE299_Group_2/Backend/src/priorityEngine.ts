import pool from './db';

// Helper to log audit events
export async function logAudit(
  userId: string,
  userRole: string,
  action: string,
  entityType: string,
  entityId: string,
  fieldChanged?: string,
  oldValue?: any,
  newValue?: any
) {
  try {
    await pool.query(
      `INSERT INTO audit_logs (user_id, user_role, action, entity_type, entity_id, field_changed, old_value, new_value)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [
        userId,
        userRole,
        action,
        entityType,
        entityId,
        fieldChanged || null,
        oldValue ? JSON.stringify(oldValue) : null,
        newValue ? JSON.stringify(newValue) : null,
      ]
    );
  } catch (err) {
    console.error('Failed to write audit log:', err);
  }
}

// Helper to send/log notifications
export async function createNotification(
  userId: string,
  type: string,
  channel: string,
  subject: string,
  body: string,
  bookingId?: string
) {
  try {
    await pool.query(
      `INSERT INTO notifications (user_id, type, channel, subject, body, status, booking_id)
       VALUES ($1, $2, $3, $4, $5, 'Sent', $6)`,
      [userId, type, channel, subject, body, bookingId || null]
    );
    console.log(`[Notification ${channel}] To: ${userId} | ${subject}: ${body}`);
  } catch (err) {
    console.error('Failed to create notification:', err);
  }
}

/**
 * Checks for any confirmed or pending bookings that overlap with the requested slot
 */
export async function checkOverlap(
  roomId: string,
  startDt: Date | string,
  endDt: Date | string,
  ignoreBookingId?: string
) {
  let query = `
    SELECT b.*, f.seniority_rank, f.full_name_en, f.designation
    FROM bookings b
    JOIN faculty f ON b.faculty_id = f.faculty_id
    WHERE b.room_id = $1
      AND b.status IN ('Confirmed', 'Pending', 'PendingAdminApproval')
      AND b.start_dt < $3
      AND b.end_dt > $2
  `;
  const params: any[] = [roomId, startDt, endDt];

  if (ignoreBookingId) {
    query += ` AND b.booking_id <> $4`;
    params.push(ignoreBookingId);
  }

  const res = await pool.query(query, params);
  return res.rows;
}

/**
 * Priority engine conflict resolution
 * Executed after a booking request is saved as 'Draft' or submitted.
 */
export async function resolvePriority(bookingId: string): Promise<{ status: string; reason: string }> {
  // Fetch booking details
  const bookingRes = await pool.query(
    `SELECT b.*, f.seniority_rank, f.designation, f.full_name_en, c.room_type, c.room_number
     FROM bookings b
     JOIN faculty f ON b.faculty_id = f.faculty_id
     JOIN classrooms c ON b.room_id = c.room_id
     WHERE b.booking_id = $1`,
    [bookingId]
  );

  if (bookingRes.rowCount === 0) {
    throw new Error('Booking not found');
  }

  const booking = bookingRes.rows[0];

  // 1. Check if the date falls inside an Exam Period
  // Check academic_calendar for exam period overlap
  const calendarRes = await pool.query(
    `SELECT * FROM academic_calendar
     WHERE event_type IN ('ExamPeriodMidterm', 'ExamPeriodFinal')
       AND start_date <= $1::date AND end_date >= $2::date`,
    [booking.start_dt, booking.start_dt]
  );

  const isExamPeriod = calendarRes.rows.length > 0;
  const isExamHall = booking.room_type === 'ExamHall';

  // 2. Check for conflicts
  const conflicts = await checkOverlap(booking.room_id, booking.start_dt, booking.end_dt, bookingId);
  const confirmedConflicts = conflicts.filter((c) => c.status === 'Confirmed');

  // No-Bump Policy (PA-008): Confirmed bookings cannot be bumped.
  if (confirmedConflicts.length > 0) {
    // Determine the highest priority confirmed conflicting booking
    confirmedConflicts.sort((a, b) => a.seniority_rank - b.seniority_rank);
    const primaryConflict = confirmedConflicts[0];

    const isEqualSeniority = booking.seniority_rank === primaryConflict.seniority_rank;
    const tiebreakReason = isEqualSeniority ? ' FCFS — identical seniority rank.' : '';
    const waitlistReason = `Conflict with confirmed booking of room ${booking.room_number} by faculty with seniority rank ${primaryConflict.seniority_rank} (${primaryConflict.designation}).${tiebreakReason}`;

    // Set status to Waitlisted
    await pool.query(
      `UPDATE bookings SET status = 'Waitlisted', updated_at = CURRENT_TIMESTAMP WHERE booking_id = $1`,
      [bookingId]
    );

    // Insert into waitlist entries
    await pool.query(
      `INSERT INTO waitlist_entries (booking_id, room_id, faculty_id, seniority_rank_at_time, reason, status)
       VALUES ($1, $2, $3, $4, $5, 'Waiting')
       ON CONFLICT (booking_id) DO UPDATE SET status = 'Waiting', reason = EXCLUDED.reason`,
      [bookingId, booking.room_id, booking.faculty_id, booking.seniority_rank, waitlistReason]
    );

    // Write audit log
    await logAudit(
      booking.faculty_id,
      'Faculty',
      'WAITLISTED',
      'Booking',
      bookingId,
      'status',
      booking.status,
      'Waitlisted'
    );

    const emailBody = isEqualSeniority
      ? `Your request ${booking.booking_request_id} for ${booking.room_number} is Waitlisted. Reason: Overlaps with a booking by a faculty of equal seniority rank (${primaryConflict.designation}) (FCFS tiebreaker).`
      : `Your request ${booking.booking_request_id} for ${booking.room_number} is Waitlisted. Reason: Booked by a faculty with higher seniority rank (${primaryConflict.designation}).`;

    // Send waitlist notification
    await createNotification(
      booking.faculty_id,
      'Waitlisted',
      'Email',
      `Room ${booking.room_number} Waitlisted`,
      emailBody,
      bookingId
    );

    return { status: 'Waitlisted', reason: waitlistReason };
  }

  // No confirmed conflicts exist. Check other factors:
  // If exam period and room is not ExamHall -> PendingAdminApproval
  if (isExamPeriod && !isExamHall) {
    await pool.query(
      `UPDATE bookings SET status = 'PendingAdminApproval', updated_at = CURRENT_TIMESTAMP WHERE booking_id = $1`,
      [bookingId]
    );

    await logAudit(
      booking.faculty_id,
      'Faculty',
      'PENDING_ADMIN_APPROVAL',
      'Booking',
      bookingId,
      'status',
      booking.status,
      'PendingAdminApproval'
    );

    await createNotification(
      booking.faculty_id,
      'StatusChange',
      'Email',
      `Booking ${booking.booking_request_id} Pending Approval`,
      `Your request for ${booking.room_number} during an exam period is pending admin approval.`,
      bookingId
    );

    return { status: 'PendingAdminApproval', reason: 'Requires admin approval during exam periods' };
  }

  // Otherwise, auto-confirm
  await pool.query(
    `UPDATE bookings SET status = 'Confirmed', updated_at = CURRENT_TIMESTAMP WHERE booking_id = $1`,
    [bookingId]
  );

  // If there was a waitlist entry, delete or mark it promoted
  await pool.query(
    `DELETE FROM waitlist_entries WHERE booking_id = $1`,
    [bookingId]
  );

  await logAudit(
    booking.faculty_id,
    'Faculty',
    'CONFIRMED',
    'Booking',
    bookingId,
    'status',
    booking.status,
    'Confirmed'
  );

  await createNotification(
    booking.faculty_id,
    'SubmissionConfirm',
    'Email',
    `Booking ${booking.booking_request_id} Confirmed`,
    `Your request for Room ${booking.room_number} on ${new Date(booking.start_dt).toLocaleDateString()} at ${new Date(booking.start_dt).toLocaleTimeString()} is CONFIRMED.`,
    bookingId
  );

  return { status: 'Confirmed', reason: 'Auto-confirmed' };
}

/**
 * Waitlist auto-promotion logic.
 * Called when a confirmed booking is cancelled, completed, or auto-cancelled.
 */
export async function promoteWaitlist(roomId: string, startDt: Date | string, endDt: Date | string) {
  console.log(`[Waitlist Promotion] Scanning waitlist for room ${roomId} between ${startDt} and ${endDt}...`);
  // Find all waitlist entries for this room that overlap with the window
  const query = `
    SELECT w.*, b.booking_request_id, b.start_dt, b.end_dt, b.course_code, f.full_name_en, f.email
    FROM waitlist_entries w
    JOIN bookings b ON w.booking_id = b.booking_id
    JOIN faculty f ON w.faculty_id = f.faculty_id
    WHERE w.room_id = $1
      AND w.status = 'Waiting'
      AND b.start_dt < $3
      AND b.end_dt > $2
    ORDER BY w.seniority_rank_at_time ASC, w.submission_ts ASC
  `;

  const res = await pool.query(query, [roomId, startDt, endDt]);

  if (res.rowCount === 0) {
    console.log(`[Waitlist Promotion] No waitlisted requests found for room ${roomId}.`);
    return;
  }

  // Promote the top candidate!
  const topCandidate = res.rows[0];
  const bookingId = topCandidate.booking_id;

  console.log(`[Waitlist Promotion] Promoting booking ${topCandidate.booking_request_id} (Faculty Seniority Rank ${topCandidate.seniority_rank_at_time})`);

  // Update booking to Confirmed
  await pool.query(
    `UPDATE bookings SET status = 'Confirmed', updated_at = CURRENT_TIMESTAMP WHERE booking_id = $1`,
    [bookingId]
  );

  // Update waitlist entry to AutoPromoted
  await pool.query(
    `UPDATE waitlist_entries SET status = 'AutoPromoted' WHERE waitlist_id = $1`,
    [topCandidate.waitlist_id]
  );

  // Audit log
  await logAudit(
    '00000000-0000-0000-0000-000000000000', // System user ID
    'System',
    'AUTO_PROMOTED',
    'Booking',
    bookingId,
    'status',
    'Waitlisted',
    'Confirmed'
  );

  // Send promotion notifications
  await createNotification(
    topCandidate.faculty_id,
    'AutoPromoted',
    'Email',
    `Waitlist Promotion: ${topCandidate.booking_request_id} Confirmed`,
    `Good news! Your waitlisted request for room ${roomId} on ${new Date(topCandidate.start_dt).toLocaleDateString()} has been promoted to CONFIRMED.`,
    bookingId
  );

  // Re-run waitlist promotion checks recursively in case there are other non-overlapping slots or cleanups
  // For the same slot, the remaining waitlist items are still waitlisted because this new slot is now confirmed.
}
