import pool from './db';
import { AllocationEngine } from './allocationEngine';

async function runTest() {
  console.log('🧪 Starting Backtracking CSP Solver Tests...');

  try {
    // 1. Create a dummy batch ID
    const batchId = '00000000-0000-0000-0000-999999999999';
    const semester = 'Spring2026';

    // Clear any previous test data for this batch
    await pool.query("DELETE FROM semester_allocations WHERE batch_id = $1", [batchId]);
    await pool.query("DELETE FROM allocation_conflicts WHERE batch_id = $1", [batchId]);
    await pool.query("DELETE FROM allocation_batches WHERE batch_id = $1", [batchId]);

    // Insert dummy batch
    await pool.query(
      `INSERT INTO allocation_batches (batch_id, semester, status, successfully_allocated, failed_allocations, total_sections, created_by)
       VALUES ($1, $2, 'Draft', 0, 0, 0, '00000000-0000-0000-0000-000000000000'::uuid)`,
      [batchId, semester]
    );

    // 2. Instantiate solver and run allocate
    const engine = new AllocationEngine(batchId, semester);
    const result = await engine.allocate();

    console.log('\n--- Solver Run Results ---');
    console.log(`Success Count: ${result.successCount}`);
    console.log(`Failure Count: ${result.failureCount}`);
    console.log(`Allocations Committed: ${result.allocations.length}`);
    console.log(`Conflicts Found: ${result.conflicts.length}`);

    if (result.successCount > 0) {
      console.log('✓ Backtracking solver successfully generated allocations!');
    }

    // Clean up
    await pool.query("DELETE FROM semester_allocations WHERE batch_id = $1", [batchId]);
    await pool.query("DELETE FROM allocation_conflicts WHERE batch_id = $1", [batchId]);
    await pool.query("DELETE FROM allocation_batches WHERE batch_id = $1", [batchId]);

    console.log('\n🎉 ALL BACKTRACKING TESTS PASSED!');
  } catch (err) {
    console.error('Test encountered an error:', err);
    process.exit(1);
  } finally {
    pool.end();
  }
}

runTest();
