import pool from './db';
import { promoteWaitlist, logAudit, createNotification } from './priorityEngine';

/**
 * Runs the auto-cancellation job for no-shows.
 * If faculty does not check in within the configured grace period (default 15 minutes),
 * the booking is auto-cancelled, and the slot is released.
 */
export async function runAutoCancelNoShow() {
  console.log('[Job: Auto-Cancel No-Show] Running scan...');
  try {
    // Get grace period from config
    const configRes = await pool.query(`SELECT config_value FROM system_config WHERE config_key = 'no_show_grace_period'`);
    let graceMinutes = 15; // default fallback
    if (configRes.rows.length > 0 && configRes.rows[0].config_value) {
      graceMinutes = parseInt(configRes.rows[0].config_value.minutes || '15', 10);
    }

    // Find active or confirmed bookings that started in the past (more than graceMinutes ago)
    // but have no check-in time and status is 'Confirmed'.
    const query = `
      SELECT b.*, c.room_number, f.full_name_en
      FROM bookings b
      JOIN classrooms c ON b.room_id = c.room_id
      JOIN faculty f ON b.faculty_id = f.faculty_id
      WHERE b.status = 'Confirmed'
        AND b.checkin_at IS NULL
        AND b.start_dt <= NOW() - ($1 * INTERVAL '1 minute')
        AND b.end_dt > NOW()
    `;

    const res = await pool.query(query, [graceMinutes]);

    if (res.rows.length === 0) {
      return 0;
    }

    console.log(`[Job: Auto-Cancel No-Show] Found ${res.rows.length} bookings to auto-cancel.`);

    for (const booking of res.rows) {
      // Update booking status
      await pool.query(
        `UPDATE bookings SET status = 'AutoCancelledNoShow', updated_at = CURRENT_TIMESTAMP WHERE booking_id = $1`,
        [booking.booking_id]
      );

      // Audit Log
      await logAudit(
        '00000000-0000-0000-0000-000000000000', // System user
        'System',
        'AUTO_CANCELLED_NO_SHOW',
        'Booking',
        booking.booking_id,
        'status',
        'Confirmed',
        'AutoCancelledNoShow'
      );

      // Send no-show notification
      await createNotification(
        booking.faculty_id,
        'NoShowCancel',
        'Email',
        `Booking ${booking.booking_request_id} Auto-Cancelled (No-Show)`,
        `Your confirmed booking for room ${booking.room_number} on ${new Date(booking.start_dt).toLocaleDateString()} was auto-cancelled because you did not check in within ${graceMinutes} minutes.`,
        booking.booking_id
      );

      // Trigger waitlist promotion
      await promoteWaitlist(booking.room_id, booking.start_dt, booking.end_dt);
    }

    return res.rows.length;
  } catch (err) {
    console.error('Error running Auto-Cancel No-Show job:', err);
    return 0;
  }
}

/**
 * Sends notifications/reminders 24 hours before a booking starts (NF-002)
 */
export async function runBookingReminders() {
  console.log('[Job: Booking Reminders] Running scan...');
  try {
    // Find bookings starting between 23 hours 50 mins and 24 hours from now
    // which do not have a sent reminder notification
    const query = `
      SELECT b.*, c.room_number, f.full_name_en
      FROM bookings b
      JOIN classrooms c ON b.room_id = c.room_id
      JOIN faculty f ON b.faculty_id = f.faculty_id
      WHERE b.status = 'Confirmed'
        AND b.start_dt BETWEEN NOW() + INTERVAL '23 hours 50 minutes' AND NOW() + INTERVAL '24 hours 10 minutes'
        AND NOT EXISTS (
          SELECT 1 FROM notifications n
          WHERE n.booking_id = b.booking_id
            AND n.type = 'ReminderDay'
        )
    `;

    const res = await pool.query(query);
    if (res.rows.length === 0) return 0;

    for (const booking of res.rows) {
      await createNotification(
        booking.faculty_id,
        'ReminderDay',
        'Email',
        `Upcoming Booking Reminder: Room ${booking.room_number}`,
        `Reminder: You have a confirmed booking for Room ${booking.room_number} tomorrow starting at ${new Date(booking.start_dt).toLocaleTimeString()}. Please remember to check in within 15 minutes of start.`,
        booking.booking_id
      );
    }

    return res.rows.length;
  } catch (err) {
    console.error('Error running Booking Reminders job:', err);
    return 0;
  }
}

// Start jobs in background interval (e.g. every 30 seconds for local dev)
export function startBackgroundJobs() {
  console.log('🔄 Background Jobs Engine spin-up...');
  setInterval(async () => {
    await runAutoCancelNoShow();
    await runBookingReminders();
  }, 30000); // every 30s
}
