import { Router, Request, Response } from 'express';
import pool from '../db';

const router = Router();

// POST /api/auth/login
router.post('/login', async (req: Request, res: Response) => {
  try {
    const { email, username, password } = req.body;
    const identifier = username || email;

    if (!identifier || !password) {
      return res.status(400).json({ error: 'Please enter email/username and password.' });
    }

    // 1. Admin login simulation
    if ((identifier === 'admin@university.edu' || identifier === 'admin') && password === 'admin123') {
      return res.json({
        user: {
          id: '00000000-0000-0000-0000-000000000000',
          name: 'Registrar Admin',
          email: 'admin@university.edu',
          username: 'admin',
          role: 'Admin'
        }
      });
    }

    // 2. Student login simulation
    if ((identifier === 'student@university.edu' || identifier === 'student') && password === 'student123') {
      return res.json({
        user: {
          id: 'student-anonymous',
          name: 'Student Public Timetable',
          email: 'student@university.edu',
          username: 'student',
          role: 'Student'
        }
      });
    }

    // 3. Query faculty members from database
    const facRes = await pool.query(
      `SELECT f.*
       FROM faculty f
       WHERE f.email = $1 OR f.username = $1`,
      [identifier]
    );

    if (facRes.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid email/username or password.' });
    }

    const faculty = facRes.rows[0];

    // Check password match (plain text fallback for proto/mock)
    if (faculty.password !== password) {
      return res.status(401).json({ error: 'Invalid email/username or password.' });
    }

    // Determine role (DeptHead if dept_head_flag is true)
    const role = faculty.dept_head_flag ? 'DeptHead' : 'Faculty';

    return res.json({
      user: {
        id: faculty.faculty_id,
        name: faculty.full_name_en,
        email: faculty.email,
        username: faculty.username,
        role,
        facultyDetails: {
          faculty_id: faculty.faculty_id,
          employee_id: faculty.employee_id,
          full_name_en: faculty.full_name_en,
          full_name_bn: faculty.full_name_bn,
          email: faculty.email,
          username: faculty.username,
          designation: faculty.designation,
          seniority_rank: faculty.seniority_rank,
          dept_head_flag: faculty.dept_head_flag
        }
      }
    });

  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

export default router;
