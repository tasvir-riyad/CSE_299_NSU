import { Router, Request, Response } from 'express';
import pool from '../db';
import { promoteWaitlist, logAudit, createNotification } from '../priorityEngine';
import { runAutoCancelNoShow, runBookingReminders } from '../jobs';
import { AllocationEngine } from '../allocationEngine';

const router = Router();

// POST /api/admin/override - Dept Head Override
router.post('/override', async (req: Request, res: Response) => {
  try {
    const { bookingId, overrideReason, deptHeadId } = req.body;

    if (!bookingId || !overrideReason || !deptHeadId) {
      return res.status(400).json({ error: 'Missing required parameters: bookingId, overrideReason, deptHeadId' });
    }

    // Check if the dept head exists and has dept_head_flag
    const deptHeadRes = await pool.query(`SELECT * FROM faculty WHERE faculty_id = $1`, [deptHeadId]);
    if (deptHeadRes.rowCount === 0 || !deptHeadRes.rows[0].dept_head_flag) {
      return res.status(403).json({ error: 'Only Department Heads can perform overrides.' });
    }
    const deptHead = deptHeadRes.rows[0];

    // Fetch booking details
    const bookingRes = await pool.query(
      `SELECT b.*, c.room_number FROM bookings b JOIN classrooms c ON b.room_id = c.room_id WHERE b.booking_id = $1`,
      [bookingId]
    );
    if (bookingRes.rowCount === 0) {
      return res.status(404).json({ error: 'Booking not found' });
    }
    const booking = bookingRes.rows[0];
    const prevStatus = booking.status;

    // Promote booking to Confirmed
    await pool.query(
      `UPDATE bookings SET status = 'Confirmed', updated_at = CURRENT_TIMESTAMP WHERE booking_id = $1`,
      [bookingId]
    );

    // Update waitlist entry to ManualOverridePromoted
    await pool.query(
      `UPDATE waitlist_entries SET status = 'ManualOverridePromoted', reason = $1 WHERE booking_id = $2`,
      [`Dept Head Override: ${overrideReason}`, bookingId]
    );

    // Audit log
    await logAudit(
      deptHeadId,
      'Department Head',
      'DEPT_HEAD_OVERRIDE_PROMOTED',
      'Booking',
      bookingId,
      'status',
      prevStatus,
      'Confirmed'
    );

    // Send notifications (promoted faculty and admin)
    await createNotification(
      booking.faculty_id,
      'OverrideApproved',
      'Email',
      `Department Override: Booking ${booking.booking_request_id} Confirmed`,
      `Your waitlisted booking for Room ${booking.room_number} on ${new Date(booking.start_dt).toLocaleDateString()} has been confirmed via Department Head Override.`,
      bookingId
    );

    // Send copy to admin (create a system notification or mock it)
    console.log(`[Override Alert] Dept Head ${deptHead.full_name_en} overrode waitlist for booking ${booking.booking_request_id}`);

    res.json({ message: 'Override applied successfully', status: 'Confirmed' });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/admin/maintenance - Mark room under maintenance
router.post('/maintenance', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { roomId, startDt, endDt, reason, adminId } = req.body;

    if (!roomId || !startDt || !endDt || !reason || !adminId) {
      return res.status(400).json({ error: 'Missing parameters roomId, startDt, endDt, reason, adminId' });
    }

    await client.query('BEGIN');

    // Create maintenance window
    const maintRes = await client.query(
      `INSERT INTO maintenance_windows (room_id, start_dt, end_dt, reason, created_by)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING maintenance_id`,
      [roomId, new Date(startDt), new Date(endDt), reason, adminId]
    );
    const maintenanceId = maintRes.rows[0].maintenance_id;

    // Fetch room name
    const roomRes = await client.query(`SELECT room_number FROM classrooms WHERE room_id = $1`, [roomId]);
    const roomNumber = roomRes.rows[0]?.room_number || 'Room';

    // Find and cancel all confirmed/pending bookings within window
    const cancelRes = await client.query(
      `SELECT b.*, f.email, f.faculty_id
       FROM bookings b
       JOIN faculty f ON b.faculty_id = f.faculty_id
       WHERE b.room_id = $1
         AND b.status IN ('Confirmed', 'Pending', 'PendingAdminApproval')
         AND b.start_dt < $3
         AND b.end_dt > $2`,
      [roomId, new Date(startDt), new Date(endDt)]
    );

    const affectedBookings = cancelRes.rows;

    for (const booking of affectedBookings) {
      // Set to CancelledByAdmin
      await client.query(
        `UPDATE bookings SET status = 'CancelledByAdmin', updated_at = CURRENT_TIMESTAMP WHERE booking_id = $1`,
        [booking.booking_id]
      );

      // Delete waitlist
      await client.query(`DELETE FROM waitlist_entries WHERE booking_id = $1`, [booking.booking_id]);

      // Audit log
      await logAudit(
        adminId,
        'Admin',
        'CANCELLED_DUE_TO_MAINTENANCE',
        'Booking',
        booking.booking_id,
        'status',
        booking.status,
        'CancelledByAdmin'
      );

      // Notification
      await createNotification(
        booking.faculty_id,
        'MaintenanceCancellation',
        'Email',
        `Urgent: Booking ${booking.booking_request_id} Cancelled`,
        `Your booking for Room ${roomNumber} on ${new Date(booking.start_dt).toLocaleDateString()} is cancelled because the room has been scheduled for maintenance. Reason: ${reason}`,
        booking.booking_id
      );
    }

    // Log maintenance audit
    await logAudit(
      adminId,
      'Admin',
      'ROOM_MAINTENANCE_SCHEDULED',
      'Classroom',
      roomId,
      'maintenance',
      null,
      { startDt, endDt, reason }
    );

    await client.query('COMMIT');

    res.json({
      message: `Room scheduled for maintenance. ${affectedBookings.length} booking(s) cancelled.`,
      maintenanceId,
      cancelledCount: affectedBookings.length,
    });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

// POST /api/admin/bulk-cancel - Emergency Bulk Cancellation
router.post('/bulk-cancel', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { buildingId, roomId, startDt, endDt, reason, adminId } = req.body;

    if (!startDt || !endDt || !reason || !adminId) {
      return res.status(400).json({ error: 'Missing startDt, endDt, reason, adminId' });
    }

    await client.query('BEGIN');

    let query = `
      SELECT b.*, c.room_number, f.faculty_id
      FROM bookings b
      JOIN classrooms c ON b.room_id = c.room_id
      JOIN faculty f ON b.faculty_id = f.faculty_id
      WHERE b.status IN ('Confirmed', 'Pending', 'PendingAdminApproval')
        AND b.start_dt < $2
        AND b.end_dt > $1
    `;
    const params: any[] = [new Date(startDt), new Date(endDt)];

    if (roomId) {
      query += ` AND b.room_id = $3`;
      params.push(roomId);
    } else if (buildingId) {
      query += ` AND c.building_id = $3`;
      params.push(buildingId);
    }

    const checkRes = await client.query(query, params);
    const bookingsToCancel = checkRes.rows;

    for (const booking of bookingsToCancel) {
      await client.query(
        `UPDATE bookings SET status = 'CancelledByAdmin', updated_at = CURRENT_TIMESTAMP WHERE booking_id = $1`,
        [booking.booking_id]
      );

      await client.query(`DELETE FROM waitlist_entries WHERE booking_id = $1`, [booking.booking_id]);

      await logAudit(
        adminId,
        'Admin',
        'BULK_CANCELLED_BY_ADMIN',
        'Booking',
        booking.booking_id,
        'status',
        booking.status,
        'CancelledByAdmin'
      );

      await createNotification(
        booking.faculty_id,
        'StatusChange',
        'Email',
        `Emergency cancellation for ${booking.booking_request_id}`,
        `Your booking for Room ${booking.room_number} on ${new Date(booking.start_dt).toLocaleDateString()} was cancelled due to bulk administrative action. Reason: ${reason}`,
        booking.booking_id
      );
    }

    await client.query('COMMIT');
    res.json({ message: `Bulk cancellation complete. Cancelled ${bookingsToCancel.length} bookings.`, cancelledCount: bookingsToCancel.length });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

// GET /api/admin/config - Get system configuration variables
router.get('/config', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(`SELECT * FROM system_config`);
    const configMap: any = {};
    result.rows.forEach((r) => {
      configMap[r.config_key] = r.config_value;
    });
    res.json(configMap);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// PUT /api/admin/config - Update system configuration variables
router.put('/config', async (req: Request, res: Response) => {
  try {
    const keys = Object.keys(req.body);
    for (const key of keys) {
      const rawVal = req.body[key];
      if (rawVal !== undefined) {
        let valObj: any = {};
        if (key.includes('booking_window')) {
          valObj = { days: String(rawVal) };
        } else if (key.includes('max_duration')) {
          valObj = { hours: String(rawVal) };
        } else if (key === 'no_show_grace_period') {
          valObj = { minutes: String(rawVal) };
        } else if (key === 'recurring_max_weeks') {
          valObj = { weeks: String(rawVal) };
        } else {
          valObj = { value: String(rawVal) };
        }
        await pool.query(
          `INSERT INTO system_config (config_key, config_value, last_updated_by)
           VALUES ($1, $2, '00000000-0000-0000-0000-000000000000')
           ON CONFLICT (config_key) DO UPDATE SET config_value = EXCLUDED.config_value, updated_at = CURRENT_TIMESTAMP`,
          [key, valObj]
        );
      }
    }
    res.json({ message: 'Configuration updated successfully' });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/admin/preference-window - Open or close the faculty preference collection window
router.post('/preference-window', async (req: Request, res: Response) => {
  try {
    const { open, deadline, semester, instructions } = req.body;
    if (typeof open !== 'boolean') {
      return res.status(400).json({ error: '"open" (boolean) is required' });
    }
    const value = {
      open,
      deadline: deadline || null,
      semester: semester || null,
      instructions: instructions || null,
      toggled_at: new Date().toISOString(),
    };
    await pool.query(
      `INSERT INTO system_config (config_key, config_value, last_updated_by)
       VALUES ('preference_window', $1, '00000000-0000-0000-0000-000000000000')
       ON CONFLICT (config_key) DO UPDATE SET config_value = EXCLUDED.config_value, updated_at = CURRENT_TIMESTAMP`,
      [value]
    );
    res.json({ message: open ? 'Preference window opened.' : 'Preference window closed.', preference_window: value });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/admin/preference-window - Get current preference window status (public endpoint for faculty)
router.get('/preference-window', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(
      `SELECT config_value FROM system_config WHERE config_key = 'preference_window'`
    );
    if (result.rowCount === 0) {
      return res.json({ open: false, deadline: null, semester: null, instructions: null, toggled_at: null });
    }
    res.json(result.rows[0].config_value);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/admin/run-jobs - Manual Trigger for Dev Testing
router.post('/run-jobs', async (req: Request, res: Response) => {
  try {
    const cancelledCount = await runAutoCancelNoShow();
    const remindersCount = await runBookingReminders();
    res.json({
      message: 'Background jobs run manually.',
      cancelledCount,
      remindersCount,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/admin/rooms - Create a single classroom
router.post('/rooms', async (req: Request, res: Response) => {
  try {
    const { room_number, building_code, floor, capacity, room_type, equipment } = req.body;
    if (!room_number || !building_code || !capacity || !room_type) {
      return res.status(400).json({ error: 'Missing required attributes.' });
    }
    
    const bldgRes = await pool.query('SELECT building_id FROM buildings WHERE building_code = $1', [building_code]);
    if (bldgRes.rowCount === 0) return res.status(404).json({ error: 'Building not found.' });
    const buildingId = bldgRes.rows[0].building_id;

    const result = await pool.query(
      `INSERT INTO classrooms (room_number, building_id, floor, capacity, room_type, equipment, operating_hours, status, photos)
       VALUES ($1, $2, $3, $4, $5, $6, '{}', 'Active', '{}') RETURNING *`,
      [room_number, buildingId, parseInt(floor, 10) || 1, parseInt(capacity, 10), room_type, equipment || {}]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// PUT /api/admin/rooms/:roomId - Edit classroom
router.put('/rooms/:roomId', async (req: Request, res: Response) => {
  try {
    const { roomId } = req.params;
    const { room_number, building_code, floor, capacity, room_type, equipment } = req.body;
    
    let buildingId = undefined;
    if (building_code) {
      const bldgRes = await pool.query('SELECT building_id FROM buildings WHERE building_code = $1', [building_code]);
      if (bldgRes.rowCount === 0) return res.status(404).json({ error: 'Building not found.' });
      buildingId = bldgRes.rows[0].building_id;
    }

    const result = await pool.query(
      `UPDATE classrooms SET 
        room_number = COALESCE($1, room_number),
        building_id = COALESCE($2, building_id),
        floor = COALESCE($3, floor),
        capacity = COALESCE($4, capacity),
        room_type = COALESCE($5, room_type),
        equipment = COALESCE($6, equipment)
       WHERE room_id = $7 RETURNING *`,
      [room_number, buildingId, floor, capacity, room_type, equipment, roomId]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// DELETE /api/admin/rooms/:roomId - Soft delete (Deactivate) classroom
router.delete('/rooms/:roomId', async (req: Request, res: Response) => {
  try {
    const { roomId } = req.params;
    const result = await pool.query(`UPDATE classrooms SET status = 'Inactive' WHERE room_id = $1 RETURNING *`, [roomId]);
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/admin/rooms/utilization - Calculate utilization stats (per day/week/month)
router.get('/rooms/utilization', async (req: Request, res: Response) => {
  try {
    const { period = 'week' } = req.query;
    let days = 7;
    if (period === 'day') days = 1;
    if (period === 'month') days = 30;

    const result = await pool.query(
      `SELECT r.room_id, r.room_number, r.capacity, r.room_type, r.building_id,
        COALESCE(
          (SELECT SUM(EXTRACT(EPOCH FROM (end_dt - start_dt))/3600)
           FROM bookings b 
           WHERE b.room_id = r.room_id 
             AND b.status = 'Confirmed' 
             AND b.start_dt >= CURRENT_DATE - ($1 || ' days')::interval
          ), 0
        ) as confirmed_hours,
        (14 * $1) as available_hours -- Defaulting to 14 hours a day (08:00 to 22:00)
       FROM classrooms r`,
      [days]
    );

    const utilization = result.rows.map(row => {
      const confirmed = parseFloat(row.confirmed_hours);
      const available = parseFloat(row.available_hours);
      return {
        ...row,
        utilization_rate: available > 0 ? ((confirmed / available) * 100).toFixed(1) : 0
      };
    });

    res.json(utilization);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/admin/import-rooms - Bulk import classrooms from template JSON (CI-006)
router.post('/import-rooms', async (req: Request, res: Response) => {
  try {
    const { rooms } = req.body; // array of room objects

    if (!Array.isArray(rooms)) {
      return res.status(400).json({ error: 'Invalid input. Expected an array of rooms under "rooms" key.' });
    }

    let imported = 0;
    const failures = [];

    // Get buildings list to validate building codes
    const buildingsRes = await pool.query(`SELECT building_id, building_code FROM buildings`);
    const bldgMap = new Map(buildingsRes.rows.map((b) => [b.building_code, b.building_id]));

    for (let i = 0; i < rooms.length; i++) {
      const room = rooms[i];
      const { room_number, building_code, floor, capacity, room_type, equipment } = room;

      if (!room_number || !building_code || !capacity || !room_type) {
        failures.push({ row: i + 1, reason: 'Missing required attributes (room_number, building_code, capacity, room_type).' });
        continue;
      }

      const buildingId = bldgMap.get(building_code);
      if (!buildingId) {
        failures.push({ row: i + 1, reason: `Building code "${building_code}" not found in database.` });
        continue;
      }

      try {
        await pool.query(
          `INSERT INTO classrooms (room_number, building_id, floor, capacity, room_type, equipment, operating_hours, status, photos)
           VALUES ($1, $2, $3, $4, $5, $6, '{}', 'Active', '{}')`,
          [room_number, buildingId, parseInt(floor, 10) || 1, parseInt(capacity, 10), room_type, equipment || {}]
        );
        imported++;
      } catch (err) {
        failures.push({ row: i + 1, reason: (err as Error).message });
      }
    }

    res.json({
      summary: `Bulk import completed: ${imported} imported, ${failures.length} failed.`,
      imported,
      failed: failures.length,
      failures,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/admin/audit-logs - Fetch Audit Trail
router.get('/audit-logs', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(
      `SELECT a.*, f.full_name_en as faculty_name
       FROM audit_logs a
       LEFT JOIN faculty f ON a.user_id = f.faculty_id
       ORDER BY a.timestamp DESC
       LIMIT 100`
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// ============================================
// BULK SEMESTER ALLOCATION ENDPOINTS
// ============================================

// POST /api/admin/allocate-semester - Bulk create course sections and auto-allocate
router.post('/allocate-semester', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { semester, adminId, courses } = req.body;

    if (!semester || !adminId || !Array.isArray(courses) || courses.length === 0) {
      return res.status(400).json({ error: 'Missing semester, adminId, or courses array' });
    }

    await client.query('BEGIN');

    // 1. Create course sections from input first to get the correct count
    let totalPlaceholderSections = 0;
    const insertedSections = [];

    for (const course of courses) {
      const { courseCode, courseName, departmentId, numSections, enrollmentPerSection, facilityType } = course;

      if (!courseCode) {
        throw new Error(`Invalid course data: missing courseCode`);
      }

      const count = parseInt(String(numSections), 10) || 1;
      const enrollment = parseInt(String(enrollmentPerSection), 10) || 40;

      // Insert or update course
      const courseRes = await client.query(
        `INSERT INTO courses (course_code, course_name)
         VALUES ($1, $2)
         ON CONFLICT (course_code) DO UPDATE SET course_name = EXCLUDED.course_name
         RETURNING course_id`,
        [courseCode, courseName || courseCode]
      );

      const courseId = courseRes.rows[0].course_id;

      // Insert course section placeholders
      for (let i = 1; i <= count; i++) {
        const secNum = String(i).padStart(2, '0');
        const secRes = await client.query(
          `INSERT INTO course_sections (course_id, semester, section_number, enrollment_size, day_of_week, start_time, end_time, facility_type)
           VALUES ($1, $2, $3, $4, NULL, NULL, NULL, $5)
           ON CONFLICT (course_id, semester, section_number) DO UPDATE
           SET enrollment_size = EXCLUDED.enrollment_size
           RETURNING *`,
          [
            courseId,
            semester,
            secNum,
            enrollment,
            facilityType || 'Lecture',
          ]
        );
        insertedSections.push(secRes.rows[0]);
        totalPlaceholderSections++;
      }
    }

    // 2. Create allocation batch
    const batchRes = await client.query(
      `INSERT INTO allocation_batches (semester, created_by, status, total_sections)
       VALUES ($1, $2, 'Processing', $3)
       RETURNING batch_id`,
      [semester, adminId, totalPlaceholderSections]
    );

    const batchId = batchRes.rows[0].batch_id;
    console.log(`[API] Created allocation batch ${batchId} for semester ${semester} with ${totalPlaceholderSections} sections`);

    await client.query('COMMIT');

    // 3. Run allocation engine
    const engine = new AllocationEngine(batchId, semester);
    const result = await engine.allocate();

    // 4. Audit log
    await logAudit(
      adminId,
      'Admin',
      'SEMESTER_ALLOCATION_CREATED',
      'AllocationBatch',
      batchId,
      'status',
      null,
      'Processing'
    );

    res.status(201).json({
      batchId,
      semester,
      message: `Allocation complete: ${result.successCount} allocated, ${result.failureCount} conflicts`,
      successCount: result.successCount,
      failureCount: result.failureCount,
      allocations: result.allocations,
      conflicts: result.conflicts,
    });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

// GET /api/admin/allocations/batch/:batchId - Fetch allocation details
router.get('/allocations/batch/:batchId', async (req: Request, res: Response) => {
  try {
    const { batchId } = req.params;

    // Fetch batch info
    const batchRes = await pool.query(`SELECT * FROM allocation_batches WHERE batch_id = $1`, [batchId]);

    if (batchRes.rows.length === 0) {
      return res.status(404).json({ error: 'Batch not found' });
    }

    // Fetch allocations
    const allocRes = await pool.query(
      `SELECT sa.*, cs.section_number, c.course_code, c.course_name, cl.room_number, cl.capacity, 
              COALESCE(f.full_name_en, sa.allocated_faculty_name) as allocated_faculty_name, 
              COALESCE(f.designation::text, sa.allocated_faculty_email) as allocated_faculty_designation
       FROM semester_allocations sa
       JOIN course_sections cs ON sa.section_id = cs.section_id
       JOIN courses c ON cs.course_id = c.course_id
       JOIN classrooms cl ON sa.room_id = cl.room_id
       LEFT JOIN faculty f ON sa.allocated_faculty_id = f.faculty_id
       WHERE sa.batch_id = $1
       ORDER BY sa.created_at`,
      [batchId]
    );

    // Fetch conflicts
    const conflictRes = await pool.query(
      `SELECT ac.*, c.course_code, cs.section_number
       FROM allocation_conflicts ac
       JOIN course_sections cs ON ac.section_id = cs.section_id
       JOIN courses c ON cs.course_id = c.course_id
       WHERE ac.batch_id = $1
       ORDER BY ac.created_at`,
      [batchId]
    );

    res.json({
      batch: batchRes.rows[0],
      allocations: allocRes.rows,
      conflicts: conflictRes.rows,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// PUT /api/admin/allocation/:allocationId - Manually adjust allocation
router.put('/allocation/:allocationId', async (req: Request, res: Response) => {
  try {
    const { allocationId } = req.params;
    const { roomId, dayOfWeek, startTime, endTime, facultyId, adminId } = req.body;

    if (!roomId || dayOfWeek === null || dayOfWeek === undefined || !startTime || !endTime) {
      return res.status(400).json({ error: 'Missing roomId, dayOfWeek, startTime, or endTime' });
    }

    if (startTime >= endTime) {
      return res.status(400).json({ error: 'Start time must be strictly before end time.' });
    }

    // Resolve faculty name/designation if provided
    let facultyName: string | null = null;
    let facultyEmail: string | null = null;
    if (facultyId) {
      const fRes = await pool.query(`SELECT full_name_en, email, designation FROM faculty WHERE faculty_id = $1`, [facultyId]);
      if (fRes.rows.length > 0) {
        facultyName = fRes.rows[0].full_name_en;
        facultyEmail = fRes.rows[0].email;
      }
    }

    // Update allocation
    const result = await pool.query(
      `UPDATE semester_allocations
       SET room_id = $1, allocated_day_of_week = $2, allocated_start_time = $3, allocated_end_time = $4,
           allocated_faculty_id = $5, allocated_faculty_name = $6, allocated_faculty_email = $7,
           allocation_reason = 'Manual admin override'
       WHERE allocation_id = $8
       RETURNING *`,
      [roomId, dayOfWeek, startTime, endTime, facultyId || null, facultyName, facultyEmail, allocationId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Allocation not found' });
    }

    // Audit log
    await logAudit(
      adminId || '00000000-0000-0000-0000-000000000000',
      'Admin',
      'ALLOCATION_ADJUSTED',
      'Allocation',
      allocationId as string,
      'room_id, times, faculty',
      null,
      `Room ${roomId}, Day ${dayOfWeek}, ${startTime}-${endTime}, Faculty: ${facultyName || 'TBA'}`
    );

    res.json({ message: 'Allocation updated', allocation: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});


// POST /api/admin/confirm-allocation/:batchId - Confirm and create bookings
router.post('/confirm-allocation/:batchId', async (req: Request, res: Response) => {
  try {
    const { batchId } = req.params;
    const { adminId } = req.body;

    if (!adminId) {
      return res.status(400).json({ error: 'Missing adminId' });
    }

    const engine = new AllocationEngine(batchId as string, '');
    const result = await engine.confirmAllocation(adminId);

    // Audit log
    await logAudit(adminId, 'Admin', 'SEMESTER_ALLOCATION_CONFIRMED', 'AllocationBatch', batchId as string, 'status', 'ReviewConflicts', 'Confirmed');

    res.json({
      message: `Allocation confirmed: ${result.confirmedBookings} bookings created`,
      confirmedBookings: result.confirmedBookings,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/admin/allocations/export/:batchId - Export schedule as CSV
router.get('/allocations/export/:batchId', async (req: Request, res: Response) => {
  try {
    const { batchId } = req.params;

    const result = await pool.query(
      `SELECT c.course_code, cs.section_number, cs.enrollment_size, cl.room_number, cl.capacity, 
              sa.allocated_day_of_week, sa.allocated_start_time, sa.allocated_end_time
       FROM semester_allocations sa
       JOIN course_sections cs ON sa.section_id = cs.section_id
       JOIN courses c ON cs.course_id = c.course_id
       JOIN classrooms cl ON sa.room_id = cl.room_id
       WHERE sa.batch_id = $1
       ORDER BY c.course_code, cs.section_number`,
      [batchId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'No allocations found' });
    }

    // Generate CSV
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const headers = ['Course Code', 'Section', 'Enrollment', 'Room Number', 'Room Capacity', 'Day', 'Start Time', 'End Time'];
    const rows = result.rows.map((r) => [
      r.course_code,
      r.section_number,
      r.enrollment_size,
      r.room_number,
      r.capacity,
      dayNames[r.allocated_day_of_week],
      r.allocated_start_time,
      r.allocated_end_time,
    ]);

    const csv = [headers, ...rows].map((row) => row.map((cell) => `"${cell}"`).join(',')).join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="allocation-${batchId}.csv"`);
    res.send(csv);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/admin/allocations/batches - Fetch all allocation batches
router.get('/allocations/batches', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(
      `SELECT ab.*, f.full_name_en as creator_name
       FROM allocation_batches ab
       LEFT JOIN faculty f ON ab.created_by = f.faculty_id
       ORDER BY ab.created_at DESC`
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});


// POST /api/admin/allocation/batch/:batchId/resolve-all - Auto-resolve all conflicts
// POST /api/admin/publish-timetable/:batchId - Set a batch as the global active timetable
router.post('/publish-timetable/:batchId', async (req: Request, res: Response) => {
  const { batchId } = req.params;
  try {
    // 1. Unpublish all other batches
    await pool.query(
      `UPDATE allocation_batches SET is_published = false`
    );
    // 2. Publish the requested batch
    const result = await pool.query(
      `UPDATE allocation_batches SET is_published = true WHERE batch_id = $1 RETURNING *`,
      [batchId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Batch not found' });
    }
    
    res.json({ message: 'Timetable published successfully', batch: result.rows[0] });
  } catch (error) {
    console.error('Error publishing timetable:', error);
    res.status(500).json({ error: 'Failed to publish timetable' });
  }
});

router.post('/allocation/batch/:batchId/resolve-all', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { batchId } = req.params;
    const adminId = req.body.adminId || null;

    if (!batchId) return res.status(400).json({ error: 'Missing batchId' });

    await client.query('BEGIN');

    // 1. Fetch unresolved conflicts
    
    const TIMES = [
      { start: "08:00", end: "09:30" },
      { start: "09:40", end: "11:10" },
      { start: "11:20", end: "12:50" },
      { start: "13:00", end: "14:30" },
      { start: "14:40", end: "16:10" },
      { start: "16:20", end: "17:50" },
      { start: "18:00", end: "19:30" },
      { start: "19:40", end: "21:10" },
    ];
    const THEORY_SLOTS = [
      ...TIMES.map(t => ({ days: [0, 2], start: t.start, end: t.end })),
      ...TIMES.map(t => ({ days: [1, 3], start: t.start, end: t.end })),
      ...TIMES.map(t => ({ days: [4, 6], start: t.start, end: t.end })),
    ];
    const LAB_SLOTS: {days: number[], start: string, end: string}[] = [];
    [0, 1, 2, 3, 4, 6].forEach(day => {
      TIMES.forEach(t => LAB_SLOTS.push({ days: [day], start: t.start, end: t.end }));
    });

    // We also need course info for each conflict to know if it's a lab
    // We can join course_sections when fetching conflicts
    const conflictsRes = await client.query(
      `SELECT c.*, cs.facility_type, co.course_code 
       FROM allocation_conflicts c
       JOIN course_sections cs ON c.section_id = cs.section_id
       JOIN courses co ON cs.course_id = co.course_id
       WHERE c.batch_id = $1`,
      [batchId]
    );

    const conflicts = conflictsRes.rows;
    if (conflicts.length === 0) {
      await client.query('COMMIT');
      return res.json({ success: true, resolvedCount: 0 });
    }

    const allocationsRes = await client.query('SELECT * FROM semester_allocations WHERE batch_id = $1', [batchId]);
    const allocations = allocationsRes.rows;

    const roomsRes = await client.query("SELECT * FROM classrooms WHERE status = 'Active' ORDER BY room_number");
    const rooms = roomsRes.rows;
    let resolvedCount = 0;
  

    for (const conflict of conflicts) {
      let foundSlot = false;

      
      const isLab = conflict.facility_type === 'Lab' || conflict.course_code.endsWith('L');
      const slotsToUse = isLab ? LAB_SLOTS : THEORY_SLOTS;
      
      for (const room of rooms) {
        if (foundSlot) break;
        
        for (const slot of slotsToUse) {
          if (foundSlot) break;
          
          let allDaysAvailable = true;
          for (const day of slot.days) {
            const overlap = allocations.find(a => {
              if (a.room_id !== room.room_id) return false;
              if (a.allocated_day_of_week !== day) return false;
              const aStart = (a.allocated_start_time || '').substring(0, 5);
              const aEnd = (a.allocated_end_time || '').substring(0, 5);
              return slot.start < aEnd && slot.end > aStart;
            });
            if (overlap) {
              allDaysAvailable = false;
              break;
            }
          }

          if (allDaysAvailable) {
            await client.query(
              `INSERT INTO semester_allocations 
               (batch_id, section_id, room_id, allocated_day_of_week, allocated_start_time, allocated_end_time, allocation_reason, status)
               VALUES ($1, $2, $3, $4, $5, $6, $7, 'Allocated')`,
              [batchId, conflict.section_id, room.room_id, slot.days[0], slot.start, slot.end, 'Auto-resolved via Resolve All']
            );

            await client.query('DELETE FROM allocation_conflicts WHERE conflict_id = $1', [conflict.conflict_id]);

            if (adminId) {
              await logAudit(adminId, 'Admin', 'AUTO_RESOLVE_CONFLICT', 'AllocationBatch', batchId as string, 'conflict_id', conflict.conflict_id, 'Resolved');
            }

            // Since it might be multiple days for theory, push all days to memory
            for (const day of slot.days) {
              allocations.push({
                batch_id: batchId,
                section_id: conflict.section_id,
                room_id: room.room_id,
                allocated_day_of_week: day,
                allocated_start_time: slot.start + ':00',
                allocated_end_time: slot.end + ':00'
              });
            }

            resolvedCount++;
            foundSlot = true;
            break; 
          }
        }
      }

    }

    // Update batch stats
    await client.query(
      `UPDATE allocation_batches 
       SET successfully_allocated = (SELECT COUNT(*) FROM semester_allocations WHERE batch_id = $1),
           failed_allocations = (SELECT COUNT(*) FROM allocation_conflicts WHERE batch_id = $1),
           updated_at = NOW()
       WHERE batch_id = $1`,
      [batchId]
    );

    await client.query('COMMIT');
    res.json({ success: true, resolvedCount });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

// POST /api/admin/allocation/resolve-conflict - Manually resolve a conflict by allocating a room & slot
router.post('/allocation/resolve-conflict', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { batchId, sectionId, roomId, dayOfWeek, startTime, endTime, adminId } = req.body;

    if (!batchId || !sectionId || !roomId || dayOfWeek === null || dayOfWeek === undefined || !startTime || !endTime) {
      return res.status(400).json({ error: 'Missing batchId, sectionId, roomId, dayOfWeek, startTime, or endTime' });
    }

    if (startTime >= endTime) {
      return res.status(400).json({ error: 'Start time must be strictly before end time.' });
    }

    await client.query('BEGIN');

    // Check for overlap in other semester_allocations for this batch
    const overlapAllocRes = await client.query(
      `SELECT * FROM semester_allocations
       WHERE batch_id = $1
         AND room_id = $2
         AND allocated_day_of_week = $3
         AND allocated_start_time < $5
         AND allocated_end_time > $4`,
      [batchId, roomId, dayOfWeek, startTime, endTime]
    );

    if (overlapAllocRes.rows.length > 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Overlap detected: The classroom is already manually allocated to another section in this slot.' });
    }

    // Check for overlap in active/confirmed bookings
    const overlapBookingRes = await client.query(
      `SELECT b.* FROM bookings b
       WHERE b.room_id = $1
         AND b.status IN ('Confirmed', 'Pending', 'PendingAdminApproval')
         AND EXTRACT(DOW FROM b.start_dt AT TIME ZONE 'Asia/Dhaka') = $2
         AND (b.start_dt AT TIME ZONE 'Asia/Dhaka')::time < $4::time
         AND (b.end_dt AT TIME ZONE 'Asia/Dhaka')::time > $3::time`,
      [roomId, dayOfWeek, startTime, endTime]
    );

    if (overlapBookingRes.rows.length > 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Overlap detected: The classroom is already booked for a confirmed/pending routine in this slot.' });
    }

    // 1. Delete from allocation_conflicts
    const deleteRes = await client.query(
      `DELETE FROM allocation_conflicts WHERE batch_id = $1 AND section_id = $2`,
      [batchId, sectionId]
    );

    // 2. Insert into semester_allocations
    const allocRes = await client.query(
      `INSERT INTO semester_allocations (batch_id, section_id, room_id, allocated_day_of_week, allocated_start_time, allocated_end_time, status, allocation_reason)
       VALUES ($1, $2, $3, $4, $5, $6, 'Allocated', 'Conflict manually resolved by admin')
       RETURNING *`,
      [batchId, sectionId, roomId, dayOfWeek, startTime, endTime]
    );

    // 3. Update allocation_batches stats: increment success, decrement failure
    await client.query(
      `UPDATE allocation_batches
       SET successfully_allocated = successfully_allocated + 1,
           failed_allocations = GREATEST(0, failed_allocations - 1)
       WHERE batch_id = $1`,
      [batchId]
    );

    // 4. Audit log
    await logAudit(
      adminId || '00000000-0000-0000-0000-000000000000',
      'Admin',
      'ALLOCATION_CONFLICT_RESOLVED',
      'Allocation',
      allocRes.rows[0].allocation_id,
      'status, room_id',
      'Conflict',
      'Allocated'
    );

    await client.query('COMMIT');
    res.json({ message: 'Conflict resolved successfully', allocation: allocRes.rows[0] });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

// POST /api/admin/approve-booking - Explicit Admin Approval for bookings in PendingAdminApproval state
router.post('/approve-booking', async (req: Request, res: Response) => {
  try {
    const { bookingId, adminId } = req.body;

    if (!bookingId || !adminId) {
      return res.status(400).json({ error: 'Missing bookingId or adminId' });
    }

    // Fetch booking details
    const bookingRes = await pool.query(
      `SELECT b.*, c.room_number FROM bookings b JOIN classrooms c ON b.room_id = c.room_id WHERE b.booking_id = $1`,
      [bookingId]
    );

    if (bookingRes.rows.length === 0) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    const booking = bookingRes.rows[0];
    const prevStatus = booking.status;

    if (prevStatus !== 'PendingAdminApproval') {
      return res.status(400).json({ error: `Booking status is ${prevStatus}. Only PendingAdminApproval requests can be approved.` });
    }

    // No-Bump Policy (PA-008): Ensure there are no overlapping confirmed bookings
    const overlapRes = await pool.query(
      `SELECT booking_id FROM bookings 
       WHERE room_id = $1 
         AND status = 'Confirmed' 
         AND start_dt < $3 
         AND end_dt > $2 
         AND booking_id <> $4`,
      [booking.room_id, booking.start_dt, booking.end_dt, bookingId]
    );

    if ((overlapRes.rowCount ?? 0) > 0) {
      return res.status(400).json({ error: 'No-Bump Policy (PA-008) Violation: Cannot approve this request because there is already a confirmed booking for this room in the requested time slot. Please reject or waitlist this request to protect confirmed faculty.' });
    }

    // Update status to Confirmed
    await pool.query(
      `UPDATE bookings SET status = 'Confirmed', updated_at = CURRENT_TIMESTAMP WHERE booking_id = $1`,
      [bookingId]
    );

    // Audit log
    await logAudit(
      adminId,
      'Admin',
      'ADMIN_APPROVED_BOOKING',
      'Booking',
      bookingId,
      'status',
      prevStatus,
      'Confirmed'
    );

    // Send notification
    await createNotification(
      booking.faculty_id,
      'StatusChange',
      'Email',
      `Booking ${booking.booking_request_id} Approved`,
      `Your booking request for Room ${booking.room_number} on ${new Date(booking.start_dt).toLocaleDateString()} has been approved and confirmed by the Administrator.`,
      bookingId
    );

    res.json({ message: 'Booking approved and confirmed successfully', status: 'Confirmed' });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/admin/assign-department-course - Assign faculty directly to a section (Department choice)
router.post('/assign-department-course', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { sectionId, facultyId } = req.body;

    if (!sectionId) {
      return res.status(400).json({ error: 'Missing sectionId' });
    }

    await client.query('BEGIN');

    // 0. Validation: Check if faculty is already assigned to a conflicting section
    if (facultyId) {
      const targetRes = await client.query(`SELECT semester, day_of_week, start_time, end_time FROM course_sections WHERE section_id = $1`, [sectionId]);
      if (targetRes.rowCount === 0) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: 'Course section not found' });
      }
      const target = targetRes.rows[0];

      if (target.day_of_week && target.start_time && target.end_time) {
        const overlapRes = await client.query(
          `SELECT c.course_code, cs.section_number 
           FROM course_sections cs
           JOIN courses c ON cs.course_id = c.course_id
           WHERE cs.assigned_faculty_id = $1
             AND cs.semester = $2
             AND cs.section_id != $3
             AND cs.day_of_week && $4
             AND (cs.start_time < $5 AND cs.end_time > $6)`,
          [facultyId, target.semester, sectionId, target.day_of_week, target.end_time, target.start_time]
        );

        if (overlapRes.rowCount && overlapRes.rowCount > 0) {
          await client.query('ROLLBACK');
          const overlap = overlapRes.rows[0];
          return res.status(409).json({ error: `Faculty is already mandated for ${overlap.course_code} Sec ${overlap.section_number} at this time.` });
        }
      }
    }

    // 1. Update assigned_faculty_id in course_sections
    const result = await client.query(
      `UPDATE course_sections
       SET assigned_faculty_id = $1, updated_at = CURRENT_TIMESTAMP
       WHERE section_id = $2
       RETURNING *`,
      [facultyId || null, sectionId]
    );

    if (result.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Course section not found' });
    }

    // 2. Fetch faculty details to cascade changes
    let facultyName = null;
    let facultyEmail = null;
    if (facultyId) {
      const facRes = await client.query(`SELECT full_name_en, email FROM faculty WHERE faculty_id = $1`, [facultyId]);
      if (facRes.rowCount && facRes.rowCount > 0) {
        facultyName = facRes.rows[0].full_name_en;
        facultyEmail = facRes.rows[0].email;
      }
    }

    // 3. Update existing draft or confirmed semester allocations for this section
    const allocRes = await client.query(
      `UPDATE semester_allocations
       SET allocated_faculty_id = $1, allocated_faculty_name = $2, allocated_faculty_email = $3
       WHERE section_id = $4
       RETURNING allocation_id`,
      [facultyId || null, facultyName, facultyEmail, sectionId]
    );

    // 4. Cascade to active/confirmed bookings tied to these allocations
    if (allocRes.rowCount && allocRes.rowCount > 0) {
      const allocationIds = allocRes.rows.map(r => r.allocation_id);
      await client.query(
        `UPDATE bookings
         SET faculty_id = $1, faculty_name = $2, faculty_email = $3
         WHERE series_id = ANY($4::uuid[]) AND status IN ('Confirmed', 'Draft')`,
        [facultyId || null, facultyName, facultyEmail, allocationIds]
      );
    }

    await client.query('COMMIT');
    res.json({ message: 'Course section assigned successfully and propagated to allocations/bookings', section: result.rows[0] });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

// GET /api/admin/pull-summary?semester=xxx — One-shot data summary for the Create Batch panel
router.get('/pull-summary', async (req: Request, res: Response) => {
  try {
    const { semester } = req.query;
    const sem = semester as string || '';

    // Count course sections for this semester
    const sectionsRes = await pool.query(
      `SELECT COUNT(*) AS total_sections,
              SUM(enrollment_size) AS total_enrollment,
              COUNT(CASE WHEN assigned_faculty_id IS NOT NULL THEN 1 END) AS sections_with_faculty,
              COUNT(DISTINCT course_id) AS unique_courses
       FROM course_sections
       WHERE semester = $1`,
      [sem]
    );

    // Count faculty preferences for this semester
    const prefsRes = await pool.query(
      `SELECT COUNT(DISTINCT p.faculty_email) AS faculty_submitted,
              COUNT(*) AS total_choices
       FROM faculty_course_preferences p
       JOIN course_sections cs ON p.section_id = cs.section_id
       WHERE cs.semester = $1`,
      [sem]
    );

    // Count available classrooms
    const roomsRes = await pool.query(
      `SELECT COUNT(*) AS total_rooms,
              SUM(capacity) AS total_seats,
              COUNT(CASE WHEN room_type = 'Lab' THEN 1 END) AS lab_rooms,
              COUNT(CASE WHEN room_type != 'Lab' THEN 1 END) AS lecture_rooms
       FROM classrooms
       WHERE status = 'Available'`
    );

    res.json({
      semester: sem,
      sections: sectionsRes.rows[0],
      preferences: prefsRes.rows[0],
      classrooms: roomsRes.rows[0],
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/admin/pull-preferences?semester=xxx — Pull all faculty preference choices for allocation
router.get('/pull-preferences', async (req: Request, res: Response) => {
  try {
    const { semester } = req.query;
    const sem = semester as string || '';

    const result = await pool.query(
      `SELECT p.faculty_email, p.faculty_name, p.faculty_designation, p.seniority_rank,
              p.choice_rank, cs.section_number, c.course_code, c.course_name, cs.semester,
              cs.enrollment_size, cs.start_time, cs.end_time, cs.day_of_week,
              cl.room_number AS preferred_room
       FROM faculty_course_preferences p
       JOIN course_sections cs ON p.section_id = cs.section_id
       JOIN courses c ON cs.course_id = c.course_id
       LEFT JOIN classrooms cl ON p.preferred_room_id = cl.room_id
       WHERE cs.semester = $1
       ORDER BY p.seniority_rank ASC, p.faculty_name ASC, p.choice_rank ASC`,
      [sem]
    );

    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/admin/course-sections - Retrieve all course sections with assignments
router.get('/course-sections', async (req: Request, res: Response) => {
  try {
    const { semester } = req.query;
    const result = await pool.query(
      `SELECT cs.*, c.course_code, c.course_name, 
              f.full_name_en as assigned_faculty_name, 
              f.designation::text as assigned_faculty_designation,
              cr.room_number
       FROM course_sections cs
       JOIN courses c ON cs.course_id = c.course_id
       LEFT JOIN faculty f ON cs.assigned_faculty_id = f.faculty_id
       LEFT JOIN (
           SELECT sa.section_id, sa.room_id, ROW_NUMBER() OVER(PARTITION BY sa.section_id ORDER BY ab.is_published DESC, ab.created_at DESC) as rn
           FROM semester_allocations sa
           JOIN allocation_batches ab ON sa.batch_id = ab.batch_id
       ) latest_alloc ON latest_alloc.section_id = cs.section_id AND latest_alloc.rn = 1
       LEFT JOIN classrooms cr ON latest_alloc.room_id = cr.room_id
       WHERE cs.semester = $1
       ORDER BY c.course_code ASC, cs.section_number ASC`,
      [semester || 'Spring2026']
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/admin/import-preferences - Bulk import faculty preferences
router.post('/import-preferences', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { preferences, semester } = req.body;

    if (!Array.isArray(preferences)) {
      return res.status(400).json({ error: 'Preferences must be an array' });
    }

    const targetSemester = semester || 'Spring2026';
    await client.query('BEGIN');

    let imported = 0;
    const failures = [];

    for (const pref of preferences) {
      const { email, name, designation, courseCode, section, choiceRank, roomNumber } = pref;

      const facRes = await client.query(
        `SELECT faculty_id, designation FROM faculty WHERE LOWER(email) = LOWER($1) OR LOWER(full_name_en) = LOWER($1)`,
        [email]
      );

      const facultyId = facRes.rows.length > 0 ? facRes.rows[0].faculty_id : null;
      let finalDesignation = designation || null;
      if (facRes.rows.length > 0 && !finalDesignation) {
        finalDesignation = facRes.rows[0].designation;
      }

      let seniorityRank = 4; // default Lecturer
      if (finalDesignation) {
        const desLower = finalDesignation.toLowerCase();
        if (desLower.includes('professor') && !desLower.includes('assistant') && !desLower.includes('associate')) {
          seniorityRank = 1;
        } else if (desLower.includes('associate')) {
          seniorityRank = 2;
        } else if (desLower.includes('assistant')) {
          seniorityRank = 3;
        }
      }

      const secRes = await client.query(
        `SELECT cs.section_id 
         FROM course_sections cs
         JOIN courses c ON cs.course_id = c.course_id
         WHERE c.course_code = $1 AND cs.section_number = $2 AND cs.semester = $3`,
        [courseCode, section, targetSemester]
      );

      if (secRes.rows.length === 0) {
        failures.push({ email, courseCode, section, error: 'Course section not found' });
        continue;
      }
      const sectionId = secRes.rows[0].section_id;

      let preferredRoomId = null;
      if (roomNumber) {
        const roomRes = await client.query(
          `SELECT room_id FROM classrooms WHERE LOWER(room_number) = LOWER($1)`,
          [roomNumber]
        );
        if (roomRes.rows.length > 0) {
          preferredRoomId = roomRes.rows[0].room_id;
        }
      }

      await client.query(
        `DELETE FROM faculty_course_preferences WHERE LOWER(faculty_email) = LOWER($1) AND choice_rank = $2`,
        [email, choiceRank || 1]
      );

      await client.query(
        `INSERT INTO faculty_course_preferences (faculty_id, faculty_email, section_id, choice_rank, preferred_room_id, faculty_name, faculty_designation, seniority_rank)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         ON CONFLICT (faculty_email, section_id) DO UPDATE SET 
           choice_rank = EXCLUDED.choice_rank, 
           preferred_room_id = EXCLUDED.preferred_room_id,
           faculty_name = EXCLUDED.faculty_name,
           faculty_designation = EXCLUDED.faculty_designation,
           seniority_rank = EXCLUDED.seniority_rank,
           faculty_id = EXCLUDED.faculty_id`,
        [facultyId, email, sectionId, choiceRank || 1, preferredRoomId, name || 'Faculty Member', finalDesignation || 'Lecturer', seniorityRank]
      );

      imported++;
    }

    await client.query('COMMIT');
    res.json({
      message: `Successfully imported ${imported} preferences.`,
      imported,
      failures
    });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

// POST /api/admin/faculty - Create a new faculty profile
router.post('/faculty', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { 
      employee_id, full_name_en, full_name_bn, email, 
      designation, seniority_rank, dept_head_flag, 
      joining_date, password, username 
    } = req.body;

    // Default joining date if none provided (optional field)
    const finalJoiningDate = joining_date ? joining_date : null;

    const result = await client.query(
      `INSERT INTO faculty (
        employee_id, full_name_en, full_name_bn, email, designation, 
        seniority_rank, dept_head_flag, joining_date, password, username
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING faculty_id`,
      [
        employee_id, full_name_en, full_name_bn, email, designation,
        seniority_rank, dept_head_flag || false, finalJoiningDate, 
        password || 'password123', username
      ]
    );

    res.json({ success: true, faculty_id: result.rows[0].faculty_id, message: 'Faculty profile created successfully' });
  } catch (err) {
    if ((err as any).constraint === 'faculty_email_key') {
      res.status(400).json({ error: 'Email already exists.' });
    } else if ((err as any).constraint === 'faculty_employee_id_key') {
      res.status(400).json({ error: 'Employee ID already exists.' });
    } else if ((err as any).constraint === 'faculty_username_key') {
      res.status(400).json({ error: 'Username already exists.' });
    } else {
      res.status(500).json({ error: (err as Error).message });
    }
  } finally {
    client.release();
  }
});

// GET /api/admin/analytics
router.get('/analytics', async (req, res) => {
  try {
    const buildingRes = await pool.query(`
      SELECT b.building_code, COUNT(bk.booking_id) as total_bookings
      FROM classrooms r
      JOIN buildings b ON r.building_id = b.building_id
      LEFT JOIN bookings bk ON bk.room_id = r.room_id AND bk.status = 'Confirmed'
      GROUP BY b.building_code
    `);
    
    // Get last 7 days bookings count by date
    const trendRes = await pool.query(`
      SELECT TO_CHAR(DATE(start_dt), 'YYYY-MM-DD') as date, COUNT(*) as count
      FROM bookings
      WHERE start_dt >= CURRENT_DATE - INTERVAL '7 days'
      AND start_dt < CURRENT_DATE + INTERVAL '1 day'
      AND status = 'Confirmed'
      GROUP BY TO_CHAR(DATE(start_dt), 'YYYY-MM-DD')
      ORDER BY date ASC
    `);

    // Get today's breakdown (Confirmed vs pending vs waitlisted)
    const statusRes = await pool.query(`
      SELECT status, COUNT(*) as count
      FROM bookings
      WHERE DATE(start_dt) = CURRENT_DATE
      GROUP BY status
    `);

    res.json({
      buildingVolume: buildingRes.rows,
      bookingTrends: trendRes.rows,
      todayStatus: statusRes.rows
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// DELETE /api/admin/allocations/batches/:batchId
router.delete('/allocations/batches/:batchId', async (req, res) => {
  const client = await pool.connect();
  try {
    const { batchId } = req.params;
    await client.query('BEGIN');

    // Fetch batch details first
    const batchRes = await client.query('SELECT * FROM allocation_batches WHERE batch_id = $1', [batchId]);
    if (batchRes.rows.length > 0) {
      const semester = batchRes.rows[0].semester;
      const pattern = `SEM-${semester}-%`;

      // Find series IDs to clean up recurring series records
      const seriesRes = await client.query(
        `SELECT DISTINCT series_id FROM bookings WHERE booking_request_id LIKE $1 AND series_id IS NOT NULL`,
        [pattern]
      );
      const seriesIds = seriesRes.rows.map(r => r.series_id);

      // Delete generated bookings
      await client.query(`DELETE FROM bookings WHERE booking_request_id LIKE $1`, [pattern]);

      // Delete corresponding recurring series
      if (seriesIds.length > 0) {
        await client.query(`DELETE FROM recurring_series WHERE series_id = ANY($1)`, [seriesIds]);
      }
    }

    // Delete the batch
    await client.query('DELETE FROM allocation_batches WHERE batch_id = $1', [batchId]);

    await client.query('COMMIT');
    res.json({ success: true, message: 'Batch and all associated timetable bookings deleted successfully' });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

// GET /api/admin/faculty - Retrieve all faculties
router.get('/faculty', async (req, res) => {
  try {
    const result = await pool.query("SELECT faculty_id, employee_id, username, full_name_en, full_name_bn, email, designation, seniority_rank, TO_CHAR(joining_date, 'YYYY-MM-DD') as joining_date, dept_head_flag, status FROM faculty ORDER BY seniority_rank ASC, full_name_en ASC");
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// PUT /api/admin/faculty/:facultyId - Update a faculty profile
router.put('/faculty/:facultyId', async (req, res) => {
  try {
    const { facultyId } = req.params;
    const { employee_id, full_name_en, full_name_bn, email, designation, seniority_rank, dept_head_flag, joining_date, username } = req.body;
    
    const finalJoiningDate = joining_date ? joining_date : null;

    const result = await pool.query(
      `UPDATE faculty SET 
        employee_id = $1, full_name_en = $2, full_name_bn = $3, email = $4, 
        designation = $5, seniority_rank = $6, dept_head_flag = $7, joining_date = $8, username = $9
       WHERE faculty_id = $10 RETURNING *`,
      [employee_id, full_name_en, full_name_bn, email, designation, seniority_rank, dept_head_flag || false, finalJoiningDate, username, facultyId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Faculty not found' });
    }
    res.json({ success: true, faculty: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/admin/faculty/:facultyId/deactivate - Deactivate and re-assign
router.post('/faculty/:facultyId/deactivate', async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { facultyId } = req.params;
    const { replacementFacultyId } = req.body;

    // 1. Deactivate the faculty
    await client.query("UPDATE faculty SET status = 'Inactive' WHERE faculty_id = $1", [facultyId]);

    // 2. If replacement provided, shift active workload
    if (replacementFacultyId) {
      await client.query("UPDATE bookings SET faculty_id = $1 WHERE faculty_id = $2 AND status = 'Confirmed'", [replacementFacultyId, facultyId]);
      await client.query("UPDATE course_sections SET assigned_faculty_id = $1 WHERE assigned_faculty_id = $2", [replacementFacultyId, facultyId]);
      await client.query("UPDATE recurring_series SET faculty_id = $1 WHERE faculty_id = $2 AND status = 'Active'", [replacementFacultyId, facultyId]);
      await client.query("UPDATE waitlist_entries SET faculty_id = $1 WHERE faculty_id = $2 AND status = 'Waiting'", [replacementFacultyId, facultyId]);
    } else {
      await client.query("UPDATE bookings SET status = 'CancelledByAdmin', notes = 'Faculty Deactivated' WHERE faculty_id = $1 AND status = 'Confirmed'", [facultyId]);
      await client.query("UPDATE recurring_series SET status = 'Cancelled' WHERE faculty_id = $1 AND status = 'Active'", [facultyId]);
    }

    await client.query('COMMIT');
    res.json({ success: true, message: 'Faculty deactivated successfully' });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});
// PUT /api/admin/faculty/:facultyId/password - Reset faculty password
router.put('/faculty/:facultyId/password', async (req, res) => {
  try {
    const { facultyId } = req.params;
    const { new_password } = req.body;
    
    if (!new_password) {
      return res.status(400).json({ error: 'new_password is required' });
    }

    const result = await pool.query(
      `UPDATE faculty SET password = $1 WHERE faculty_id = $2 RETURNING faculty_id`,
      [new_password, facultyId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Faculty not found' });
    }
    res.json({ success: true, message: 'Password reset successfully' });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/admin/hr-sync - Sync with institutional HR API
router.post('/hr-sync', async (req, res) => {
  const client = await pool.connect();
  try {
    const { faculties } = req.body;
    if (!faculties || !Array.isArray(faculties)) return res.status(400).json({ error: 'faculties array required' });

    await client.query('BEGIN');
    
    let created = 0;
    let updated = 0;

    for (const f of faculties) {
      // Auto assign rank
      let rank = 4;
      if (f.designation === 'Professor') rank = 1;
      else if (f.designation === 'Associate Professor') rank = 2;
      else if (f.designation === 'Assistant Professor') rank = 3;

      const check = await client.query(`SELECT faculty_id FROM faculty WHERE employee_id = $1`, [f.employee_id]);
      
      if (check.rows.length > 0) {
        // Update
        await client.query(
          `UPDATE faculty SET 
            full_name_en = $1, full_name_bn = $2, email = $3, designation = $4,
            department = $5, phone = $6, seniority_rank = $7, hr_sync_at = CURRENT_TIMESTAMP
           WHERE employee_id = $8`,
          [f.full_name_en, f.full_name_bn, f.email, f.designation, f.department, f.phone, rank, f.employee_id]
        );
        updated++;
      } else {
        // Insert
        // Need a username
        const username = f.email.split('@')[0];
        await client.query(
          `INSERT INTO faculty (employee_id, full_name_en, full_name_bn, email, designation, department, phone, seniority_rank, username)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
          [f.employee_id, f.full_name_en, f.full_name_bn, f.email, f.designation, f.department, f.phone, rank, username]
        );
        created++;
      }
    }

    await client.query('COMMIT');
    res.json({ success: true, created, updated });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

// PUT /api/admin/faculty/:facultyId/rank - Manually override rank
router.put('/faculty/:facultyId/rank', async (req, res) => {
  const client = await pool.connect();
  try {
    const { facultyId } = req.params;
    const { targetRank, justification, adminId } = req.body;
    if (!targetRank || !justification || !adminId) {
      return res.status(400).json({ error: 'targetRank, justification, and adminId are required' });
    }

    await client.query('BEGIN');
    
    // Get old rank
    const facRes = await client.query(`SELECT seniority_rank FROM faculty WHERE faculty_id = $1`, [facultyId]);
    if (facRes.rows.length === 0) throw new Error('Faculty not found');
    const oldRank = facRes.rows[0].seniority_rank;

    // Update rank
    await client.query(
      `UPDATE faculty SET seniority_rank = $1, rank_justification = $2 WHERE faculty_id = $3`,
      [targetRank, justification, facultyId]
    );

    // Audit Log
    await client.query(
      `INSERT INTO audit_logs (user_id, user_role, action, entity_type, entity_id, field_changed, old_value, new_value)
       VALUES ($1, 'Admin', 'RANK_OVERRIDE', 'Faculty', $2, 'seniority_rank', $3, $4)`,
      [adminId, facultyId, JSON.stringify({ rank: oldRank }), JSON.stringify({ rank: targetRank, justification })]
    );

    await client.query('COMMIT');
    res.json({ success: true });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

export default router;
