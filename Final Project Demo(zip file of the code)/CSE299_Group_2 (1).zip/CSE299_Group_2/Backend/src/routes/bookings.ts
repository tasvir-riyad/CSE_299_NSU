import { Router, Request, Response } from 'express';
import pool from '../db';
import { resolvePriority, promoteWaitlist, logAudit, createNotification, checkOverlap } from '../priorityEngine';

const router = Router();

// Generate human-readable booking request ID
function generateRequestId(): string {
  const year = new Date().getFullYear();
  const num = Math.floor(10000 + Math.random() * 90000);
  return `CBS-${year}-${num}`;
}

// GET /api/bookings - Retrieve list of bookings
router.get('/', async (req: Request, res: Response) => {
  try {
    const { facultyId, department, status, roomId } = req.query;
    let query = `
      SELECT b.*, c.room_number, COALESCE(f.full_name_en, b.faculty_name) as full_name_en, COALESCE(f.designation::text, b.faculty_email) as designation, f.employee_id
      FROM bookings b
      JOIN classrooms c ON b.room_id = c.room_id
      LEFT JOIN faculty f ON b.faculty_id = f.faculty_id
      WHERE 1=1
    `;
    const params: any[] = [];
    let idx = 1;

    if (facultyId) {
      query += ` AND b.faculty_id = $${idx}`;
      params.push(facultyId);
      idx++;
    }
    if (department) {
      query += ` AND f.department = $${idx}`;
      params.push(department);
      idx++;
    }
    if (status) {
      const dbStatus = status === 'PendingAdminApproval' ? 'Pending' : status;
      query += ` AND b.status = $${idx}`;
      params.push(dbStatus);
      idx++;
    }
    if (roomId) {
      query += ` AND b.room_id = $${idx}`;
      params.push(roomId);
      idx++;
    }

    query += ` ORDER BY b.start_dt DESC`;
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/bookings - Create one-time or recurring booking request
router.post('/', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const {
      facultyId,
      roomId,
      courseCode,
      courseName,
      classSize,
      startDt, // ISO string for one-time
      endDt,   // ISO string for one-time
      bookingType, // 'OneTime' | 'Recurring'
      notes,
      // For recurring bookings:
      pattern, // 'Weekly' | 'BiWeekly'
      daysOfWeek, // array of numbers e.g. [1, 3] (1 = Mon, 3 = Wed)
      startDate, // 'YYYY-MM-DD'
      endDate,   // 'YYYY-MM-DD'
      startTime, // 'HH:MM:SS'
      endTime,   // 'HH:MM:SS'
      confirmOption, // 'skip' or 'reject' (when recurring has conflicts)
      isDraft, // boolean
    } = req.body;

    if (bookingType === 'OneTime') {
      const s = new Date(startDt);
      const e = new Date(endDt);
      if (s >= e) {
        return res.status(400).json({ error: 'Start time must be strictly before end time.' });
      }
    } else if (bookingType === 'Recurring') {
      if (startTime >= endTime) {
        return res.status(400).json({ error: 'Start time must be strictly before end time.' });
      }
    }

    // Start transaction
    await client.query('BEGIN');

    // 1. Fetch Room Capacity and Building Operating Hours
    const roomRes = await client.query(
      `SELECT c.*, b.operating_hours as building_operating_hours
       FROM classrooms c
       JOIN buildings b ON c.building_id = b.building_id
       WHERE c.room_id = $1`,
      [roomId]
    );
    if (roomRes.rows.length === 0) {
      throw new Error('Room not found');
    }
    const room = roomRes.rows[0];

    // BR-003: Capacity Validation
    if (parseInt(classSize, 10) > room.capacity) {
      throw new Error(`Class size ${classSize} exceeds room capacity of ${room.capacity}. Please select a larger room.`);
    }

    // Fetch Faculty info
    const facultyRes = await client.query(`SELECT * FROM faculty WHERE faculty_id = $1`, [facultyId]);
    if (facultyRes.rows.length === 0) {
      throw new Error('Faculty profile not found');
    }
    const faculty = facultyRes.rows[0];

    // Check configuration limits
    const configRes = await client.query(`SELECT * FROM system_config`);
    const configMap = new Map(configRes.rows.map((r) => [r.config_key, r.config_value]));

    // AD-001/PA-012 Booking Window Enforcement (e.g. max 60 days in advance)
    const windowKey = 'booking_window_' + room.room_type;
    const typeWindowConfig = configMap.get(windowKey);
    const bookingWindowDays = typeWindowConfig 
      ? parseInt((typeWindowConfig as any).days || '60', 10) 
      : parseInt((configMap.get('booking_window_days') as any)?.days || '60', 10);

    const maxBookingDate = new Date();
    maxBookingDate.setDate(maxBookingDate.getDate() + bookingWindowDays);

    // Check Operating Hours & Anti-Double-Booking for OneTime
    if (bookingType === 'OneTime') {
      const start = new Date(startDt);
      const end = new Date(endDt);

      if (start > maxBookingDate) {
        throw new Error(`Booking date exceeds the maximum booking window of ${bookingWindowDays} days.`);
      }

      // AD-002 Max Booking Duration validation
      const durationKey = 'max_duration_' + room.room_type;
      const typeDurationConfig = configMap.get(durationKey);
      const maxHours = typeDurationConfig ? parseFloat((typeDurationConfig as any).hours || '4') : 4.0;
      const diffHours = (end.getTime() - start.getTime()) / (1000 * 60 * 60);
      if (diffHours > maxHours) {
        throw new Error(`Booking duration of ${diffHours.toFixed(1)} hours exceeds the maximum limit of ${maxHours} hours for ${room.room_type}.`);
      }

      // BR-004: Operating Hours Validation
      const opHours = room.building_operating_hours?.default || { open: '08:00', close: '22:00' };
      const dateStr = startDt.split('T')[0];
      const openTime = new Date(`${dateStr}T${opHours.open}`);
      const closeTime = new Date(`${dateStr}T${opHours.close}`);

      if (start < openTime || end > closeTime) {
        throw new Error(`Requested slot falls outside the building's operating hours (${opHours.open} - ${opHours.close}).`);
      }

      // BR-010: Anti-Double-Booking for faculty
      if (!isDraft) {
        const doubleBookingRes = await client.query(
          `SELECT * FROM bookings
           WHERE faculty_id = $1
             AND status IN ('Confirmed', 'Pending')
             AND start_dt < $3 AND end_dt > $2`,
          [facultyId, start, end]
        );
        if (doubleBookingRes.rows.length > 0) {
          throw new Error(`Anti-Double-Booking: You already have a confirmed or pending booking for Room ${doubleBookingRes.rows[0].booking_request_id} overlapping this slot.`);
        }
      }

      const reqId = generateRequestId();
      const insertStatus = isDraft ? 'Draft' : 'Pending';
      const insertRes = await client.query(
        `INSERT INTO bookings (booking_request_id, faculty_id, room_id, course_code, course_name, class_size, start_dt, end_dt, booking_type, status, notes)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'OneTime', $10, $9)
         RETURNING booking_id`,
        [reqId, facultyId, roomId, courseCode, courseName, parseInt(classSize, 10), start, end, notes || '', insertStatus]
      );

      const bookingId = insertRes.rows[0].booking_id;
      await client.query('COMMIT');

      let resolution = null;
      if (!isDraft) {
        // Resolve priority and auto-confirm/waitlist (outside transaction to avoid lock nesting issues, or in transaction)
        resolution = await resolvePriority(bookingId);
      }

      // Fetch final booking status
      const finalBooking = await pool.query(
        `SELECT b.*, c.room_number FROM bookings b JOIN classrooms c ON b.room_id = c.room_id WHERE b.booking_id = $1`,
        [bookingId]
      );

      return res.status(201).json({
        booking: finalBooking.rows[0],
        resolution,
      });
    }

    // RECURRING BOOKINGS
    if (bookingType === 'Recurring') {
      // Parse dates and check max series duration (RB-008)
      const startD = new Date(startDate);
      const endD = new Date(endDate);
      const diffTime = Math.abs(endD.getTime() - startD.getTime());
      const diffWeeks = Math.ceil(diffTime / (1000 * 60 * 60 * 24 * 7));

      const maxSeriesWeeks = parseInt((configMap.get('recurring_max_weeks') as any)?.weeks || '18', 10);
      if (diffWeeks > maxSeriesWeeks) {
        throw new Error(`Recurring series exceeds the maximum duration limit of ${maxSeriesWeeks} weeks.`);
      }

      // Generate all dates matching the daysOfWeek in the range
      const datesToBook: Date[] = [];
      const current = new Date(startD);
      while (current <= endD) {
        const day = current.getDay(); // 0 = Sun, 1 = Mon, etc.
        if (daysOfWeek.includes(day)) {
          datesToBook.push(new Date(current));
        }
        current.setDate(current.getDate() + 1);
      }

      if (datesToBook.length === 0) {
        throw new Error('No matching days found in the requested date range.');
      }

      // Pre-evaluate conflicts for each instance
      const instances = [];
      let conflictCount = 0;

      for (const d of datesToBook) {
        const dateStr = d.toISOString().split('T')[0];
        const instStart = new Date(`${dateStr}T${startTime}`);
        const instEnd = new Date(`${dateStr}T${endTime}`);

        // Check operating hours
        const opHours = room.building_operating_hours?.default || { open: '08:00', close: '22:00' };
        const openTime = new Date(`${dateStr}T${opHours.open}`);
        const closeTime = new Date(`${dateStr}T${opHours.close}`);

        let hasConflict = false;
        let reason = '';

        if (instStart < openTime || instEnd > closeTime) {
          hasConflict = true;
          reason = 'Outside operating hours';
        } else {
          // Check database overlap
          const overlaps = await checkOverlap(roomId, instStart, instEnd);
          if (overlaps.some((o: any) => o.status === 'Confirmed')) {
            hasConflict = true;
            reason = 'Slot already Confirmed';
          }
        }

        if (hasConflict) {
          conflictCount++;
        }

        instances.push({
          startDt: instStart,
          endDt: instEnd,
          hasConflict,
          reason,
        });
      }

      // If conflicts exist and client hasn't specified option or wants to reject, ONLY if it's not a draft
      if (!isDraft && conflictCount > 0 && (!confirmOption || confirmOption === 'reject')) {
        await client.query('ROLLBACK');
        return res.status(409).json({
          message: `The recurring series has ${conflictCount} conflicting instances.`,
          conflictCount,
          instances,
          requiresChoice: true,
        });
      }

      // Create recurring series record
      const seriesRes = await client.query(
        `INSERT INTO recurring_series (faculty_id, room_id, pattern, days_of_week, start_date, end_date, start_time, end_time, total_instances, confirmed_count, skipped_count, status)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 0, 0, 'Active')
         RETURNING series_id`,
        [
          facultyId,
          roomId,
          pattern,
          daysOfWeek,
          startDate,
          endDate,
          startTime,
          endTime,
          instances.length,
        ]
      );
      const seriesId = seriesRes.rows[0].series_id;

      const createdBookings = [];
      let confirmedCount = 0;
      let skippedCount = 0;

      for (const inst of instances) {
        if (inst.hasConflict && (!isDraft && confirmOption === 'skip')) {
          // Skip or Waitlist
          const reqId = generateRequestId();
          const insertRes = await client.query(
            `INSERT INTO bookings (booking_request_id, faculty_id, room_id, course_code, course_name, class_size, start_dt, end_dt, booking_type, status, notes, series_id)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'Recurring', 'Waitlisted', $9, $10)
             RETURNING booking_id`,
            [reqId, facultyId, roomId, courseCode, courseName, parseInt(classSize, 10), inst.startDt, inst.endDt, notes || '', seriesId]
          );
          skippedCount++;

          const bookingId = insertRes.rows[0].booking_id;
          // Insert waitlist
          await client.query(
            `INSERT INTO waitlist_entries (booking_id, room_id, faculty_id, seniority_rank_at_time, reason, status)
             VALUES ($1, $2, $3, $4, $5, 'Waiting')`,
            [bookingId, roomId, facultyId, faculty.seniority_rank, 'Recurring series skipped conflict']
          );

          createdBookings.push({
            bookingId,
            startDt: inst.startDt,
            endDt: inst.endDt,
            status: 'Waitlisted',
          });
        } else if (!inst.hasConflict || isDraft) {
          // Confirm or Draft
          const reqId = generateRequestId();
          const insertStatus = isDraft ? 'Draft' : 'Confirmed';
          const insertRes = await client.query(
            `INSERT INTO bookings (booking_request_id, faculty_id, room_id, course_code, course_name, class_size, start_dt, end_dt, booking_type, status, notes, series_id)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'Recurring', $10, $9, $11)
             RETURNING booking_id`,
            [reqId, facultyId, roomId, courseCode, courseName, parseInt(classSize, 10), inst.startDt, inst.endDt, notes || '', insertStatus, seriesId]
          );
          if (!isDraft) {
            confirmedCount++;
          }

          createdBookings.push({
            bookingId: insertRes.rows[0].booking_id,
            startDt: inst.startDt,
            endDt: inst.endDt,
            status: insertStatus,
          });
        }
      }

      // Update counters in series
      await client.query(
        `UPDATE recurring_series SET confirmed_count = $1, skipped_count = $2 WHERE series_id = $3`,
        [confirmedCount, skippedCount, seriesId]
      );

      await client.query('COMMIT');

      // Send summary notification
      await createNotification(
        facultyId,
        'SubmissionConfirm',
        'Email',
        `Recurring Series Created: Room ${room.room_number}`,
        `Your recurring series is created. ${confirmedCount} instances CONFIRMED, ${skippedCount} instances WAITLISTED.`,
        undefined
      );

      res.status(201).json({
        seriesId,
        confirmedCount,
        skippedCount,
        bookings: createdBookings,
      });
    }
  } catch (err) {
    await client.query('ROLLBACK');
    const msg = (err as Error).message;
    if (msg.includes('exceeds room capacity') || msg.includes('Anti-Double-Booking') || msg.includes('operating hours') || msg.includes('exceeds the maximum')) {
      res.status(400).json({ error: msg });
    } else {
      res.status(500).json({ error: msg });
    }
  } finally {
    client.release();
  }
});

// DELETE /api/bookings/:id - Cancel a booking
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { cancelRole, cancelReason, scope } = req.body; // scope = 'series' or 'instance'

    // Fetch booking details
    const bookingRes = await pool.query(
      `SELECT b.*, c.room_number FROM bookings b JOIN classrooms c ON b.room_id = c.room_id WHERE b.booking_id = $1`,
      [id]
    );

    if (bookingRes.rows.length === 0) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    const booking = bookingRes.rows[0];
    const prevStatus = booking.status;

    // Check cancellation cutoff: BM-002: up to 1 hour before start
    const start = new Date(booking.start_dt);
    const now = new Date();
    const hoursDiff = (start.getTime() - now.getTime()) / (1000 * 60 * 60);

    if (cancelRole !== 'Admin' && hoursDiff < 1 && hoursDiff >= 0) {
      return res.status(400).json({ error: 'Bookings can only be cancelled up to 1 hour before slot start.' });
    }

    const newStatus = cancelRole === 'Admin' ? 'CancelledByAdmin' : 'CancelledByFaculty';

    let affectedBookings = [booking];

    if (scope === 'series' && booking.series_id) {
      // Find all future bookings associated with the same series_id (starting from this instance's start_dt)
      const seriesRes = await pool.query(
        `SELECT b.*, c.room_number 
         FROM bookings b 
         JOIN classrooms c ON b.room_id = c.room_id 
         WHERE b.series_id = $1 AND b.start_dt >= $2 AND b.status NOT IN ('CancelledByFaculty', 'CancelledByAdmin', 'AutoCancelledNoShow', 'Completed')`,
        [booking.series_id, booking.start_dt]
      );
      if (seriesRes.rows.length > 0) {
        affectedBookings = seriesRes.rows;
      }
    }

    for (const b of affectedBookings) {
      // Update status
      await pool.query(
        `UPDATE bookings SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE booking_id = $2`,
        [newStatus, b.booking_id]
      );

      // Delete waitlist entry
      await pool.query(`DELETE FROM waitlist_entries WHERE booking_id = $1`, [b.booking_id]);

      // Audit log
      await logAudit(
        b.faculty_id,
        cancelRole || 'Faculty',
        cancelRole === 'Admin' ? 'CANCELLED_BY_ADMIN' : 'CANCELLED_BY_FACULTY',
        'Booking',
        String(b.booking_id),
        'status',
        b.status,
        newStatus
      );

      // Send cancellation notifications
      await createNotification(
        b.faculty_id,
        'StatusChange',
        'Email',
        `Booking ${b.booking_request_id} Cancelled`,
        `Your booking for Room ${b.room_number} on ${new Date(b.start_dt).toLocaleDateString()} was cancelled. Reason: ${cancelReason || 'N/A'}.`,
        String(b.booking_id)
      );

      // Trigger waitlist promotion if it was confirmed
      if (b.status === 'Confirmed') {
        await promoteWaitlist(b.room_id, b.start_dt, b.end_dt);
      }
    }

    res.json({ message: `${affectedBookings.length} booking(s) cancelled successfully`, status: newStatus });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/bookings/:id/checkin - Mark check-in
router.post('/:id/checkin', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const checkinRes = await pool.query(
      `UPDATE bookings
       SET checkin_at = CURRENT_TIMESTAMP, status = 'Confirmed', updated_at = CURRENT_TIMESTAMP
       WHERE booking_id = $1
       RETURNING *`,
      [id]
    );

    if (checkinRes.rows.length === 0) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    const booking = checkinRes.rows[0];

    // Audit log
    await logAudit(
      booking.faculty_id,
      'Faculty',
      'CHECKED_IN',
      'Booking',
      String(id),
      'checkin_at',
      null,
      new Date().toISOString()
    );

    res.json({ message: 'Checked in successfully', booking });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/bookings/:id/report-issue - Report room issue
router.post('/:id/report-issue', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { issueType, description, facultyId } = req.body;

    if (!issueType || !description || !facultyId) {
      return res.status(400).json({ error: 'Missing issueType, description, or facultyId' });
    }

    // Fetch booking details
    const bookingRes = await pool.query(
      `SELECT b.*, c.room_number FROM bookings b JOIN classrooms c ON b.room_id = c.room_id WHERE b.booking_id = $1`,
      [id]
    );

    if (bookingRes.rows.length === 0) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    const booking = bookingRes.rows[0];

    // Log audit trail
    await logAudit(
      facultyId as string,
      'Faculty',
      'FACULTY_REPORTED_ISSUE',
      'Booking',
      id as string,
      'notes',
      null,
      `Issue: ${issueType} | ${description}`
    );

    // Create system notification for Administrator
    await createNotification(
      '00000000-0000-0000-0000-000000000000',
      'IssueReport',
      'Email',
      `Classroom Alert: Room ${booking.room_number}`,
      `Issue Reported by Faculty: ${issueType}. Details: ${description} (Booking request: ${booking.booking_request_id})`,
      id as string
    );

    res.json({ message: 'Issue reported to administrator successfully.' });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/bookings/lobby
// Gets all confirmed bookings for today for a specific building (or all)
router.get('/lobby', async (req, res) => {
  try {
    const { building } = req.query;
    
    let query = `
      SELECT bk.booking_id, bk.course_code, bk.course_name, bk.start_dt, bk.end_dt, r.room_number,
             COALESCE(u.full_name_en, 'Staff') as faculty_name, bk.booking_type, b.building_code
      FROM bookings bk
      JOIN classrooms r ON bk.room_id = r.room_id
      JOIN buildings b ON r.building_id = b.building_id
      LEFT JOIN faculty u ON bk.faculty_id = u.faculty_id
      WHERE DATE(bk.start_dt) = CURRENT_DATE
      AND bk.status = 'Confirmed'
    `;
    const params: any[] = [];
    
    if (building) {
      query += ` AND b.building_code = $1`;
      params.push(building);
    }
    
    query += ` ORDER BY bk.start_dt ASC`;
    
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/bookings/:id/alternatives
// Finds up to 5 alternative available rooms for the same slot as this waitlisted booking
router.get('/:id/alternatives', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const bookingRes = await pool.query(
      `SELECT b.*, c.building_id, c.capacity
       FROM bookings b
       JOIN classrooms c ON b.room_id = c.room_id
       WHERE b.booking_id = $1`,
      [id]
    );

    if (bookingRes.rows.length === 0) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    const booking = bookingRes.rows[0];

    // Find classrooms that do not have overlapping confirmed or pending bookings for the same slot
    const alternativesQuery = `
      SELECT r.*, bldg.building_code
      FROM classrooms r
      JOIN buildings bldg ON r.building_id = bldg.building_id
      WHERE r.status = 'Active'
        AND r.room_id <> $1
        AND NOT EXISTS (
          SELECT 1 FROM bookings bk
          WHERE bk.room_id = r.room_id
            AND bk.status IN ('Confirmed', 'Pending')
            AND bk.start_dt < $3
            AND bk.end_dt > $2
        )
      ORDER BY ABS(r.capacity - $4) ASC
      LIMIT 5
    `;

    const alternatives = await pool.query(alternativesQuery, [
      booking.room_id,
      booking.start_dt,
      booking.end_dt,
      booking.capacity
    ]);

    res.json(alternatives.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/bookings/:id/rebook
// Instantly update waitlisted booking with alternative room and re-evaluate priority
router.post('/:id/rebook', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { roomId } = req.body;

    const bookingRes = await pool.query(`SELECT * FROM bookings WHERE booking_id = $1`, [id]);
    if (bookingRes.rows.length === 0) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    // Update room and reset to Pending
    await pool.query(
      `UPDATE bookings SET room_id = $1, status = 'Pending', updated_at = CURRENT_TIMESTAMP WHERE booking_id = $2`,
      [roomId, id]
    );

    // Resolve priority
    const resolution = await resolvePriority(id as string);
    // Fetch updated booking
    const updatedRes = await pool.query(
      `SELECT b.*, c.room_number FROM bookings b JOIN classrooms c ON b.room_id = c.room_id WHERE b.booking_id = $1`,
      [id]
    );

    res.json({
      booking: updatedRes.rows[0],
      resolution
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// PUT /api/bookings/:id - Modify a booking request
router.put('/:id', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { id } = req.params;
    const { roomId, startDt, endDt, notes, classSize } = req.body;

    await client.query('BEGIN');

    // 1. Fetch booking details
    const bookingRes = await client.query(`SELECT * FROM bookings WHERE booking_id = $1`, [id]);
    if (bookingRes.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Booking not found' });
    }
    const booking = bookingRes.rows[0];

    // Check if booking has already started
    const now = new Date();
    if (new Date(booking.start_dt) <= now) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Booking has already started and cannot be modified.' });
    }

    // 2. Fetch classroom details
    const targetRoomId = roomId || booking.room_id;
    const roomRes = await client.query(
      `SELECT c.*, b.operating_hours as building_operating_hours
       FROM classrooms c
       JOIN buildings b ON c.building_id = b.building_id
       WHERE c.room_id = $1`,
      [targetRoomId]
    );
    if (roomRes.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Room not found' });
    }
    const room = roomRes.rows[0];

    // Capacity Validation
    const finalSize = classSize ? parseInt(classSize, 10) : booking.class_size;
    if (finalSize > room.capacity) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: `Class size ${finalSize} exceeds room capacity of ${room.capacity}. Please select a larger room.` });
    }

    // Fetch system configs
    const configRes = await client.query(`SELECT * FROM system_config`);
    const configMap = new Map(configRes.rows.map((r) => [r.config_key, r.config_value]));

    // Booking Window Validation
    const windowKey = 'booking_window_' + room.room_type;
    const typeWindowConfig = configMap.get(windowKey);
    const bookingWindowDays = typeWindowConfig 
      ? parseInt((typeWindowConfig as any).days || '60', 10) 
      : parseInt((configMap.get('booking_window_days') as any)?.days || '60', 10);

    const maxBookingDate = new Date();
    maxBookingDate.setDate(maxBookingDate.getDate() + bookingWindowDays);

    const finalStart = startDt ? new Date(startDt) : new Date(booking.start_dt);
    const finalEnd = endDt ? new Date(endDt) : new Date(booking.end_dt);

    if (finalStart > maxBookingDate) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: `Booking date exceeds the maximum booking window of ${bookingWindowDays} days.` });
    }

    // Max Duration Validation
    const durationKey = 'max_duration_' + room.room_type;
    const typeDurationConfig = configMap.get(durationKey);
    const maxHours = typeDurationConfig ? parseFloat((typeDurationConfig as any).hours || '4') : 4.0;
    const diffHours = (finalEnd.getTime() - finalStart.getTime()) / (1000 * 60 * 60);
    if (diffHours > maxHours) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: `Booking duration of ${diffHours.toFixed(1)} hours exceeds the maximum limit of ${maxHours} hours for ${room.room_type}.` });
    }

    const opHours = room.building_operating_hours?.default || { open: '08:00', close: '22:00' };
    const dateStr = (startDt || booking.start_dt.toISOString()).split('T')[0];
    const openTime = new Date(`${dateStr}T${opHours.open}`);
    const closeTime = new Date(`${dateStr}T${opHours.close}`);

    if (finalStart < openTime || finalEnd > closeTime) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: `Requested slot falls outside the building's operating hours (${opHours.open} - ${opHours.close}).` });
    }

    // Check overlaps (ignoring self)
    const overlaps = await checkOverlap(targetRoomId, finalStart, finalEnd, id as string);
    const confirmedOverlaps = overlaps.filter(o => o.status === 'Confirmed');
    if (confirmedOverlaps.length > 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: `Slot conflict: The selected slot overlaps with a confirmed booking.` });
    }

    // Update booking details
    await client.query(
      `UPDATE bookings 
       SET room_id = $1, start_dt = $2, end_dt = $3, class_size = $4, notes = $5, status = 'Pending', updated_at = CURRENT_TIMESTAMP
       WHERE booking_id = $6`,
      [targetRoomId, finalStart, finalEnd, finalSize, notes || booking.notes, id]
    );

    // Audit log
    await logAudit(
      booking.faculty_id,
      'Faculty',
      'MODIFY_BOOKING',
      'Booking',
      String(id),
      'room_id/times',
      { roomId: booking.room_id, startDt: booking.start_dt, endDt: booking.end_dt },
      { roomId: targetRoomId, startDt: finalStart, endDt: finalEnd }
    );

    await client.query('COMMIT');

    // Re-resolve priority
    const resolution = await resolvePriority(id as string);

    const updatedRes = await pool.query(
      `SELECT b.*, c.room_number FROM bookings b JOIN classrooms c ON b.room_id = c.room_id WHERE b.booking_id = $1`,
      [id]
    );

    res.json({ booking: updatedRes.rows[0], resolution });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

// POST /api/bookings/:id/mark-status - Mark final utilization status
router.post('/:id/mark-status', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body; // 'Completed' | 'AutoCancelledNoShow'

    if (status !== 'Completed' && status !== 'AutoCancelledNoShow') {
      return res.status(400).json({ error: 'Invalid status. Must be Completed or AutoCancelledNoShow.' });
    }

    const bookingRes = await pool.query(`SELECT * FROM bookings WHERE booking_id = $1`, [id]);
    if (bookingRes.rows.length === 0) {
      return res.status(404).json({ error: 'Booking not found' });
    }
    const booking = bookingRes.rows[0];

    await pool.query(
      `UPDATE bookings SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE booking_id = $2`,
      [status, id]
    );

    // Audit Log
    await logAudit(
      booking.faculty_id,
      'Faculty',
      'MARK_BOOKING_UTILIZATION',
      'Booking',
      String(id),
      'status',
      booking.status,
      status
    );

    res.json({ message: `Status updated to ${status} successfully.` });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

export default router;
