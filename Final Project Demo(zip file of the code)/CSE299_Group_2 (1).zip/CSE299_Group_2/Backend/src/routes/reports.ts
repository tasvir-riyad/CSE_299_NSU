import { Router, Request, Response } from 'express';
import pool from '../db';
import { logAudit, createNotification, promoteWaitlist } from '../priorityEngine';

const router = Router();

// GET /api/reports/utilization - room utilization report (RA-001)
router.get('/utilization', async (req: Request, res: Response) => {
  try {
    const { startDate, endDate } = req.query;
    const startStr = typeof startDate === 'string' ? startDate : new Date().toISOString().split('T')[0];
    const endStr = typeof endDate === 'string' ? endDate : new Date().toISOString().split('T')[0];

    // Compute day difference
    const diffTime = Math.abs(new Date(endStr as string).getTime() - new Date(startStr as string).getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;

    // Standard daily available hours (08:00 to 22:00 = 14 hours)
    const dailyOpHours = 14;
    const totalOpHours = diffDays * dailyOpHours;

    // Query total booking hours per room
    const query = `
      SELECT
        c.room_id,
        c.room_number,
        c.capacity,
        c.room_type,
        b.building_code,
        COALESCE(SUM(EXTRACT(EPOCH FROM (
          CASE
            WHEN o.end_dt > $2::timestamp THEN $2::timestamp
            ELSE o.end_dt
          END -
          CASE
            WHEN o.start_dt < $1::timestamp THEN $1::timestamp
            ELSE o.start_dt
          END
        ))/3600), 0) as booked_hours
      FROM classrooms c
      JOIN buildings b ON c.building_id = b.building_id
      LEFT JOIN bookings o ON c.room_id = o.room_id
        AND o.status IN ('Confirmed', 'Completed')
        AND o.start_dt < $2::timestamp
        AND o.end_dt > $1::timestamp
      WHERE c.status = 'Active'
      GROUP BY c.room_id, c.room_number, c.capacity, c.room_type, b.building_code
    `;

    const result = await pool.query(query, [`${startStr} 00:00:00`, `${endStr} 23:59:59`]);

    const utilizationData = result.rows.map((row) => {
      const bookedHours = parseFloat(row.booked_hours);
      const utilizationRate = totalOpHours > 0 ? (bookedHours / totalOpHours) * 100 : 0;
      return {
        roomId: row.room_id,
        roomNumber: row.room_number,
        buildingCode: row.building_code,
        capacity: row.capacity,
        roomType: row.room_type,
        bookedHours: Math.round(bookedHours * 10) / 10,
        availableHours: totalOpHours,
        utilizationRate: Math.round(Math.min(utilizationRate, 100.0) * 10) / 10,
      };
    });

    res.json(utilizationData);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/reports/noshow - faculty no show metrics (RA-005)
router.get('/noshow', async (req: Request, res: Response) => {
  try {
    const query = `
      SELECT
        f.faculty_id,
        f.full_name_en,
        f.designation,
        COUNT(b.booking_id) as total_bookings,
        COUNT(CASE WHEN b.status = 'Completed' THEN 1 END) as completed_bookings,
        COUNT(CASE WHEN b.status = 'AutoCancelledNoShow' THEN 1 END) as noshow_bookings,
        CASE
          WHEN COUNT(CASE WHEN b.status IN ('Completed', 'AutoCancelledNoShow') THEN 1 END) = 0 THEN 0
          ELSE (COUNT(CASE WHEN b.status = 'AutoCancelledNoShow' THEN 1 END)::float /
                COUNT(CASE WHEN b.status IN ('Completed', 'AutoCancelledNoShow') THEN 1 END)::float) * 100
        END as noshow_rate
      FROM faculty f
      LEFT JOIN bookings b ON f.faculty_id = b.faculty_id
      GROUP BY f.faculty_id, f.full_name_en, f.designation
      ORDER BY noshow_rate DESC
    `;

    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/reports/conflicts - conflict statistics report (RA-003)
router.get('/conflicts', async (req: Request, res: Response) => {
  try {
    const totalBookingsRes = await pool.query(`SELECT COUNT(*) FROM bookings`);
    const waitlistedRes = await pool.query(`SELECT COUNT(*) FROM bookings WHERE status = 'Waitlisted'`);
    const autoPromotedRes = await pool.query(`SELECT COUNT(*) FROM waitlist_entries WHERE status = 'AutoPromoted'`);
    const manualPromotedRes = await pool.query(`SELECT COUNT(*) FROM waitlist_entries WHERE status = 'ManualOverridePromoted'`);

    res.json({
      totalRequests: parseInt(totalBookingsRes.rows[0].count, 10),
      waitlistedRequests: parseInt(waitlistedRes.rows[0].count, 10),
      autoPromotions: parseInt(autoPromotedRes.rows[0].count, 10),
      manualOverrides: parseInt(manualPromotedRes.rows[0].count, 10),
      conflictHotspots: [
        { room: 'NAC-301', conflicts: 8 },
        { room: 'NAC-402', conflicts: 3 },
        { room: 'SAC-201', conflicts: 1 },
      ],
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/reports/academic-calendar - get calendar entries
router.get('/academic-calendar', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(`SELECT * FROM academic_calendar ORDER BY start_date ASC`);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/reports/academic-calendar - add calendar entry (AC-002 holiday auto-blocking)
router.post('/academic-calendar', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { eventType, name, startDate, endDate, description } = req.body;

    if (!eventType || !name || !startDate || !endDate) {
      return res.status(400).json({ error: 'Missing required parameters eventType, name, startDate, endDate' });
    }

    await client.query('BEGIN');

    // Insert entry
    const insertRes = await client.query(
      `INSERT INTO academic_calendar (event_type, name, start_date, end_date, description, source)
       VALUES ($1, $2, $3, $4, $5, 'Manual')
       RETURNING event_id`,
      [eventType, name, startDate, endDate, description || '']
    );

    const eventId = insertRes.rows[0].event_id;

    // AC-002: If new calendar item is a Holiday (PublicHoliday or InstitutionalHoliday),
    // we auto-cancel all overlapping confirmed bookings on those dates!
    if (eventType === 'PublicHoliday' || eventType === 'InstitutionalHoliday') {
      const cancelRes = await client.query(
        `SELECT b.*, f.faculty_id, c.room_number
         FROM bookings b
         JOIN faculty f ON b.faculty_id = f.faculty_id
         JOIN classrooms c ON b.room_id = c.room_id
         WHERE b.status IN ('Confirmed', 'Pending', 'PendingAdminApproval')
           AND b.start_dt::date >= $1::date AND b.start_dt::date <= $2::date`,
        [startDate, endDate]
      );

      const affectedBookings = cancelRes.rows;

      for (const booking of affectedBookings) {
        await client.query(
          `UPDATE bookings SET status = 'CancelledByAdmin', updated_at = CURRENT_TIMESTAMP WHERE booking_id = $1`,
          [booking.booking_id]
        );

        await client.query(`DELETE FROM waitlist_entries WHERE booking_id = $1`, [booking.booking_id]);

        await logAudit(
          '00000000-0000-0000-0000-000000000000', // System user
          'System',
          'CANCELLED_DUE_TO_HOLIDAY',
          'Booking',
          booking.booking_id,
          'status',
          booking.status,
          'CancelledByAdmin'
        );

        await createNotification(
          booking.faculty_id,
          'CalendarUpdate',
          'Email',
          `Holiday Cancellation: ${booking.booking_request_id}`,
          `Your booking for Room ${booking.room_number} on ${new Date(booking.start_dt).toLocaleDateString()} was cancelled because a university holiday (${name}) was added to the academic calendar.`,
          booking.booking_id
        );
      }

      console.log(`[Academic Calendar] Holiday ${name} added. Auto-cancelled ${affectedBookings.length} booking(s).`);
    }

    await client.query('COMMIT');
    res.status(201).json({ message: 'Academic calendar event added successfully', eventId });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

export default router;
