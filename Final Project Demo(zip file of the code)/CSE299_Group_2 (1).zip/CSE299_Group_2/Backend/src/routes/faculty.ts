import { Router, Request, Response } from 'express';
import pool from '../db';

const router = Router();

// GET /api/faculty - List all faculty members (for demo profile switcher)
router.get('/', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(
      `SELECT f.*
       FROM faculty f
       ORDER BY f.seniority_rank ASC`
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/faculty/imported-list - List all unique faculty members from preferences & profile table
router.get('/imported-list', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(
      `SELECT DISTINCT email, name, designation
       FROM (
         SELECT email, full_name_en as name, designation::text as designation FROM faculty
         UNION
         SELECT faculty_email as email, faculty_name as name, faculty_designation as designation FROM faculty_course_preferences WHERE faculty_email IS NOT NULL
       ) combined
       ORDER BY name ASC`
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/faculty/my-allocations?email=xxx - Get all confirmed semester allocations for a faculty member
router.get('/my-allocations', async (req: Request, res: Response) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ error: 'email query param is required' });

    const result = await pool.query(
      `SELECT
         sa.allocation_id,
         sa.allocated_day_of_week,
         sa.allocated_start_time,
         sa.allocated_end_time,
         sa.allocated_faculty_name,
         sa.allocated_faculty_email,
         sa.allocation_reason,
         sa.status AS allocation_status,
         cl.room_number,
         cl.capacity,
         cs.section_number,
         cs.enrollment_size,
         cs.facility_type,
         co.course_code,
         co.course_name,
         ab.semester,
         ab.batch_id,
         ab.status AS batch_status,
         COALESCE(f.designation::text, '') AS allocated_faculty_designation
       FROM semester_allocations sa
       JOIN allocation_batches ab ON sa.batch_id = ab.batch_id
       JOIN course_sections cs ON sa.section_id = cs.section_id
       JOIN courses co ON cs.course_id = co.course_id
       JOIN classrooms cl ON sa.room_id = cl.room_id
       LEFT JOIN faculty f ON sa.allocated_faculty_id = f.faculty_id
       WHERE LOWER(sa.allocated_faculty_email) = LOWER($1)
         AND ab.status IN ('Confirmed', 'Draft')
       ORDER BY ab.semester DESC, sa.allocated_day_of_week ASC, sa.allocated_start_time ASC`,
      [email]
    );

    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/faculty/timetable
router.get('/timetable', async (req: Request, res: Response) => {
  try {
    const { email, facultyId, startDate } = req.query;
    const start = startDate ? new Date(startDate as string) : new Date();
    // Start of the week (Monday)
    const day = start.getDay();
    const diff = start.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(start.setDate(diff));
    monday.setHours(0, 0, 0, 0);

    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 7);
    sunday.setHours(23, 59, 59, 999);

    let bookingsQuery = `
      SELECT b.booking_id, b.booking_request_id, b.course_code, b.course_name, b.start_dt, b.end_dt, b.status, b.booking_type,
             c.room_number, COALESCE(f.full_name_en, b.faculty_name) as faculty_name, COALESCE(f.designation::text, b.faculty_email) as faculty_designation, f.seniority_rank
      FROM bookings b
      JOIN classrooms c ON b.room_id = c.room_id
      LEFT JOIN faculty f ON b.faculty_id = f.faculty_id
      WHERE b.start_dt >= $1 AND b.start_dt <= $2
        AND b.status NOT IN ('CancelledByFaculty', 'CancelledByAdmin', 'AutoCancelledNoShow')
    `;
    const params: any[] = [monday, sunday];

    if (email) {
      bookingsQuery += ` AND (LOWER(b.faculty_email) = LOWER($3) OR LOWER(f.email) = LOWER($3))`;
      params.push(email);
    } else if (facultyId) {
      bookingsQuery += ` AND b.faculty_id = $3`;
      params.push(facultyId);
    } else {
      return res.status(400).json({ error: 'Either email or facultyId is required' });
    }

    bookingsQuery += ` ORDER BY b.start_dt ASC`;
    const bookingsRes = await pool.query(bookingsQuery, params);

    res.json({
      weekStart: monday.toISOString(),
      weekEnd: sunday.toISOString(),
      bookings: bookingsRes.rows,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/faculty/:id - Retrieve faculty profile and bookings overview
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const profileRes = await pool.query(
      `SELECT f.*
       FROM faculty f
       WHERE f.faculty_id = $1`,
      [id]
    );

    if (profileRes.rowCount === 0) {
      return res.status(404).json({ error: 'Faculty not found' });
    }

    // Get statistics
    const statsRes = await pool.query(
      `SELECT
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'Confirmed' THEN 1 END) as confirmed,
        COUNT(CASE WHEN status = 'Waitlisted' THEN 1 END) as waitlisted,
        COUNT(CASE WHEN status IN ('CancelledByFaculty', 'CancelledByAdmin') THEN 1 END) as cancelled,
        COUNT(CASE WHEN status = 'AutoCancelledNoShow' THEN 1 END) as noshows
       FROM bookings
       WHERE faculty_id = $1`,
      [id]
    );

    res.json({
      profile: profileRes.rows[0],
      stats: statsRes.rows[0],
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/faculty/:id/notifications - Retrieve recent notifications
router.get('/:id/notifications', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const notifRes = await pool.query(
      `SELECT * FROM notifications
       WHERE user_id = $1
       ORDER BY sent_at DESC
       LIMIT 20`,
      [id]
    );
    res.json(notifRes.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/faculty/:id/preferences - Get faculty's course choices
router.get('/:id/preferences', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `SELECT p.*, cs.section_number, cs.enrollment_size, cs.day_of_week, cs.start_time, cs.end_time, c.course_code, c.course_name
       FROM faculty_course_preferences p
       JOIN course_sections cs ON p.section_id = cs.section_id
       JOIN courses c ON cs.course_id = c.course_id
       WHERE p.faculty_id = $1
       ORDER BY p.choice_rank ASC`,
      [id]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/faculty/:id/preferences - Submit/update faculty course preferences
router.post('/:id/preferences', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { id } = req.params;
    const { preferences } = req.body; // Array of { sectionId, choiceRank }

    if (!Array.isArray(preferences)) {
      return res.status(400).json({ error: 'Preferences must be an array' });
    }

    await client.query('BEGIN');

    // Remove existing preferences
    await client.query(`DELETE FROM faculty_course_preferences WHERE faculty_id = $1`, [id]);

    // Insert new preferences
    for (const pref of preferences) {
      await client.query(
        `INSERT INTO faculty_course_preferences (faculty_id, section_id, choice_rank)
         VALUES ($1, $2, $3)`,
        [id, pref.sectionId, pref.choiceRank]
      );
    }

    await client.query('COMMIT');
    res.json({ message: 'Preferences updated successfully' });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: (err as Error).message });
  } finally {
    client.release();
  }
});

export default router;
