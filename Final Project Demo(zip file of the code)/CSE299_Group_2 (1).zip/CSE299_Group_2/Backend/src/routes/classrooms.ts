import { Router, Request, Response } from 'express';
import pool from '../db';
import { checkOverlap } from '../priorityEngine';

const router = Router();

// GET /api/classrooms/published-batch - get the current published timetable batch and its allocations
router.get('/published-batch', async (req: Request, res: Response) => {
  try {
    const batchResult = await pool.query(
      `SELECT * FROM allocation_batches WHERE is_published = true LIMIT 1`
    );
    if (batchResult.rows.length === 0) {
      return res.json({ batch: null, allocations: [] });
    }
    const batch = batchResult.rows[0];
    const allocResult = await pool.query(
      `SELECT a.*, 
              c.course_name, c.credits, 
              r.room_number, r.building_code, 
              f.full_name_en as allocated_faculty_name, f.email as allocated_faculty_email 
       FROM semester_allocations a
       LEFT JOIN courses c ON a.course_code = c.course_code
       LEFT JOIN rooms r ON a.room_id = r.room_id
       LEFT JOIN faculty f ON a.allocated_faculty_id = f.faculty_id
       WHERE a.batch_id = $1`,
      [batch.batch_id]
    );
    res.json({ batch, allocations: allocResult.rows });
  } catch (err) {
    console.error('Error fetching published batch:', err);
    res.status(500).json({ error: 'Failed to fetch published batch' });
  }
});

// GET /api/classrooms - search classrooms with filters and availability
router.get('/', async (req: Request, res: Response) => {
  try {
    const {
      date,
      startTime,
      endTime,
      capacity,
      equipment, // comma-separated strings
      buildingId,
      roomType,
      floor,
      facultyId, // to compute past use scoring and building proximity
    } = req.query;

    let query = `
      SELECT c.*, b.building_name, b.building_code, b.operating_hours as building_operating_hours
      FROM classrooms c
      JOIN buildings b ON c.building_id = b.building_id
      WHERE c.status = 'Active'
    `;
    const params: any[] = [];
    let paramIndex = 1;

    if (buildingId) {
      query += ` AND c.building_id = $${paramIndex}`;
      params.push(buildingId);
      paramIndex++;
    }

    if (roomType) {
      query += ` AND c.room_type = $${paramIndex}`;
      params.push(roomType);
      paramIndex++;
    }

    if (floor) {
      query += ` AND c.floor = $${paramIndex}`;
      params.push(parseInt(floor as string, 10));
      paramIndex++;
    }

    if (capacity) {
      query += ` AND c.capacity >= $${paramIndex}`;
      params.push(parseInt(capacity as string, 10));
      paramIndex++;
    }

    const roomsRes = await pool.query(query, params);
    let rooms = roomsRes.rows;

    // Filter by requested equipment if provided
    if (equipment) {
      const reqEquip = (equipment as string).split(',');
      rooms = rooms.filter((room) => {
        const roomEquip = room.equipment || {};
        return reqEquip.every((eq) => roomEquip[eq] === true || (eq === 'computer_stations' && roomEquip[eq] > 0));
      });
    }

    // Retrieve faculty details for scoring
    let facultyBuildingId = null;
    let facultyBookedRooms: string[] = [];
    if (facultyId) {

      // Past booking history for the faculty in the past semester
      const pastRes = await pool.query(
        `SELECT room_id, COUNT(*) as count FROM bookings
         WHERE faculty_id = $1 AND status = 'Completed'
         GROUP BY room_id`,
        [facultyId]
      );
      facultyBookedRooms = pastRes.rows.map((r) => r.room_id);
    }

    const processedRooms = [];

    // If date/time range is provided, check availability and compute score
    for (const room of rooms) {
      let isAvailable = true;
      let conflictReason = '';
      let score = 100;
      let capacityScore = 40;
      let equipScore = 30;
      let proximityScore = 0;
      let pastUseScore = 0;

      if (date && startTime && endTime) {
        const startDt = new Date(`${date}T${startTime}`);
        const endDt = new Date(`${date}T${endTime}`);

        // 1. Check operating hours
        const opHours = room.building_operating_hours?.default || { open: '08:00', close: '22:00' };
        const openTime = new Date(`${date}T${opHours.open}`);
        const closeTime = new Date(`${date}T${opHours.close}`);

        if (startDt < openTime || endDt > closeTime) {
          isAvailable = false;
          conflictReason = `Outside building operating hours (${opHours.open} - ${opHours.close})`;
        } else {
          // 2. Check overlap with confirmed/pending bookings
          const overlaps = await checkOverlap(room.room_id, startDt, endDt);
          if (overlaps.some((o) => o.status === 'Confirmed')) {
            isAvailable = false;
            conflictReason = 'Already booked (Confirmed)';
          } else if (overlaps.some((o) => o.status === 'Pending' || o.status === 'PendingAdminApproval')) {
            // Note: partially available but pending requests exist
            isAvailable = true; // Still filterable as available, but flagged
            conflictReason = 'Pending requests exist (Waitlist likely)';
          }

          // 3. Check maintenance windows
          const maintRes = await pool.query(
            `SELECT * FROM maintenance_windows
             WHERE room_id = $1 AND start_dt < $3 AND end_dt > $2`,
            [room.room_id, startDt, endDt]
          );
          if (maintRes.rows.length > 0) {
            isAvailable = false;
            conflictReason = 'Room under maintenance';
          }

          // 4. Check academic calendar holiday blocks
          const calRes = await pool.query(
            `SELECT * FROM academic_calendar
             WHERE event_type IN ('PublicHoliday', 'InstitutionalHoliday')
               AND start_date <= $1::date AND end_date >= $2::date`,
            [startDt, startDt]
          );
          if (calRes.rows.length > 0) {
            isAvailable = false;
            conflictReason = `Holiday: ${calRes.rows[0].name}`;
          }
        }

        // Calculate capacity match score (max 40 pts)
        if (capacity) {
          const reqCap = parseInt(capacity as string, 10);
          capacityScore = Math.round(Math.min(reqCap / room.capacity, 1.0) * 40);
        }

        // Calculate equipment match score (max 30 pts)
        if (equipment) {
          const reqEquipList = (equipment as string).split(',');
          const matchingEquip = reqEquipList.filter((eq) => {
            const re = room.equipment || {};
            return re[eq] === true || (eq === 'computer_stations' && re[eq] > 0);
          });
          equipScore = Math.round((matchingEquip.length / reqEquipList.length) * 30);
        }

        // Calculate building proximity score (max 20 pts)
        if (facultyBuildingId) {
          if (room.building_id === facultyBuildingId) {
            proximityScore = 20;
          } else {
            proximityScore = 10; // Adjacent / nearby
          }
        }

        // Calculate past preference score (max 10 pts)
        if (facultyId) {
          const count = facultyBookedRooms.filter((id) => id === room.room_id).length;
          if (count >= 3) pastUseScore = 10;
          else if (count >= 1) pastUseScore = 5;
        }

        score = capacityScore + equipScore + proximityScore + pastUseScore;
      }

      processedRooms.push({
        ...room,
        isAvailable,
        conflictReason,
        matchScore: score,
        scores: {
          capacity: capacityScore,
          equipment: equipScore,
          proximity: proximityScore,
          pastUse: pastUseScore,
        },
      });
    }

    // Sort by available first, then by match score descending
    processedRooms.sort((a, b) => {
      if (a.isAvailable !== b.isAvailable) {
        return a.isAvailable ? -1 : 1;
      }
      return b.matchScore - a.matchScore;
    });

    res.json(processedRooms);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/classrooms/:id/timetable - retrieve weekly timetable for a room
router.get('/:id/timetable', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { startDate } = req.query; // date string e.g. YYYY-MM-DD
    const start = startDate ? new Date(startDate as string) : new Date();
    // Start of the week (Monday)
    const day = start.getDay();
    const diff = start.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
    const monday = new Date(start.setDate(diff));
    monday.setHours(0, 0, 0, 0);

    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 7);
    sunday.setHours(23, 59, 59, 999);

    // Fetch bookings in this window
    const bookingsRes = await pool.query(
      `SELECT b.booking_id, b.faculty_id, b.booking_request_id, b.course_code, b.course_name, b.start_dt, b.end_dt, b.status, b.booking_type,
              COALESCE(f.full_name_en, b.faculty_name) as faculty_name, COALESCE(f.designation::text, b.faculty_email) as faculty_designation, f.seniority_rank
       FROM bookings b
       LEFT JOIN faculty f ON b.faculty_id = f.faculty_id
       WHERE b.room_id = $1
         AND b.start_dt >= $2 AND b.start_dt <= $3
         AND b.status NOT IN ('CancelledByFaculty', 'CancelledByAdmin', 'AutoCancelledNoShow')`,
      [id, monday, sunday]
    );

    // Fetch maintenance windows
    const maintenanceRes = await pool.query(
      `SELECT maintenance_id, start_dt, end_dt, reason
       FROM maintenance_windows
       WHERE room_id = $1
         AND start_dt >= $2 AND start_dt <= $3`,
      [id, monday, sunday]
    );

    // Fetch academic calendar holidays
    const calendarRes = await pool.query(
      `SELECT event_id, name, start_date, end_date, event_type
       FROM academic_calendar
       WHERE start_date <= $2::date AND end_date >= $1::date`,
      [monday, sunday]
    );

    res.json({
      weekStart: monday.toISOString(),
      weekEnd: sunday.toISOString(),
      bookings: bookingsRes.rows,
      maintenance: maintenanceRes.rows,
      calendarEvents: calendarRes.rows,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /api/classrooms - admin CRUD (Create)
router.post('/', async (req: Request, res: Response) => {
  try {
    const { roomNumber, buildingId, floor, capacity, roomType, equipment, operatingHours } = req.body;
    const result = await pool.query(
      `INSERT INTO classrooms (room_number, building_id, floor, capacity, room_type, equipment, operating_hours, status, photos)
       VALUES ($1, $2, $3, $4, $5, $6, $7, 'Active', '{}')
       RETURNING *`,
      [roomNumber, buildingId, floor, capacity, roomType, equipment || {}, operatingHours || {}]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// PUT /api/classrooms/:id - admin CRUD (Update)
router.put('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { roomNumber, capacity, roomType, status, equipment, operatingHours } = req.body;
    const result = await pool.query(
      `UPDATE classrooms
       SET room_number = $1, capacity = $2, room_type = $3, status = $4, equipment = $5, operating_hours = $6
       WHERE room_id = $7
       RETURNING *`,
      [roomNumber, capacity, roomType, status, equipment, operatingHours, id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// GET /api/classrooms/heatmap
// Computes heatmap values for a typical week (across 30 days)
router.get('/heatmap', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        EXTRACT(ISODOW FROM start_dt) as day_of_week,
        EXTRACT(HOUR FROM start_dt) as hour_of_day,
        COUNT(*) as booking_count
      FROM bookings
      WHERE status = 'Confirmed' 
      AND start_dt >= CURRENT_DATE
      AND start_dt <= CURRENT_DATE + INTERVAL '30 days'
      GROUP BY EXTRACT(ISODOW FROM start_dt), EXTRACT(HOUR FROM start_dt)
    `);

    // Also get total number of rooms to calculate percentage (capacity)
    const roomRes = await pool.query(`SELECT COUNT(*) as total FROM classrooms`);
    const totalRooms = parseInt(roomRes.rows[0].total) || 1;

    res.json({
      heatmap: result.rows,
      totalRooms
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

export default router;
