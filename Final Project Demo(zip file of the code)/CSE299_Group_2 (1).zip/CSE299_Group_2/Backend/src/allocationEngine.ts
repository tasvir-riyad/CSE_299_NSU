import pool from './db';
import { logAudit, createNotification } from './priorityEngine';

export interface CourseSection {
  section_id: string;
  course_id: string;
  course_code: string;
  semester: string;
  section_number: string;
  enrollment_size: number;
  day_of_week?: number[] | null;
  start_time?: string | null;
  end_time?: string | null;
  facility_type: string;
  assigned_faculty_id?: string;
  assigned_faculty_name?: string;
  assigned_faculty_designation?: string;
  assigned_faculty_email?: string;
}

export interface AllocationResult {
  allocation_id: string;
  section_id: string;
  room_id: string;
  room_number: string;
  allocated_start_time: string;
  allocated_end_time: string;
  allocated_day_of_week: number;
  allocated_faculty_id?: string;
}

export interface ConflictInfo {
  section_id: string;
  course_code: string;
  conflict_type: string;
  description: string;
}


const TIMES = [
  { start: '08:00', end: '09:30' },
  { start: '09:40', end: '11:10' },
  { start: '11:20', end: '12:50' },
  { start: '13:00', end: '14:30' },
  { start: '14:40', end: '16:10' },
  { start: '16:20', end: '17:50' },
  { start: '18:00', end: '19:30' },
  { start: '19:40', end: '21:10' },
];

const THEORY_SLOTS = [
  ...TIMES.map(t => ({ days: [0, 2], start: t.start, end: t.end })), // ST (Sun/Tue)
  ...TIMES.map(t => ({ days: [1, 3], start: t.start, end: t.end })), // MW (Mon/Wed)
  ...TIMES.map(t => ({ days: [4, 6], start: t.start, end: t.end })), // RA (Thu/Sat)
];

const LAB_SLOTS: {days: number[], start: string, end: string}[] = [];
[0, 1, 2, 3, 4, 6].forEach(day => {
  TIMES.forEach(t => LAB_SLOTS.push({ days: [day], start: t.start, end: t.end }));
});


export class AllocationEngine {
  private batchId: string;
  private semester: string;
  private allocations: AllocationResult[] = [];
  private conflicts: ConflictInfo[] = [];

  constructor(batchId: string, semester: string) {
    this.batchId = batchId;
    this.semester = semester;
  }

  private preferences: any[] = [];
  private activeBookings: any[] = [];

  private timeToMinutes(t: string): number {
    if (!t) return 0;
    const parts = t.split(':');
    const h = parseInt(parts[0] || '0', 10);
    const m = parseInt(parts[1] || '0', 10);
    return h * 60 + m;
  }

  private assignments: Map<string, {
    roomId: string;
    roomNumber: string;
    dayOfWeek: number;
    startTime: string;
    endTime: string;
    facultyId: string | null;
    facultyEmail: string | null;
    facultyName: string | null;
    reason: string;
  }> = new Map();

  /**
   * Main choice-based timetable generation process using recursive backtracking
   */
  async allocate(): Promise<{
    allocations: AllocationResult[];
    conflicts: ConflictInfo[];
    successCount: number;
    failureCount: number;
  }> {
    try {
      console.log(`[Allocation] Starting Recursive Backtracking Timetable Generator batch ${this.batchId}, semester ${this.semester}`);

      const sections = await this.fetchCourseSections();
      const classrooms = await this.fetchAvailableClassrooms();

      // Fetch all active bookings once to perform in-memory availability checks
      const bookingsRes = await pool.query(
        `SELECT b.room_id, 
                EXTRACT(DOW FROM b.start_dt AT TIME ZONE 'Asia/Dhaka') as day_of_week,
                (b.start_dt AT TIME ZONE 'Asia/Dhaka')::time::text as start_time,
                (b.end_dt AT TIME ZONE 'Asia/Dhaka')::time::text as end_time
         FROM bookings b
         WHERE b.status IN ('Confirmed', 'Pending', 'PendingAdminApproval')`
      );
      this.activeBookings = bookingsRes.rows;
      
      // Fetch choices with preferred slot details
      const prefRes = await pool.query(
        `SELECT p.*
         FROM faculty_course_preferences p
         ORDER BY p.seniority_rank ASC, p.choice_rank ASC`
      );
      this.preferences = prefRes.rows;
      const preferences = prefRes.rows;

      // Group sections into senior preferences vs forced vs general fallback sections
      // Priority 1: Forced sections (Department Mandates)
      const forcedSections: { section: CourseSection; days: number[]; start: string; end: string; facultyId: string; reason: string }[] = [];
      // Priority 2: Senior faculty sections (Professors, Assoc Professors) with preferences
      const seniorPrefSections: { section: CourseSection; prefs: any[] }[] = [];
      // Priority 3: All remaining sections
      const fallbackSections: CourseSection[] = [];

      const processedSectionIds = new Set<string>();

      // A. Identify forced slots
      for (const section of sections) {
        if (section.assigned_faculty_id && section.day_of_week && section.start_time) {
          forcedSections.push({
            section,
            days: section.day_of_week,
            start: section.start_time,
            end: section.end_time || '11:30',
            facultyId: section.assigned_faculty_id,
            reason: `Department Mandate: ${section.assigned_faculty_name}`
          });
          processedSectionIds.add(section.section_id);
        }
      }

      // B. Identify senior faculty preferences
      const seniorPrefs = preferences.filter(p => p.seniority_rank <= 2);
      for (const section of sections) {
        if (processedSectionIds.has(section.section_id)) continue;
        const sectionPrefs = seniorPrefs.filter(p => p.section_id === section.section_id);
        if (sectionPrefs.length > 0) {
          seniorPrefSections.push({
            section,
            prefs: sectionPrefs
          });
          processedSectionIds.add(section.section_id);
        }
      }

      // Sort senior pref sections by seniority rank of preference (Rank 1 Professors first, then Rank 2 Associate Professors)
      seniorPrefSections.sort((a, b) => {
        const rankA = a.prefs[0]?.seniority_rank ?? 2;
        const rankB = b.prefs[0]?.seniority_rank ?? 2;
        return rankA - rankB;
      });

      // C. All other sections go to fallback
      for (const section of sections) {
        if (!processedSectionIds.has(section.section_id)) {
          fallbackSections.push(section);
        }
      }

      // Clear previous database records for this batch
      await pool.query("DELETE FROM semester_allocations WHERE batch_id = $1", [this.batchId]);
      await pool.query("DELETE FROM allocation_conflicts WHERE batch_id = $1", [this.batchId]);

      // Phase 1: Allocate all forced sections first (non-negotiable constraints)
      for (const item of forcedSections) {
        const requiredCapacity = item.section.enrollment_size;
        const suitableRooms = classrooms.filter((r) => r.capacity >= requiredCapacity);
        let allocated = false;
        
        for (const room of suitableRooms) {
          let allDaysAvailable = true;
          for (const d of item.days) {
            const isAvail = await this.isRoomAvailable(room.room_id, d, item.start, item.end);
            if (!isAvail) {
              allDaysAvailable = false;
              break;
            }
          }
          if (allDaysAvailable) {
            this.assignments.set(item.section.section_id, {
              roomId: room.room_id,
              roomNumber: room.room_number,
              dayOfWeek: item.days[0] ?? 1,
              startTime: item.start,
              endTime: item.end,
              facultyId: item.facultyId,
              facultyEmail: item.section.assigned_faculty_email || null,
              facultyName: item.section.assigned_faculty_name || null,
              reason: item.reason
            });
            allocated = true;
            break;
          }
        }

        if (!allocated) {
          this.conflicts.push({
            section_id: item.section.section_id,
            course_code: item.section.course_code,
            conflict_type: 'ForcedSlotConflict',
            description: `Could not allocate mandated slot for ${item.section.course_code} - all matching rooms are occupied.`,
          });
        }
      }

      // Phase 2 & 3: Backtracking Solver for Seniors and Fallback sections
      const solveSections = [
        ...seniorPrefSections.map(s => ({ type: 'senior' as const, section: s.section, prefs: s.prefs })),
        ...fallbackSections.map(s => ({ type: 'fallback' as const, section: s }))
      ];

      await this.solveBacktracking(solveSections, 0, classrooms);

      // Phase 4: Commit in-memory assignments to database
      for (const [secId, assign] of this.assignments.entries()) {
        const result = await this.recordAllocation(
          secId,
          assign.roomId,
          assign.roomNumber,
          assign.dayOfWeek,
          assign.startTime,
          assign.endTime,
          assign.facultyId,
          assign.facultyEmail,
          assign.facultyName,
          assign.reason
        );
        this.allocations.push(result);
      }

      await this.updateBatchStatus();

      return {
        allocations: this.allocations,
        conflicts: this.conflicts,
        successCount: this.allocations.length,
        failureCount: this.conflicts.length,
      };
    } catch (err) {
      console.error('[Allocation] Error during allocation:', err);
      throw err;
    }
  }

  /**
   * Backtracking Constraint Solver algorithm
   */
  private async solveBacktracking(
    list: Array<{ type: 'senior' | 'fallback'; section: CourseSection; prefs?: any[] }>,
    index: number,
    classrooms: any[]
  ): Promise<boolean> {
    if (index === list.length) {
      return true;
    }

    const current = list[index];
    if (!current) return true;
    const section = current.section;
    const requiredCapacity = section.enrollment_size;
    const suitableRooms = classrooms.filter((r) => r.capacity >= requiredCapacity);

    if (current.type === 'senior' && current.prefs) {
      // Try preferred slots first
      for (const pref of current.prefs) {
        const days = pref.preferred_day_of_week || [0, 3];
        const start = pref.preferred_start_time || '10:00';
        const end = pref.preferred_end_time || '11:30';

        // Try preferred room if specified
        if (pref.preferred_room_id) {
          const prefRoom = classrooms.find(r => r.room_id === pref.preferred_room_id);
          if (prefRoom && prefRoom.capacity >= requiredCapacity) {
            let allDaysAvailable = true;
            for (const d of days) {
              if (!(await this.isRoomAvailable(prefRoom.room_id, d, start, end))) {
                allDaysAvailable = false;
                break;
              }
            }
            if (allDaysAvailable) {
              this.assignments.set(section.section_id, {
                roomId: prefRoom.room_id,
                roomNumber: prefRoom.room_number,
                dayOfWeek: days[0] ?? 1,
                startTime: start,
                endTime: end,
                facultyId: pref.faculty_id || null,
                facultyEmail: pref.faculty_email || null,
                facultyName: pref.faculty_name || null,
                reason: `Senior Choice #${pref.choice_rank}: ${pref.faculty_name}`
              });
              if (await this.solveBacktracking(list, index + 1, classrooms)) return true;
              this.assignments.delete(section.section_id);
            }
          }
        }

        // Try other suitable rooms
        for (const room of suitableRooms) {
          if (room.room_id === pref.preferred_room_id) continue;
          let allDaysAvailable = true;
          for (const d of days) {
            if (!(await this.isRoomAvailable(room.room_id, d, start, end))) {
              allDaysAvailable = false;
              break;
            }
          }
          if (allDaysAvailable) {
            this.assignments.set(section.section_id, {
              roomId: room.room_id,
              roomNumber: room.room_number,
              dayOfWeek: days[0] ?? 1,
              startTime: start,
              endTime: end,
              facultyId: pref.faculty_id || null,
              facultyEmail: pref.faculty_email || null,
              facultyName: pref.faculty_name || null,
              reason: `Senior Choice #${pref.choice_rank}: ${pref.faculty_name} (Fallback Room)`
            });
            if (await this.solveBacktracking(list, index + 1, classrooms)) return true;
            this.assignments.delete(section.section_id);
          }
        }
      }
    }

    // Fallback: Try standard timeslot grid
    const isLab = section.facility_type === 'Lab' || section.course_code.endsWith('L');
        const slotsToUse = isLab ? LAB_SLOTS : THEORY_SLOTS;
        for (const slot of slotsToUse) {
      for (const room of suitableRooms) {
        let allDaysAvailable = true;
        for (const d of slot.days) {
          if (!(await this.isRoomAvailable(room.room_id, d, slot.start, slot.end))) {
            allDaysAvailable = false;
            break;
          }
        }
        if (allDaysAvailable) {
          const sectionPref = this.preferences.find(p => p.section_id === section.section_id);
          const assignedFacId = section.assigned_faculty_id || (sectionPref ? sectionPref.faculty_id : null);
          const assignedFacEmail = section.assigned_faculty_email || (sectionPref ? sectionPref.faculty_email : null);
          const assignedFacName = section.assigned_faculty_name || (sectionPref ? sectionPref.faculty_name : null);

          this.assignments.set(section.section_id, {
            roomId: room.room_id,
            roomNumber: room.room_number,
            dayOfWeek: slot.days[0] ?? 1,
            startTime: slot.start,
            endTime: slot.end,
            facultyId: assignedFacId,
            facultyEmail: assignedFacEmail,
            facultyName: assignedFacName,
            reason: current.type === 'senior' ? 'Senior Preference Fallback' : 'Forced Grid Allocation'
          });
          if (await this.solveBacktracking(list, index + 1, classrooms)) return true;
          this.assignments.delete(section.section_id);
        }
      }
    }

    // If backtracking solver fails to find any room/timeslot for this section,
    // record a conflict and continue resolving subsequent sections.
    this.conflicts.push({
      section_id: section.section_id,
      course_code: section.course_code,
      conflict_type: 'NoSlotAvailable',
      description: `Could not find any available slot for ${section.course_code}-${section.section_number}`
    });

    if (await this.solveBacktracking(list, index + 1, classrooms)) return true;

    this.conflicts.pop();
    return false;
  }

  /**
   * Fetch all unallocated course sections for this semester
   */
  private async fetchCourseSections(): Promise<CourseSection[]> {
    const result = await pool.query(
      `SELECT cs.*, c.course_code, c.course_name, f.full_name_en as assigned_faculty_name, f.designation as assigned_faculty_designation, f.email as assigned_faculty_email
       FROM course_sections cs
       JOIN courses c ON cs.course_id = c.course_id
       LEFT JOIN faculty f ON cs.assigned_faculty_id = f.faculty_id
       WHERE cs.semester = $1
       ORDER BY cs.created_at ASC`,
      [this.semester]
    );
    return result.rows;
  }

  /**
   * Fetch all active classrooms
   */
  private async fetchAvailableClassrooms(): Promise<any[]> {
    const result = await pool.query(
      `SELECT * FROM classrooms WHERE status = 'Active' ORDER BY capacity ASC`
    );
    return result.rows;
  }

  /**
   * Write allocation record to DB
   */
  private async recordAllocation(
    sectionId: string,
    roomId: string,
    roomNumber: string,
    dayOfWeek: number,
    start: string,
    end: string,
    facultyId: string | null,
    facultyEmail: string | null,
    facultyName: string | null,
    reason: string
  ): Promise<AllocationResult> {
    const allocRes = await pool.query(
      `INSERT INTO semester_allocations (
         batch_id, section_id, room_id, allocated_day_of_week, 
         allocated_start_time, allocated_end_time, status, 
         allocation_reason, allocated_faculty_id, 
         allocated_faculty_email, allocated_faculty_name
       )
       VALUES ($1, $2, $3, $4, $5, $6, 'Allocated', $7, $8, $9, $10)
       RETURNING *`,
      [this.batchId, sectionId, roomId, dayOfWeek, start, end, reason, facultyId, facultyEmail, facultyName]
    );

    const result: AllocationResult = {
      allocation_id: allocRes.rows[0].allocation_id,
      section_id: sectionId,
      room_id: roomId,
      room_number: roomNumber,
      allocated_start_time: start,
      allocated_end_time: end,
      allocated_day_of_week: dayOfWeek,
    };
    if (facultyId) {
      result.allocated_faculty_id = facultyId;
    }
    return result;
  }

  /**
   * Check room availability in-memory and against fixed DB bookings
   */
  private async isRoomAvailable(
    roomId: string,
    dayOfWeek: number,
    startTime: string,
    endTime: string
  ): Promise<boolean> {
    const startMin = this.timeToMinutes(startTime);
    const endMin = this.timeToMinutes(endTime);

    // Check against active bookings loaded in memory
    for (const b of this.activeBookings) {
      if (b.room_id === roomId && Number(b.day_of_week) === dayOfWeek) {
        const bStartMin = this.timeToMinutes(b.start_time);
        const bEndMin = this.timeToMinutes(b.end_time);
        if (bStartMin < endMin && bEndMin > startMin) {
          return false;
        }
      }
    }

    // Check against in-memory allocations
    for (const [secId, assign] of this.assignments.entries()) {
      if (assign.roomId === roomId && assign.dayOfWeek === dayOfWeek) {
        const aStartMin = this.timeToMinutes(assign.startTime);
        const aEndMin = this.timeToMinutes(assign.endTime);
        if (aStartMin < endMin && aEndMin > startMin) {
          return false;
        }
      }
    }

    return true;
  }

  /**
   * Update batch status and record conflicts
   */
  private async updateBatchStatus(): Promise<void> {
    const successCount = this.allocations.length;
    const failureCount = this.conflicts.length;

    await pool.query(
      `UPDATE allocation_batches
       SET successfully_allocated = $1, failed_allocations = $2, total_sections = $3, status = 'ReviewConflicts'
       WHERE batch_id = $4`,
      [successCount, failureCount, successCount + failureCount, this.batchId]
    );

    for (const conflict of this.conflicts) {
      await pool.query(
        `INSERT INTO allocation_conflicts (batch_id, section_id, conflict_type, description)
         VALUES ($1, $2, $3, $4)`,
        [this.batchId, conflict.section_id, conflict.conflict_type, conflict.description]
      );
    }
  }

  /**
   * Confirm allocation - convert allocations to actual bookings
   */
  async confirmAllocation(adminId: string): Promise<{ confirmedBookings: number }> {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      let confirmedCount = 0;

      const allocRes = await client.query(
        `SELECT sa.*, cs.course_id, c.course_code, c.course_name, cs.section_number, cs.enrollment_size
         FROM semester_allocations sa
         JOIN course_sections cs ON sa.section_id = cs.section_id
         JOIN courses c ON cs.course_id = c.course_id
         WHERE sa.batch_id = $1 AND sa.status = 'Allocated'`,
        [this.batchId]
      );

      const allocations = allocRes.rows;

      for (const alloc of allocations) {
        const semesterStartDate = await this.getSemesterStartDate();
        const bookingDate = this.getNextOccurrenceDate(semesterStartDate, alloc.allocated_day_of_week);

        const startDt = new Date(`${bookingDate}T${alloc.allocated_start_time}`);
        const endDt = new Date(`${bookingDate}T${alloc.allocated_end_time}`);
        
        const semesterEndDate = new Date(startDt);
        semesterEndDate.setDate(semesterEndDate.getDate() + 14 * 7); // 14 weeks

        // Update finalized timing inside course_sections table!
        await client.query(
          `UPDATE course_sections 
           SET day_of_week = $1, start_time = $2, end_time = $3, assigned_faculty_id = $4
           WHERE section_id = $5`,
          [[alloc.allocated_day_of_week], alloc.allocated_start_time, alloc.allocated_end_time, alloc.allocated_faculty_id || null, alloc.section_id]
        );

        // Create recurring series record
        const seriesRes = await client.query(
          `INSERT INTO recurring_series (faculty_id, room_id, pattern, days_of_week, start_date, end_date, start_time, end_time, total_instances, confirmed_count, skipped_count, status)
           VALUES ($1, $2, 'Weekly', $3, $4, $5, $6, $7, 14, 14, 0, 'Active')
           RETURNING series_id`,
          [
            alloc.allocated_faculty_id || null,
            alloc.room_id,
            [alloc.allocated_day_of_week],
            startDt,
            semesterEndDate,
            alloc.allocated_start_time,
            alloc.allocated_end_time
          ]
        );
        const seriesId = seriesRes.rows[0].series_id;

        // Loop 14 times for 14 weeks
        // reqId includes batch_id prefix so re-confirms after delete never collide
        const batchPrefix = this.batchId.substring(0, 6);
        for (let i = 0; i < 14; i++) {
          const reqId = `SEM-${this.semester}-${batchPrefix}-${alloc.section_id.substring(0, 6)}-W${i}`;
          
          const currentStart = new Date(startDt);
          currentStart.setDate(currentStart.getDate() + (i * 7));
          
          const currentEnd = new Date(endDt);
          currentEnd.setDate(currentEnd.getDate() + (i * 7));

          if (currentStart >= currentEnd) {
            console.log("INVALID TIMESTAMP DETECTED!", { startDt, endDt, currentStart, currentEnd, i, alloc });
          }

          await client.query(
            `INSERT INTO bookings (booking_request_id, faculty_id, room_id, course_code, course_name, class_size, start_dt, end_dt, booking_type, status, notes, series_id)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'Recurring', 'Confirmed', $9, $10)
             ON CONFLICT (booking_request_id) DO NOTHING`,
            [
              reqId,
              alloc.allocated_faculty_id || null,
              alloc.room_id,
              alloc.course_code,
              alloc.course_name || alloc.course_code,
              alloc.enrollment_size,
              currentStart,
              currentEnd,
              alloc.allocation_reason || 'Auto-allocated semester booking',
              seriesId
            ]
          );
        }

        await client.query(`UPDATE semester_allocations SET status = 'Confirmed' WHERE allocation_id = $1`, [
          alloc.allocation_id,
        ]);

        await logAudit(
          adminId,
          'Admin',
          'SEMESTER_ALLOCATION_CONFIRMED',
          'Booking',
          seriesId,
          'status',
          'Allocated',
          'Confirmed'
        );

        confirmedCount++;
      }

      await client.query(`UPDATE allocation_batches SET status = 'Confirmed' WHERE batch_id = $1`, [this.batchId]);

      await client.query('COMMIT');
      return { confirmedBookings: confirmedCount };
    } catch (err) {
      await client.query('ROLLBACK');
      console.error('[Allocation] Error confirming allocation:', err);
      throw err;
    } finally {
      client.release();
    }
  }

  private async getSemesterStartDate(): Promise<Date> {
    const result = await pool.query(
      `SELECT start_date FROM academic_calendar
       WHERE event_type = 'SemesterStart'
       AND EXTRACT(YEAR FROM start_date) = EXTRACT(YEAR FROM CURRENT_DATE)
       LIMIT 1`
    );

    if (result.rows.length > 0) {
      return new Date(result.rows[0].start_date);
    }

    const today = new Date();
    const daysUntilMonday = (1 - today.getDay() + 7) % 7;
    const nextMonday = new Date(today);
    nextMonday.setDate(today.getDate() + daysUntilMonday);
    return nextMonday;
  }

  private getNextOccurrenceDate(startDate: Date, dayOfWeek: number): string {
    const current = new Date(startDate);
    const currentDayOfWeek = current.getDay();
    let daysToAdd = dayOfWeek - currentDayOfWeek;

    if (daysToAdd < 0) {
      daysToAdd += 7;
    }

    current.setDate(current.getDate() + daysToAdd);
    return current.toISOString().split('T')[0] || '';
  }
}
