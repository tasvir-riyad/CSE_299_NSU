# Classroom Booking System (CBS) - System Overview

The **Classroom Booking System (CBS)** is a full-stack web application designed to automate, optimize, and manage the allocation of university classrooms. It streamlines both bulk semester-long course scheduling and ad-hoc (one-time) room bookings while enforcing strict capacity constraints, time conflict avoidance, and faculty seniority priorities.

## 1. High-Level Architecture

The system is built using a modern decoupled architecture:

- **Frontend (Client)**: Built with **Next.js** (React) and styled with Tailwind CSS. It provides role-based interfaces for Students/Guests (Lobby), Faculty (Booking Portal), and Administrators (Admin Dashboard).
- **Backend (API)**: A **Node.js / Express** server built with TypeScript. It acts as the central business logic layer, handling authentication, allocation algorithms, and database transactions.
- **Database**: A relational **PostgreSQL** database. It acts as the single source of truth for all structured data (users, classrooms, courses, bookings, and recurring series).

---

## 2. Core Modules & Flow

### A. Bulk Semester Allocation Engine
The most complex part of the system is the automated allocation of a full semester's courses to available rooms.

**Flow:**
1. **Data Ingestion**: The Admin uploads a CSV file containing the upcoming semester's courses and sections.
2. **Parsing & Batching**: The backend parses the CSV, validates the data, and creates an `allocation_batch` with a status of `Draft`.
3. **Algorithmic Allocation**: 
   - The engine iterates through every course section.
   - It searches for available `classrooms` that match the required `facilityType` (e.g., Lab or Lecture) and have a `capacity` $\ge$ `enrollmentPerSection`.
   - It checks the proposed time slot against all existing allocations in the batch and existing permanent bookings in the database to prevent double-booking.
4. **Conflict Generation**: If a section cannot be placed (e.g., no room large enough, or all rooms are booked at that time), the engine logs an `allocation_conflict`.
5. **Review & Adjustment**: The Admin reviews the drafted batch via the UI. They can manually resolve conflicts by overriding times or forcing room assignments.
6. **Confirmation**: Once reviewed, the Admin clicks "Confirm & Create Bookings". The system locks the batch and translates all successful allocations into permanent 14-week `recurring_series` records in the `bookings` table.

### B. One-Time Room Bookings (Faculty)
Faculty members often need to book rooms for makeup classes, meetings, or exams.

**Flow:**
1. **Search & Heatmap**: A Faculty member navigates to the "Book Room" tab. They select a date, time, and required capacity. A visual **Heatmap** shows room availability across the day.
2. **Booking Request**: The user submits a booking request for a specific time slot.
3. **Validation & Anti-Double-Booking**: The backend intercepts the request and runs a transaction against the `bookings` table. It strictly checks:
   - `start_dt < end_dt`
   - Does this exact time slot overlap with an existing `Confirmed` or `Pending` booking for this room?
4. **Priority Queueing**: If multiple faculty members request the same room at the same time, the system uses a **Seniority Priority Queue**. The booking from the faculty member with the highest seniority rank is automatically confirmed, while the others are placed on a Waitlist.
5. **Database Commit**: The booking is saved with a status of `Confirmed`, `PendingAdminApproval`, or `Waitlisted`.

### C. Public Lobby Display
Students and visitors need to see real-time schedules without logging in.

**Flow:**
1. **Lobby Interface**: Users navigate to the public `/lobby` route.
2. **Data Fetching**: The frontend polls the backend `/api/bookings/lobby` endpoint.
3. **Live Timetable**: The system queries PostgreSQL for all `Confirmed` bookings happening *today*. It formats them into a clean, read-only chronological list, grouped by building/floor.

### D. Admin Dashboard & Analytics
Admins require a bird's-eye view of system utilization.

**Flow:**
1. **Metrics Aggregation**: The frontend requests data from `/api/admin/analytics`.
2. **Data Processing**: The backend runs aggregation queries on PostgreSQL (e.g., counting total bookings, calculating average room utilization rates, identifying peak booking hours).
3. **Visualization**: The Next.js frontend uses charting libraries (e.g., Recharts) to render interactive graphs, allowing the Admin to make data-driven decisions about room management.

---

## 3. Database Schema Overview

The PostgreSQL database relies on strict referential integrity and constraints. Key tables include:

- `users` / `faculty`: Stores user credentials, roles (Admin/Faculty), and seniority rankings.
- `classrooms` & `buildings`: Stores spatial data, room capacities, and operating hours.
- `courses` & `course_sections`: Stores academic curriculum data used by the allocation engine.
- `allocation_batches` & `semester_allocations`: Temporary tables used to stage data during the bulk algorithmic allocation phase.
- `bookings`: The central ledger. It records both ad-hoc events and occurrences linked to a `recurring_series`. It relies on strict `CHECK (start_dt < end_dt)` constraints to prevent temporal paradoxes.
