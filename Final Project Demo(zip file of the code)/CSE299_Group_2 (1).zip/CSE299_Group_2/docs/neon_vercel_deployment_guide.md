# Deployment Guide: Neon & Vercel

This guide covers how to deploy the **Classroom Booking System (CBS)** using **Neon** (Serverless PostgreSQL) for the database and **Vercel** for the Next.js frontend. 

Since CBS has a dedicated Node.js/Express backend, we recommend deploying the backend to a platform like **Render** or **Railway**, and connecting the Vercel frontend to it.

---

## Part 1: Setting up the Database on Neon

Neon provides serverless PostgreSQL that scales automatically and is perfect for modern web applications.

1. **Create a Neon Account**: Go to [neon.tech](https://neon.tech/) and sign up.
2. **Create a New Project**:
   - Name your project (e.g., `cbs-production`).
   - Select the Postgres version (15 or newer is recommended).
   - Select a region closest to your intended user base.
3. **Get Your Connection String**:
   - Once the database is created, navigate to the **Dashboard**.
   - Under "Connection Details", copy the standard Postgres connection string. It will look like this:  
     `postgresql://<user>:<password>@<endpoint>.neon.tech/neondb?sslmode=require`
4. **Initialize the Database**:
   - You need to run the `schema.sql` file to create the necessary tables.
   - You can do this via the **Neon SQL Editor** in their web console by pasting the contents of `Backend/schema.sql` and running it.
   - Alternatively, connect via a local tool like `psql` or `pgAdmin` using the connection string and execute the schema.

---

## Part 2: Deploying the Backend (Render / Railway)

Because the backend is a stateful Node.js Express server running background processes (like the Allocation Engine), deploying it to a containerized platform like Render or Railway is highly recommended over Vercel Serverless.

### Using Render.com (Free Tier Available)
1. **Push your code to GitHub**: Ensure the `Backend` directory is pushed to a GitHub repository.
2. **Create a New Web Service** on [Render](https://render.com/).
3. **Connect Repository**: Select your GitHub repo.
4. **Configuration**:
   - **Root Directory**: `Backend`
   - **Environment**: `Node`
   - **Build Command**: `npm install && npm run build` *(Make sure your package.json has a build script for compiling TypeScript: `tsc`)*
   - **Start Command**: `node dist/index.js` *(Or whichever entry file you use)*
5. **Environment Variables**:
   - Add `DATABASE_URL` and paste the connection string you copied from Neon.
   - Add `PORT` and set it to `10000` (Render's default).
   - Add `JWT_SECRET` and set a strong, random string.
6. **Deploy**: Click "Create Web Service". Once deployed, Render will give you a backend URL (e.g., `https://cbs-backend.onrender.com`).

---

## Part 3: Deploying the Frontend on Vercel

Vercel is the creator of Next.js and provides the absolute best hosting experience for the frontend.

1. **Create a Vercel Account**: Go to [vercel.com](https://vercel.com/) and sign in with GitHub.
2. **Import Project**:
   - Click **"Add New..." -> "Project"**.
   - Import the GitHub repository containing your CBS code.
3. **Configure the Build**:
   - **Root Directory**: Click "Edit" and select the `Frontend/classroom_booking_system` folder.
   - **Framework Preset**: Vercel will automatically detect **Next.js**.
   - **Build Command**: Leave as default (`npm run build`).
4. **Environment Variables**:
   - Open the "Environment Variables" dropdown.
   - Add your API URL pointing to the backend you just deployed:
     - **Name**: `NEXT_PUBLIC_API_URL`
     - **Value**: `https://cbs-backend.onrender.com/api` *(Replace with your actual backend URL)*
5. **Deploy**:
   - Click **Deploy**. Vercel will build the Next.js application and deploy it globally.
   - Once finished, you will receive a public Vercel URL (e.g., `https://cbs-frontend.vercel.app`).

---

## Post-Deployment Checklist

- **CORS Configuration**: Ensure your Node.js backend is configured to accept requests from your new Vercel domain. In your `Backend/src/index.ts`, update the `cors` settings:
  ```javascript
  app.use(cors({
      origin: ['http://localhost:3000', 'https://cbs-frontend.vercel.app'], // Add your Vercel URL
      credentials: true
  }));
  ```
  *(Remember to push this change to GitHub so Render redeploys the backend).*
- **Database Connection Pooling**: Neon uses `PgBouncer` for connection pooling. Ensure your backend Postgres client is using the pooled connection string (usually ending in `-pooler.neon.tech` depending on your Neon plan) if you expect high traffic.
- **Admin Setup**: Run the `Backend/src/seed.ts` script against your Neon database to generate the default Admin user so you can log into the Vercel production site.
