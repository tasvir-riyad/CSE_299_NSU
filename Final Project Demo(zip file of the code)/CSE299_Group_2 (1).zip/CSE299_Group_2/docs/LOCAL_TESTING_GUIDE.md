# Local Testing Guide - Classroom Booking System

A comprehensive guide for testing the Classroom Booking System locally, covering backend APIs, frontend functionality, database operations, and end-to-end workflows.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Project Structure](#project-structure)
3. [Setup](#setup)
4. [Running the Application](#running-the-application)
5. [Backend Testing](#backend-testing)
6. [Frontend Testing](#frontend-testing)
7. [Database Testing](#database-testing)
8. [API Testing](#api-testing)
9. [Priority Engine Testing](#priority-engine-testing)
10. [Manual Testing Workflows](#manual-testing-workflows)
11. [Troubleshooting](#troubleshooting)

---

## Prerequisites

- **Node.js**: v18+ (verify with `node --version`)
- **npm**: v9+ (verify with `npm --version`)
- **PostgreSQL**: Database running and accessible
- **Git**: For version control
- **API Tool**: Postman, Insomnia, or cURL for API testing
- **Browser**: Chrome, Firefox, Safari, or Edge for frontend testing

---

## Project Structure

```
CSE299/
├── Backend/                    # Express.js + TypeScript backend
│   ├── src/
│   │   ├── index.ts           # Server entry point
│   │   ├── db.ts              # Database connection pool
│   │   ├── jobs.ts            # Background jobs engine
│   │   ├── priorityEngine.ts   # Booking priority resolution
│   │   ├── seed.ts            # Database seeding script
│   │   ├── test_priority.ts    # Priority engine test suite
│   │   └── routes/            # API endpoints
│   │       ├── auth.ts
│   │       ├── faculty.ts
│   │       ├── classrooms.ts
│   │       ├── bookings.ts
│   │       ├── admin.ts
│   │       └── reports.ts
│   ├── .env                   # Environment variables
│   └── package.json           # Dependencies and scripts
├── Frontend/
│   └── classroom_booking_system/  # Next.js + React frontend
│       ├── app/               # Next.js app directory
│       ├── public/            # Static assets
│       └── package.json
└── LOCAL_TESTING_GUIDE.md     # This file
```

---

## Setup

### 1. Install Dependencies

```bash
# Backend dependencies
cd Backend
npm install

# Frontend dependencies
cd ../Frontend/classroom_booking_system
npm install

# Return to root
cd ../../
```

### 2. Environment Configuration

Create/verify `.env` file in the Backend directory with:

```env
# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=classroom_booking_db
DB_USER=postgres
DB_PASSWORD=your_password

# Server
PORT=5001
NODE_ENV=development

# Other configs as needed
```

### 3. Database Setup

```bash
# Create database (if not exists)
createdb classroom_booking_db

# Seed the database with test data
cd Backend
npm run seed  # or ts-node src/seed.ts
```

---

## Running the Application

### Start Backend Server

```bash
cd Backend
npm run dev
```

Expected output:
```
🚀 Backend Engine spinning up on port 5001
🔄 Background Jobs Engine spin-up...
[Job: Auto-Cancel No-Show] Running scan...
[Job: Booking Reminders] Running scan...
```

**Backend runs on**: `http://localhost:5001`

### Start Frontend Server

```bash
cd Frontend/classroom_booking_system
npm run dev
```

Expected output:
```
▲ Next.js 16.2.9
- Local:         http://localhost:3000
✓ Ready in 295ms
```

**Frontend runs on**: `http://localhost:3000`

---

## Backend Testing

### 1. Health Check

```bash
curl http://localhost:5001/health
```

### 2. TypeScript Compilation Check

```bash
cd Backend
npx tsc --noEmit
```

### 3. Running Built-in Tests

#### Priority Engine Tests

Run comprehensive tests for the booking priority resolution system:

```bash
cd Backend
npx ts-node src/test_priority.ts
```

This test verifies:
- ✅ No-Bump Policy (confirmed bookings aren't bumped by higher-priority faculty)
- ✅ Waitlist Queue Sorting (proper ordering by faculty seniority)
- ✅ Waitlist Promotion (when confirmed bookings are cancelled)
- ✅ Faculty seniority-based conflict resolution

**Expected output**:
```
🧪 Starting Priority Conflict and Promotion Engine Tests...
Using test profiles: 
- Dr. Arshad (Professor, Rank 1)
- Dr. Nusrat (Assoc Professor, Rank 2)
- Samiul (Lecturer, Rank 4)

Step 1: Lecturer Samiul submits a booking request...
Result: Booking status set to Confirmed. Reason: No conflicts.
✓ No-Bump Policy successfully verified...
...
🎉 ALL TESTS PASSED SUCCESSFULLY!
```

---

## Frontend Testing

### 1. Visual Inspection

Open `http://localhost:3000` in your browser and verify:
- ✅ Page loads without errors
- ✅ Navigation menu is present
- ✅ Responsive design works on mobile/tablet/desktop
- ✅ No console errors (check browser DevTools: F12)

### 2. Check Console for Errors

```javascript
// In browser console (F12 > Console tab)
// Should show no errors, only informational messages
```

### 3. Build Test

```bash
cd Frontend/classroom_booking_system
npm run build
```

Expected output:
```
✓ Compiled successfully
...
```

### 4. Production Build Preview

```bash
npm run build
npm start
```

Then visit `http://localhost:3000`

---

## Database Testing

### 1. Connect to PostgreSQL

```bash
psql -h localhost -U postgres -d classroom_booking_db
```

### 2. Verify Database Schema

```sql
-- List all tables
\dt

-- Expected tables:
-- - faculty
-- - classrooms
-- - bookings
-- - waitlist_entries
-- - reports
```

### 3. Check Sample Data

```sql
-- View faculty
SELECT faculty_id, full_name_en, seniority_rank FROM faculty LIMIT 5;

-- View classrooms
SELECT room_id, room_code, capacity FROM classrooms LIMIT 5;

-- View bookings
SELECT booking_id, status, start_dt, end_dt FROM bookings LIMIT 5;

-- View waitlist
SELECT * FROM waitlist_entries LIMIT 5;
```

### 4. Test Database Connection

```bash
cd Backend
npx ts-node -e "
import pool from './src/db';
pool.query('SELECT NOW()', (err, res) => {
  if (err) console.error('Connection failed:', err);
  else console.log('✓ Database connected:', res.rows[0].now);
  process.exit();
});
"
```

---

## API Testing

### Using cURL

#### Authentication

```bash
# Login (get token)
curl -X POST http://localhost:5001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"faculty@email.com","password":"password"}'
```

#### Faculty Endpoints

```bash
# Get all faculty
curl http://localhost:5001/api/faculty

# Get single faculty
curl http://localhost:5001/api/faculty/:facultyId
```

#### Classroom Endpoints

```bash
# Get all classrooms
curl http://localhost:5001/api/classrooms

# Get classroom availability
curl "http://localhost:5001/api/classrooms/:roomId/availability?date=2024-06-21"
```

#### Booking Endpoints

```bash
# Create booking
curl -X POST http://localhost:5001/api/bookings \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "room_id":"room-uuid",
    "course_code":"CSE-101",
    "course_name":"Intro to CS",
    "class_size":30,
    "start_dt":"2024-06-21T10:00:00",
    "end_dt":"2024-06-21T12:00:00",
    "booking_type":"OneTime"
  }'

# Get user bookings
curl http://localhost:5001/api/bookings/my \
  -H "Authorization: Bearer YOUR_TOKEN"

# Cancel booking
curl -X PUT http://localhost:5001/api/bookings/:bookingId/cancel \
  -H "Authorization: Bearer YOUR_TOKEN"
```

#### Reports Endpoints

```bash
# Get booking report
curl http://localhost:5001/api/reports/bookings

# Get utilization report
curl http://localhost:5001/api/reports/utilization
```

### Using Postman/Insomnia

1. **Import API Collection**:
   - Create new environment with `BASE_URL=http://localhost:5001`
   - Create requests for each endpoint listed above

2. **Test Workflow**:
   - Login → Get token
   - Use token in Authorization header for subsequent requests
   - Test CRUD operations on bookings
   - Verify error handling

---

## Priority Engine Testing

### Scenario 1: Basic No-Bump Policy

**Objective**: Verify that confirmed bookings aren't bumped by higher-priority faculty

**Steps**:
1. Lecturer books NAC-301 for 10:00-12:00 → Status: **Confirmed**
2. Professor (higher priority) books same slot → Status: **Waitlisted**
3. Lecturer cancels → Professor gets **Promoted to Confirmed**

**Manual Test**:
```bash
cd Backend
npx ts-node src/test_priority.ts
```

### Scenario 2: Waitlist Queue Sorting

**Objective**: Verify waitlist entries are sorted by faculty seniority

**Steps**:
1. Lecturer books slot → Confirmed
2. Associate Prof requests same slot → Waitlisted (rank 2)
3. Professor requests same slot → Waitlisted (rank 1)
4. Lecturer cancels

**Expected**: Professor (rank 1) promoted first, then Associate Prof

---

## Manual Testing Workflows

### Workflow 1: Complete Booking Process

```
1. Login as Faculty Member
   - Navigate to http://localhost:3000
   - Click "Login"
   - Enter credentials (test@email.com / password)

2. Search Available Classrooms
   - Select date and time range
   - Filter by capacity, building, etc.
   - View available slots (green = available, red = booked)

3. Create Booking
   - Select classroom and time slot
   - Enter course code, name, class size
   - Select booking type (One-time, Recurring, Daily)
   - Click "Request Booking"

4. Verify Booking Status
   - Navigate to "My Bookings"
   - Status should be "Confirmed" (if no conflicts)
   - Or "Waitlisted" (if conflict with higher-priority faculty)

5. View Confirmation
   - Email notification (if configured)
   - SMS reminder (if configured)
```

### Workflow 2: Handling Conflicts

```
1. Book NAC-301 for 10:00-12:00 as Lecturer A

2. Try to book NAC-301 for 10:30-11:30 as Professor B
   - Should show "Conflict with existing booking"
   - Option to join waitlist

3. Join waitlist as Professor B

4. When Lecturer A cancels, Professor B should be notified
   - Notification: "Booking promoted from waitlist"
```

### Workflow 3: Admin Functions

```
1. Login as Administrator
   - Use admin credentials

2. View All Bookings
   - Filter by status, faculty, room, date
   - Export as CSV/PDF

3. View Utilization Report
   - Peak hours analysis
   - Room occupancy rates
   - Department statistics

4. Manage Faculty
   - View faculty list
   - Update seniority ranks
   - Enable/disable booking privileges
```

---

## Troubleshooting

### Backend Issues

#### Port Already in Use

```bash
# Find process on port 5001
lsof -i :5001

# Kill process
kill -9 <PID>
```

#### Database Connection Failed

```bash
# Check PostgreSQL is running
pg_isready -h localhost -p 5432

# Verify environment variables
cat Backend/.env

# Test connection
psql -h localhost -U postgres -d classroom_booking_db
```

#### TypeScript Compilation Error

```bash
# Clear and reinstall node_modules
cd Backend
rm -rf node_modules package-lock.json
npm install
npm run dev
```

### Frontend Issues

#### Port 3000 Already in Use

```bash
# Kill process on port 3000
lsof -i :3000
kill -9 <PID>
```

#### Module Not Found

```bash
cd Frontend/classroom_booking_system
npm install
npm run dev
```

#### Build Fails

```bash
npm run build

# If still fails, check for TypeScript errors
npx tsc --noEmit
```

### Common Errors & Solutions

| Error | Solution |
|-------|----------|
| `ECONNREFUSED 127.0.0.1:5432` | PostgreSQL not running. Start with `brew services start postgresql` |
| `Cannot find module 'express'` | Run `npm install` in Backend directory |
| `Port 3000 is already in use` | Kill process: `kill -9 $(lsof -t -i:3000)` |
| `Unexpected token <` (in frontend) | Clear `.next` folder: `rm -rf Frontend/classroom_booking_system/.next` |
| `Test failed: Initial booking should have been Confirmed` | Database not seeded. Run `npx ts-node src/seed.ts` |

---

## Performance Testing

### Load Testing API Endpoints

Using Apache Bench:

```bash
# Test API endpoint with 100 requests, 10 concurrent
ab -n 100 -c 10 http://localhost:5001/api/classrooms

# Expected: <200ms average response time
```

### Memory Usage Check

```bash
# Monitor process memory
ps aux | grep "node\|next"

# Backend should use <200MB
# Frontend should use <300MB
```

---

## Browser DevTools Testing

### 1. Performance Profiling

```
1. Open http://localhost:3000
2. Press F12 (or Cmd+Opt+I on Mac)
3. Go to Performance tab
4. Click record
5. Interact with application for 5-10 seconds
6. Stop recording
7. Review FCP, LCP, CLS metrics
```

### 2. Network Inspection

```
1. Go to Network tab
2. Reload page
3. Verify:
   - All requests return 200 status
   - No failed requests (red entries)
   - File sizes are reasonable (<1MB per request)
```

### 3. Console Errors

```
1. Go to Console tab
2. Should show no red error messages
3. Warnings are acceptable
```

---

## Testing Checklist

### Backend
- [ ] Server starts without errors
- [ ] Health endpoint responds
- [ ] Database connection established
- [ ] All routes accessible
- [ ] Priority engine tests pass
- [ ] Background jobs running

### Frontend
- [ ] Application loads at localhost:3000
- [ ] No console errors
- [ ] Navigation works
- [ ] Forms can be submitted
- [ ] Responsive on mobile
- [ ] Production build succeeds

### Database
- [ ] All tables created
- [ ] Seed data loaded
- [ ] Queries execute correctly
- [ ] No connection issues

### API
- [ ] Authentication works
- [ ] CRUD operations function
- [ ] Error handling proper
- [ ] Response times acceptable

---

## Additional Resources

- [Express.js Documentation](https://expressjs.com/)
- [Next.js Documentation](https://nextjs.org/docs)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)

---

## Quick Start Commands

```bash
# Full setup from scratch
npm install
cd Backend && npm install && cd ..
cd Frontend/classroom_booking_system && npm install && cd ../../

# Start both servers
# Terminal 1: Backend
cd Backend && npm run dev

# Terminal 2: Frontend
cd Frontend/classroom_booking_system && npm run dev

# Run priority engine tests
cd Backend && npx ts-node src/test_priority.ts

# Database seeding
cd Backend && npx ts-node src/seed.ts
```

---

**Last Updated**: June 21, 2026
**Version**: 1.0
**Maintained By**: Development Team
