# Quick Start - Bulk Semester Allocation

## ⚡ 30-Second Setup

### Prerequisites
- Backend running: `npm run dev` in `Backend/`
- PostgreSQL running
- Admin UUID ready

### In 3 Curl Commands

```bash
# 1️⃣ Create allocation
curl -X POST http://localhost:3000/api/admin/allocate-semester \
  -H "Content-Type: application/json" \
  -d '{
    "semester": "Spring2026",
    "adminId": "550e8400-e29b-41d4-a716-446655440000",
    "courses": [
      {"courseCode": "CSE101", "section": "01", "enrollment": 45, "daysOfWeek": [1, 3], "startTime": "10:00", "endTime": "11:30"},
      {"courseCode": "CSE201", "section": "01", "enrollment": 55, "daysOfWeek": [2, 4], "startTime": "14:00", "endTime": "15:30"}
    ]
  }'

# Copy the batchId from response

# 2️⃣ View results
curl http://localhost:3000/api/admin/allocations/batch/{BATCH_ID}

# 3️⃣ Confirm & export
curl -X POST http://localhost:3000/api/admin/confirm-allocation/{BATCH_ID} \
  -H "Content-Type: application/json" \
  -d '{"adminId": "550e8400-e29b-41d4-a716-446655440000"}'

curl http://localhost:3000/api/admin/allocations/export/{BATCH_ID} > schedule.csv
```

## 📋 Course Data Format

Minimal example:
```json
{
  "courseCode": "CSE101",
  "section": "01",
  "enrollment": 45
}
```

Full example:
```json
{
  "courseCode": "CSE101",
  "courseName": "Introduction to Computing",
  "departmentId": "550e8400-e29b-41d4-a716-446655440001",
  "section": "01",
  "enrollment": 45,
  "daysOfWeek": [1, 3],
  "startTime": "10:00",
  "endTime": "11:30",
  "facilityType": "Lecture"
}
```

## 🎯 Workflow

```
Prepare Courses
    ↓
POST /allocate-semester
    ↓
GET /allocations/batch/{id}  ← Review conflicts
    ↓
PUT /allocation/{id}  ← Adjust if needed
    ↓
POST /confirm-allocation/{id}  ← Create bookings
    ↓
GET /allocations/export/{id}  ← Download schedule
```

## 🔍 Response Examples

**Success Response:**
```json
{
  "batchId": "uuid...",
  "semester": "Spring2026",
  "successCount": 47,
  "failureCount": 3,
  "conflicts": [
    {
      "course_code": "CSE401",
      "conflict_type": "NoSuitableRoom",
      "description": "No room with capacity >= 120"
    }
  ]
}
```

**Conflict Types:**
- `NoSuitableRoom` - No classroom big enough
- `TimeConflict` - All preferred times booked
- `FacilityTypeMismatch` - No lab/lecture hall available

## 🛠️ Troubleshooting

| Problem | Solution |
|---------|----------|
| Batch not found | Check batchId spelling |
| Foreign key error | Ensure departmentId exists in DB |
| No allocations | Check enrollment vs room capacity |
| "Missing parameters" | Include all required fields |

## 📞 Need Help?

1. See full API: `BULK_ALLOCATION_API.md`
2. Run tests: `bash test-allocation.sh`
3. Check code: `Backend/src/allocationEngine.ts`

---

**Next Steps:**
- Build frontend upload UI
- Integrate email notifications
- Add conflict resolution wizard
