"use client";

import { useEffect, useState } from "react";

type BackendHealth = {
  status: "ok" | "error";
  serverTime?: string;
  message?: string;
};

const backendBaseUrl = typeof window !== 'undefined' && !window.location.hostname.includes('localhost') && window.location.hostname !== '127.0.0.1'
  ? "https://cse-299-classroom-booking-system.onrender.com"
  : (process.env.NEXT_PUBLIC_BACKEND_URL ?? "http://127.0.0.1:5001");

export default function BackendStatus() {
  const [health, setHealth] = useState<BackendHealth | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    const loadHealth = async () => {
      try {
        const response = await fetch(`${backendBaseUrl}/api/health`, {
          cache: "no-store",
        });
        const data = (await response.json()) as BackendHealth;

        if (!cancelled) {
          setHealth(data);
          setLoading(false);
        }
      } catch {
        if (!cancelled) {
          setHealth({ status: "error", message: "Unable to reach backend health endpoint" });
          setLoading(false);
        }
      }
    };

    loadHealth();
    const interval = window.setInterval(loadHealth, 30000);

    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, []);

  const isHealthy = health?.status === "ok";

  return (
    <div className="rounded-2xl border border-white/10 bg-slate-950/55 p-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.24em] text-slate-400">
            Backend link
          </p>
          <p className="mt-2 text-sm font-medium text-white">
            {loading ? "Checking live API..." : isHealthy ? "Backend is reachable" : "Backend unavailable"}
          </p>
        </div>
        <span
          className={`rounded-full px-3 py-1 text-xs font-semibold ${
            loading
              ? "bg-slate-500/15 text-slate-200"
              : isHealthy
                ? "bg-emerald-400/15 text-emerald-100"
                : "bg-rose-400/15 text-rose-100"
          }`}
        >
          {loading ? "Loading" : isHealthy ? "Online" : "Offline"}
        </span>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border border-white/10 bg-white/5 p-3">
          <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">
            API
          </p>
          <p className="mt-2 text-sm text-slate-100">{backendBaseUrl}/api/health</p>
        </div>
        <div className="rounded-xl border border-white/10 bg-white/5 p-3">
          <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">
            Server time
          </p>
          <p className="mt-2 text-sm text-slate-100">
            {isHealthy && health?.serverTime ? health.serverTime : health?.message ?? "Waiting for response"}
          </p>
        </div>
      </div>
    </div>
  );
}