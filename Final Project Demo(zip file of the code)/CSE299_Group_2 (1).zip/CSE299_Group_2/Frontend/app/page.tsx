"use client";

import { useEffect, useState } from "react";
import * as XLSX from "xlsx";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell } from 'recharts';
import BackendStatus from "./backend-status";

type Faculty = {
  faculty_id: string;
  employee_id: string;
  full_name_en: string;
  full_name_bn: string;
  email: string;
  department_id: string;
  department_name?: string;
  dept_code?: string;
  department?: string; // Add department as an optional string
  designation: string;
  seniority_rank: number;
  joining_date: string;
  dept_head_flag: boolean;
};

type Room = {
  room_id: string;
  utilization_rate?: number;
  status?: string;
  room_number: string;
  building_id: string;
  building_name: string;
  building_code: string;
  floor: number;
  capacity: number;
  room_type: string;
  equipment: any;
  isAvailable?: boolean;
  conflictReason?: string;
  matchScore?: number;
  scores?: {
    capacity: number;
    equipment: number;
    proximity: number;
    pastUse: number;
  };
};

type Booking = {
  booking_id: string;
  series_id?: string;
  booking_request_id: string;
  faculty_id: string;
  faculty_name?: string;
  faculty_designation?: string;
  room_id: string;
  room_number?: string;
  course_code: string;
  course_name: string;
  class_size: number;
  start_dt: string;
  end_dt: string;
  booking_type: string;
  status: string;
  notes: string;
  checkin_at?: string;
};

type Notification = {
  notif_id: string;
  type: string;
  channel: string;
  subject: string;
  body: string;
  sent_at: string;
};

type AuditLog = {
  log_id: string;
  user_role: string;
  action: string;
  entity_type: string;
  field_changed?: string;
  old_value?: any;
  new_value?: any;
  timestamp: string;
  faculty_name?: string;
};

type SessionUser = {
  id: string;
  faculty_id?: string;
  name: string;
  email: string;
  role: "Faculty" | "DeptHead" | "Admin" | "Student";
  facultyDetails?: Faculty;
};

type ToastType = "success" | "error" | "warning" | "info";
type Toast = {
  id: string;
  message: string;
  type: ToastType;
};

// Production API endpoint binding (forces Vercel build trigger)
const backendBaseUrl = typeof window !== 'undefined' && !window.location.hostname.includes('localhost') && window.location.hostname !== '127.0.0.1'
  ? "https://cse-299-classroom-booking-system.onrender.com"
  : (process.env.NEXT_PUBLIC_BACKEND_URL ?? "http://127.0.0.1:5001");

export default function Home() {
  const [user, setUser] = useState<SessionUser | null>(null);

  
  const classMatchesDay = (alloc: any, targetDayIndex: number) => {
    const d = alloc.allocated_day_of_week;
    if (d === undefined || d === null) return false;
    const isLab = (alloc.facility_type === 'Lab' || alloc.course_code?.endsWith('L'));
    if (isLab) return d === targetDayIndex;
    if (d === 0) return targetDayIndex === 0 || targetDayIndex === 2;
    if (d === 1) return targetDayIndex === 1 || targetDayIndex === 3;
    if (d === 4) return targetDayIndex === 4 || targetDayIndex === 6;
    return d === targetDayIndex;
  };

  const formatAllocationDay = (alloc: any) => {
    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const isLab = (alloc.facility_type === 'Lab' || alloc.course_code?.endsWith('L'));
    const d = alloc.allocated_day_of_week;
    
    if (d === undefined || d === null) return "—";
    if (isLab) return dayNames[d] || "—";
    
    if (d === 0 || d === 2) return "ST (Sun & Tue)";
    if (d === 1 || d === 3) return "MW (Mon & Wed)";
    if (d === 4 || d === 6) return "RA (Thu & Sat)";
    
    return dayNames[d] || "—";
  };
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Toast Notification Trigger
  const showToast = (message: string, type: ToastType = "info") => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const formatICSDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return date.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
    } catch (e) {
      return "";
    }
  };

  const downloadICSFile = (b: any) => {
    try {
      const summary = `${b.course_code} - ${b.course_name}`;
      const description = `Classroom Booking System reservation for course ${b.course_code}. Notes: ${b.notes || 'None'}`;
      const location = `Room ${b.room_number || b.room_id}`;
      const start = formatICSDate(b.start_dt);
      const end = formatICSDate(b.end_dt);
      const stamp = new Date().toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";

      if (!start || !end) throw new Error("Invalid start or end date");

      const icsContent = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//CBS//Classroom Booking System//EN",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        "BEGIN:VEVENT",
        `UID:${b.booking_id || Math.random().toString()}@university.edu`,
        `DTSTAMP:${stamp}`,
        `DTSTART:${start}`,
        `DTEND:${end}`,
        `SUMMARY:${summary}`,
        `LOCATION:${location}`,
        `DESCRIPTION:${description}`,
        "END:VEVENT",
        "END:VCALENDAR"
      ].join("\r\n");

      const blob = new Blob([icsContent], { type: "text/calendar;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `booking-${b.booking_request_id || b.booking_id}.ics`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showToast("iCalendar (.ics) file downloaded successfully.", "success");
    } catch (e) {
      console.error(e);
      showToast("Failed to generate iCalendar file.", "error");
    }
  };

  const getGoogleCalendarUrl = (b: any) => {
    try {
      const summary = encodeURIComponent(`${b.course_code} - ${b.course_name}`);
      const description = encodeURIComponent(`Classroom Booking System reservation for course ${b.course_code}. Notes: ${b.notes || 'None'}`);
      const location = encodeURIComponent(`Room ${b.room_number || b.room_id}`);

      const formatGDate = (dateStr: string) => {
        return new Date(dateStr).toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
      };

      const dates = `${formatGDate(b.start_dt)}/${formatGDate(b.end_dt)}`;
      return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${summary}&dates=${dates}&details=${description}&location=${location}`;
    } catch (e) {
      return "#";
    }
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") as "dark" | "light";
    if (savedTheme) {
      setTheme(savedTheme);
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
  };

  const isDark = theme === "dark";
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [faculties, setFaculties] = useState<Faculty[]>([]);
  const [adminSubTab, setAdminSubTab] = useState<"dashboard" | "inventory" | "faculty">("dashboard");
  const [activeTab, setActiveTab] = useState<"timetable" | "search" | "dashboard" | "dept" | "admin" | "allocation" | "profile">("timetable");
  const [myProfile, setMyProfile] = useState<any>(null);
  const [myStats, setMyStats] = useState<any>(null);

  // Timetable States
  const [rooms, setRooms] = useState<Room[]>([]);
  const [selectedRoomId, setSelectedRoomId] = useState<string>("");
  const [timetableDate, setTimetableDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [timetableBatchId, setTimetableBatchId] = useState<string>("");
  const [timetableBatchData, setTimetableBatchData] = useState<any>(null);
  const [timetableData, setTimetableData] = useState<any>(null);
  const [timetableMode, setTimetableMode] = useState<"room" | "faculty">("room");
  const [importedFaculty, setImportedFaculty] = useState<any[]>([]);
  const [selectedFacultyEmail, setSelectedFacultyEmail] = useState<string>("");
  const [facultySearchQuery, setFacultySearchQuery] = useState<string>("");

  // Search States
  const [searchDate, setSearchDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [searchStartTime, setSearchStartTime] = useState("09:00");
  const [searchEndTime, setSearchEndTime] = useState("11:00");
  const [searchCapacity, setSearchCapacity] = useState("30");
  const [searchEquipment, setSearchEquipment] = useState<string[]>([]);
  const [searchBuilding, setSearchBuilding] = useState("");
  const [searchRoomType, setSearchRoomType] = useState("");
  const [searchResults, setSearchResults] = useState<Room[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [showPartiallyAvailable, setShowPartiallyAvailable] = useState(false);
  const [searchFloor, setSearchFloor] = useState("");

  // Booking Form Modal States
  const [bookingRoom, setBookingRoom] = useState<Room | null>(null);
  const [courseCode, setCourseCode] = useState("");
  const [courseName, setCourseName] = useState("");
  const [classSize, setClassSize] = useState("");
  const [notes, setNotes] = useState("");
  const [bookingType, setBookingType] = useState<"OneTime" | "Recurring">("OneTime");
  // Recurring details
  const [pattern, setPattern] = useState<"Weekly" | "BiWeekly">("Weekly");
  const [daysOfWeek, setDaysOfWeek] = useState<number[]>([1]); // Default Monday
  const [recurStartDate, setRecurStartDate] = useState(new Date().toISOString().split("T")[0]);
  const [recurEndDate, setRecurEndDate] = useState("");
  // Conflict review for recurring
  const [recurConflicts, setRecurConflicts] = useState<any>(null);
  const [bookingError, setBookingError] = useState<string | null>(null);

  // Dashboard / Notifications
  const [myBookings, setMyBookings] = useState<Booking[]>([]);
  const [myNotifications, setMyNotifications] = useState<Notification[]>([]);
  const [mySemesterAllocations, setMySemesterAllocations] = useState<any[]>([]);
  const [loadingMyAllocations, setLoadingMyAllocations] = useState(false);
  const [viewingAlternativesBookingId, setViewingAlternativesBookingId] = useState<string | null>(null);
  const [alternativesList, setAlternativesList] = useState<any[]>([]);
  const [editingBooking, setEditingBooking] = useState<any | null>(null);
  const [editNotes, setEditNotes] = useState("");
  const [editClassSize, setEditClassSize] = useState("");

  // Dept Head View
  const [deptBookings, setDeptBookings] = useState<Booking[]>([]);
  const [mandateSearchQuery, setMandateSearchQuery] = useState("");
  const [mandateFilterMode, setMandateFilterMode] = useState<"all" | "assigned" | "unassigned">("all");

  // Admin View
  const [sysConfig, setSysConfig] = useState<any>({ booking_window_days: { days: "60" }, no_show_grace_period: { minutes: "15" }, recurring_max_weeks: { weeks: "18" } });
  const [editConfigWindow, setEditConfigWindow] = useState("60");
  const [editConfigGrace, setEditConfigGrace] = useState("15");
  const [editConfigMaxWeeks, setEditConfigMaxWeeks] = useState("18");
  const [editConfigWindowExamHall, setEditConfigWindowExamHall] = useState("90");
  const [editConfigWindowLectureHall, setEditConfigWindowLectureHall] = useState("60");
  const [editConfigWindowSeminarRoom, setEditConfigWindowSeminarRoom] = useState("30");
  const [editConfigWindowComputerLab, setEditConfigWindowComputerLab] = useState("30");
  const [editConfigDurationExamHall, setEditConfigDurationExamHall] = useState("4");
  const [editConfigDurationLectureHall, setEditConfigDurationLectureHall] = useState("4");
  const [editConfigDurationSeminarRoom, setEditConfigDurationSeminarRoom] = useState("3");
  const [editConfigDurationComputerLab, setEditConfigDurationComputerLab] = useState("3");
  // Preference Collection Window
  const [prefWindow, setPrefWindow] = useState<{ open: boolean; deadline: string | null; semester: string | null; instructions: string | null; toggled_at: string | null }>({ open: false, deadline: null, semester: null, instructions: null, toggled_at: null });
  const [prefWindowSemester, setPrefWindowSemester] = useState("");
  const [prefWindowDeadline, setPrefWindowDeadline] = useState("");
  const [prefWindowInstructions, setPrefWindowInstructions] = useState("");
  const [savingPrefWindow, setSavingPrefWindow] = useState(false);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  // Maintenance Form
  const [maintRoomId, setMaintRoomId] = useState("");
  const [maintStart, setMaintStart] = useState("");
  const [maintEnd, setMaintEnd] = useState("");
  const [maintReason, setMaintReason] = useState("");
  // Bulk Cancellation Form
  const [bulkBldgId, setBulkBldgId] = useState("");
  const [bulkStart, setBulkStart] = useState("");
  const [bulkEnd, setBulkEnd] = useState("");
  const [bulkReason, setBulkReason] = useState("");
  // Room Import Text
  const [importJson, setImportJson] = useState(`{\n  "rooms": [\n    {\n      "room_number": "NAC-505",\n      "building_code": "NAC",\n      "floor": 5,\n      "capacity": 45,\n      "room_type": "LectureHall",\n      "equipment": { "projector": true, "air_conditioning": true }\n    }\n  ]\n}`);

  // Add Classroom Form
  const [newRoomNumber, setNewRoomNumber] = useState("");
  const [newBuildingId, setNewBuildingId] = useState("");
  const [newFloor, setNewFloor] = useState("");
  const [newCapacity, setNewCapacity] = useState("");
  const [newRoomType, setNewRoomType] = useState("LectureHall");
  const [newEquipProjector, setNewEquipProjector] = useState(false);
  const [newEquipSmartBoard, setNewEquipSmartBoard] = useState(false);
  const [newEquipWhiteboard, setNewEquipWhiteboard] = useState(false);
  const [newEquipAC, setNewEquipAC] = useState(false);
  const [newEquipAudioSystem, setNewEquipAudioSystem] = useState(false);

  // Report States
  const [utilizationReport, setUtilizationReport] = useState<any[]>([]);
  const [noShowReport, setNoShowReport] = useState<any[]>([]);
  const [conflictReport, setConflictReport] = useState<any>(null);
  const [pendingApprovals, setPendingApprovals] = useState<any[]>([]);
  const [reportedIssues, setReportedIssues] = useState<any[]>([]);

  // Semester Allocation States
  const [batches, setBatches] = useState<any[]>([]);
  const [selectedBatchId, setSelectedBatchId] = useState<string>("");
  const [selectedBatchData, setSelectedBatchData] = useState<any>(null);
  const [allocationSemester, setAllocationSemester] = useState("Spring2026");
  const [allocationCoursesInput, setAllocationCoursesInput] = useState("");
  const [isCreatingBatch, setIsCreatingBatch] = useState(false);
  const [allocationLoading, setAllocationLoading] = useState(false);
  const [allocationDetailTab, setAllocationDetailTab] = useState<"allocated" | "conflicts">("allocated");
  // Data Pull states for Create Batch panel
  const [pullSummary, setPullSummary] = useState<any>(null);
  const [pullingSummary, setPullingSummary] = useState(false);
  const [pulledSections, setPulledSections] = useState<any[]>([]);
  const [pullingSections, setPullingSections] = useState(false);
  const [pulledPreferences, setPulledPreferences] = useState<any[]>([]);
  const [pullingPreferences, setPullingPreferences] = useState(false);
  const [dataPullExpanded, setDataPullExpanded] = useState(false);

  // Manual adjust modal state for allocations/conflicts
  const [adjustingItem, setAdjustingItem] = useState<any>(null);
  const [adjustRoomId, setAdjustRoomId] = useState("");
  const [adjustDayOfWeek, setAdjustDayOfWeek] = useState<number>(1);
  const [adjustStartTime, setAdjustStartTime] = useState("10:00");
  const [adjustEndTime, setAdjustEndTime] = useState("11:30");
  const [adjustFacultyId, setAdjustFacultyId] = useState<string>("");

  // Classroom issue states
  const [selectedIssueBooking, setSelectedIssueBooking] = useState<any>(null);
  const [issueType, setIssueType] = useState("Projector / Display Issue");
  const [issueDescription, setIssueDescription] = useState("");

  // Admin sub-tab and inventory filter states

  // Faculty Creation State
  const [facultyForm, setFacultyForm] = useState({
    employee_id: "", full_name_en: "", full_name_bn: "", email: "", username: "",
    designation: "Lecturer", seniority_rank: 4, joining_date: "", dept_head_flag: false,
    department: "", phone: ""
  });
  const [facultyCreationStatus, setFacultyCreationStatus] = useState("");
  
  // Faculty Management State
  const [adminFaculties, setAdminFaculties] = useState<any[]>([]);
  const [overrideRankId, setOverrideRankId] = useState<string | null>(null);
  const [overrideRankForm, setOverrideRankForm] = useState({ targetRank: 4, justification: "" });
  const [editFacultyId, setEditFacultyId] = useState<string | null>(null);
  const [editFacultyForm, setEditFacultyForm] = useState<any>({});
  const [deactivateFacultyId, setDeactivateFacultyId] = useState<string | null>(null);
  const [replacementFacultyId, setReplacementFacultyId] = useState<string>("");
  const [viewRoutineFaculty, setViewRoutineFaculty] = useState<any | null>(null);
  const [resetPasswordFacultyId, setResetPasswordFacultyId] = useState<string | null>(null);
  const [resetPasswordValue, setResetPasswordValue] = useState<string>("");
  const [adminFacultySearch, setAdminFacultySearch] = useState("");
  const [adminRoomSearch, setAdminRoomSearch] = useState("");
  const [timetableFacultySearch, setTimetableFacultySearch] = useState("");
  const [timetableRoomSearch, setTimetableRoomSearch] = useState("");

  // Room Management State
  const [isCreatingRoom, setIsCreatingRoom] = useState(false);
  const [editRoomId, setEditRoomId] = useState<string | null>(null);
  const [editRoomForm, setEditRoomForm] = useState<any>({});
  const [deactivateRoomId, setDeactivateRoomId] = useState<string | null>(null);
  const [maintenanceRoomId, setMaintenanceRoomId] = useState<string | null>(null);
  const [maintenanceForm, setMaintenanceForm] = useState({ startDt: "", endDt: "", reason: "" });

  useEffect(() => {
    if (user && (user.role === "Faculty" || user.role === "DeptHead")) {
      setTimetableMode("faculty");
      setSelectedFacultyEmail(user.email);
    }
  }, [user]);


  const fetchAdminFaculties = async () => {
    try {
      const res = await fetch("http://localhost:5001/api/admin/faculty");
      const data = await res.json();
      setAdminFaculties(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error("Failed to fetch admin faculties", e);
    }
  };

  const handleUpdateFaculty = async (facultyId: string) => {
    try {
      const res = await fetch(`http://localhost:5001/api/admin/faculty/${facultyId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editFacultyForm)
      });
      if (res.ok) {
        setEditFacultyId(null);
        fetchAdminFaculties();
      }
    } catch (e) {
      console.error("Failed to update faculty", e);
    }
  };

  const handleDeactivateFaculty = async () => {
    if (!deactivateFacultyId) return;
    try {
      const res = await fetch(`http://localhost:5001/api/admin/faculty/${deactivateFacultyId}/deactivate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ replacementFacultyId: replacementFacultyId || null })
      });
      if (res.ok) {
        setDeactivateFacultyId(null);
        setReplacementFacultyId("");
        fetchAdminFaculties();
      }
    } catch (e) {
      console.error("Failed to deactivate faculty", e);
    }
  };
  const handleResetPassword = async () => {
    if (!resetPasswordFacultyId || !resetPasswordValue) return;
    try {
      const res = await fetch(`http://localhost:5001/api/admin/faculty/${resetPasswordFacultyId}/password`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ new_password: resetPasswordValue })
      });
      if (res.ok) {
        setResetPasswordFacultyId(null);
        setResetPasswordValue("");
        alert("Password reset successfully!");
      } else {
        const err = await res.json();
        alert("Failed to reset password: " + err.error);
      }
    } catch (e) {
      console.error("Failed to reset password", e);
    }
  };

  const handleCreateRoom = async () => {
    try {
      const res = await fetch("http://localhost:5001/api/admin/rooms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editRoomForm)
      });
      if (res.ok) {
        setIsCreatingRoom(false);
        setEditRoomForm({});
        fetchRooms();
      } else {
        const err = await res.json();
        alert("Failed to create room: " + err.error);
      }
    } catch (e) {
      console.error("Failed to create room", e);
    }
  };

  const handleUpdateRoom = async (roomId: string) => {
    try {
      const res = await fetch(`http://localhost:5001/api/admin/rooms/${roomId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editRoomForm)
      });
      if (res.ok) {
        setEditRoomId(null);
        setEditRoomForm({});
        fetchRooms();
      } else {
        const err = await res.json();
        alert("Failed to update room: " + err.error);
      }
    } catch (e) {
      console.error("Failed to update room", e);
    }
  };

  const handleDeactivateRoom = async () => {
    if (!deactivateRoomId) return;
    try {
      const res = await fetch(`http://localhost:5001/api/admin/rooms/${deactivateRoomId}`, {
        method: "DELETE"
      });
      if (res.ok) {
        setDeactivateRoomId(null);
        fetchRooms();
      }
    } catch (e) {
      console.error("Failed to deactivate room", e);
    }
  };

  const handleSetMaintenance = async () => {
    if (!maintenanceRoomId || !maintenanceForm.startDt || !maintenanceForm.endDt || !maintenanceForm.reason) return;
    try {
      const res = await fetch(`http://localhost:5001/api/admin/maintenance`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          roomId: maintenanceRoomId, 
          startDt: maintenanceForm.startDt, 
          endDt: maintenanceForm.endDt, 
          reason: maintenanceForm.reason,
          adminId: user?.id 
        })
      });
      if (res.ok) {
        setMaintenanceRoomId(null);
        setMaintenanceForm({ startDt: "", endDt: "", reason: "" });
        alert("Maintenance window created. Affected bookings have been auto-cancelled and users notified.");
        fetchRooms();
      } else {
        const err = await res.json();
        alert("Failed to set maintenance: " + err.error);
      }
    } catch (e) {
      console.error("Failed to set maintenance", e);
    }
  };

  const handleFacultyCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFacultyCreationStatus("Creating...");
    
    // Auto-generate employee ID if empty
    const empId = facultyForm.employee_id || `EMP-${Math.floor(10000 + Math.random() * 90000)}`;
    const finalForm = { ...facultyForm, employee_id: empId };
    
    try {
      const res = await fetch("http://localhost:5001/api/admin/faculty", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(finalForm)
      });
      const data = await res.json();
      if (data.error) {
        setFacultyCreationStatus(`Error: ${data.error}`);
      } else {
        setFacultyCreationStatus("Successfully created faculty profile!");
        setFacultyForm({
          employee_id: "", full_name_en: "", full_name_bn: "", email: "", username: "",
          designation: "Lecturer", seniority_rank: 4, joining_date: "", dept_head_flag: false,
          department: "", phone: ""
        });
        setTimeout(() => setFacultyCreationStatus(""), 3000);
      }
    } catch (err: any) {
      setFacultyCreationStatus(`Error: ${err.message}`);
    }
  };

  const handleSyncHR = async () => {
    try {
      // Mock HR Data
      const mockHRData = [
        { employee_id: "EMP100", full_name_en: "Dr. Jane Doe", full_name_bn: "ড. জেন ডো", email: "jane.doe@university.edu", designation: "Professor", department: "Computer Science", phone: "123-456-7890" },
        { employee_id: "EMP101", full_name_en: "John Smith", full_name_bn: "জন স্মিথ", email: "john.smith@university.edu", designation: "Assistant Professor", department: "Computer Science", phone: "123-456-7891" },
        { employee_id: "EMP102", full_name_en: "Alice Johnson", full_name_bn: "অ্যালিস জনসন", email: "alice.j@university.edu", designation: "Lecturer", department: "Mathematics", phone: "123-456-7892" },
      ];
      
      const res = await fetch(`${backendBaseUrl}/api/admin/hr-sync`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ faculties: mockHRData })
      });
      const data = await res.json();
      if (res.ok) {
        showToast(`HR Sync Complete: ${data.created} Created, ${data.updated} Updated`, "success");
        fetchAdminFaculties();
      } else {
        showToast(data.error || "HR Sync Failed", "error");
      }
    } catch (e) {
      console.error(e);
      showToast("HR Sync Failed", "error");
    }
  };

  const handleOverrideRank = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!overrideRankId || !user?.id) return;
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/faculty/${overrideRankId}/rank`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetRank: overrideRankForm.targetRank, justification: overrideRankForm.justification, adminId: user.id })
      });
      const data = await res.json();
      if (res.ok) {
        showToast("Rank Overridden Successfully", "success");
        setOverrideRankId(null);
        setOverrideRankForm({ targetRank: 4, justification: "" });
        fetchAdminFaculties();
      } else {
        showToast(data.error || "Failed to override rank", "error");
      }
    } catch (e) {
      console.error(e);
      showToast("Error overriding rank", "error");
    }
  };

  const [adminFilterBuilding, setAdminFilterBuilding] = useState("All");
  const [adminFilterFloor, setAdminFilterFloor] = useState("All");
  const [adminAnalytics, setAdminAnalytics] = useState<any>(null);
  const [heatmapData, setHeatmapData] = useState<any>(null);
  const [showHeatmap, setShowHeatmap] = useState(false);

  // Faculty course preference & assignment states
  const [allCourseSections, setAllCourseSections] = useState<any[]>([]);
  const [myPreferences, setMyPreferences] = useState<any[]>([]);
  const [preferenceSearchQuery, setPreferenceSearchQuery] = useState("");

  const fetchBatches = async () => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/allocations/batches`);
      const data = await res.json();
      setBatches(data);
    } catch (e) {
      console.error("Error fetching batches:", e);
    }
  };

  const fetchAllCourseSections = async () => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/course-sections?semester=Spring2026`);
      const data = await res.json();
      setAllCourseSections(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error("Error fetching course sections:", e);
      setAllCourseSections([]);
    }
  };

  const fetchMyCoursePreferences = async () => {
    if (!user?.id) return;
    try {
      const res = await fetch(`${backendBaseUrl}/api/faculty/${user.id}/preferences`);
      const data = await res.json();
      setMyPreferences(data);
    } catch (e) {
      console.error("Error fetching preferences:", e);
    }
  };

  const handleTogglePreference = async (sectionId: string) => {
    if (!user?.id) return;
    try {
      const exists = myPreferences.find((p) => p.section_id === sectionId);
      let updatedList = [];

      if (exists) {
        const remaining = myPreferences.filter((p) => p.section_id !== sectionId);
        updatedList = remaining.map((p, idx) => ({ sectionId: p.section_id, choiceRank: idx + 1 }));
      } else {
        const currentMapped = myPreferences.map((p, idx) => ({ sectionId: p.section_id, choiceRank: idx + 1 }));
        updatedList = [...currentMapped, { sectionId, choiceRank: currentMapped.length + 1 }];
      }

      const res = await fetch(`${backendBaseUrl}/api/faculty/${user.id}/preferences`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ preferences: updatedList }),
      });

      if (res.ok) {
        showToast("Preferences updated successfully!", "success");
        fetchMyCoursePreferences();
      } else {
        showToast("Failed to update preferences.", "error");
      }
    } catch (e) {
      console.error(e);
      showToast("Error updating preferences.", "error");
    }
  };

  const handleAssignFaculty = async (sectionId: string, facultyId: string | null) => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/assign-department-course`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sectionId, facultyId }),
      });

      if (res.ok) {
        showToast("Department course assignment updated successfully!", "success");
        fetchAllCourseSections();
      } else {
        const errorData = await res.json();
        showToast(errorData.error || "Failed to update department assignment.", "error");
      }
    } catch (e) {
      console.error(e);
      showToast("Error updating assignment.", "error");
    }
  };

  const fetchBatchDetails = async (batchId: string) => {
    if (!batchId) return;
    setAllocationLoading(true);
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/allocations/batch/${batchId}`);
      const data = await res.json();
      setSelectedBatchData(data);
      setSelectedBatchId(batchId);
      setIsCreatingBatch(false);
    } catch (e) {
      console.error("Error fetching batch details:", e);
    } finally {
      setAllocationLoading(false);
    }
  };

  const handleAutoResolveAll = async () => {
    if (!selectedBatchId) return;
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/allocation/batch/${selectedBatchId}/resolve-all`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminId: user?.faculty_id })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      
      showToast(`Successfully auto-resolved ${data.resolvedCount} conflicts!`, "success");
      fetchBatchDetails(selectedBatchId);
    } catch (e: any) {
      console.error(e);
      showToast("Error auto-resolving conflicts: " + e.message, "error");
    }
  };

  const handleOpenAdjust = (item: any) => {
    const CLASS_SLOTS_INIT = [
      { start: "08:00", end: "09:30" },
      { start: "09:40", end: "11:10" },
      { start: "11:20", end: "12:50" },
      { start: "13:00", end: "14:30" },
      { start: "14:40", end: "16:10" },
      { start: "16:20", end: "17:50" },
      { start: "18:00", end: "19:30" },
      { start: "19:40", end: "21:10" },
    ];
    let dayOfWeek = item.allocated_day_of_week !== undefined ? item.allocated_day_of_week : 1;
    let roomId = item.room_id;
    const batchAllocations = selectedBatchData?.allocations || [];

    let firstAvailableSlot = null;

    // If no room is pre-assigned (e.g., resolving a conflict), find the first room that has at least one free slot
    if (!roomId) {
      for (const r of rooms) {
        firstAvailableSlot = CLASS_SLOTS_INIT.find(slot => {
          const conflict = batchAllocations.find((a: any) => {
            if (a.allocation_id === item.allocation_id) return false;
            if (a.room_id !== r.room_id) return false;
            if (a.allocated_day_of_week !== dayOfWeek) return false;
            const aStart = (a.allocated_start_time || '').substring(0, 5);
            const aEnd = (a.allocated_end_time || '').substring(0, 5);
            return slot.start < aEnd && slot.end > aStart;
          });
          return !conflict;
        });

        if (firstAvailableSlot) {
          roomId = r.room_id;
          break;
        }
      }
    }

    // Fallback if all rooms are full or a room was pre-assigned
    if (!roomId) roomId = rooms[0]?.room_id || "";
    
    if (!firstAvailableSlot) {
      firstAvailableSlot = CLASS_SLOTS_INIT.find(slot => {
        const conflict = batchAllocations.find((a: any) => {
          if (a.allocation_id === item.allocation_id) return false;
          if (a.room_id !== roomId) return false;
          if (a.allocated_day_of_week !== dayOfWeek) return false;
          const aStart = (a.allocated_start_time || '').substring(0, 5);
          const aEnd = (a.allocated_end_time || '').substring(0, 5);
          return slot.start < aEnd && slot.end > aStart;
        });
        return !conflict;
      }) || CLASS_SLOTS_INIT[0];
    }

    setAdjustingItem(item);
    setAdjustRoomId(roomId);
    setAdjustDayOfWeek(dayOfWeek);
    setAdjustStartTime(firstAvailableSlot.start);
    setAdjustEndTime(firstAvailableSlot.end);
    setAdjustFacultyId(item.allocated_faculty_id || "");
  };

  const handleSaveAdjust = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingItem) return;

    const payload = {
      roomId: adjustRoomId,
      dayOfWeek: adjustDayOfWeek,
      startTime: adjustStartTime,
      endTime: adjustEndTime,
      facultyId: adjustFacultyId || null,
      adminId: user?.id || "00000000-0000-0000-0000-000000000000",
    };

    try {
      let url = "";
      let method = "";
      let body: any = null;

      if (adjustingItem.allocation_id) {
        url = `${backendBaseUrl}/api/admin/allocation/${adjustingItem.allocation_id}`;
        method = "PUT";
        body = payload;
      } else {
        url = `${backendBaseUrl}/api/admin/allocation/resolve-conflict`;
        method = "POST";
        body = {
          batchId: selectedBatchId,
          sectionId: adjustingItem.section_id,
          ...payload,
        };
      }

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed to save manual adjustment", "error");
        return;
      }

      showToast(
        adjustingItem.allocation_id
          ? "Allocation adjusted successfully!"
          : "Conflict resolved and course allocated!",
        "success"
      );
      setAdjustingItem(null);
      fetchBatchDetails(selectedBatchId);
      fetchBatches();
    } catch (err) {
      console.error(err);
      showToast("Error saving manual adjustment", "error");
    }
  };

  const handleCSVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: "array" });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];

        const rows = XLSX.utils.sheet_to_json(worksheet) as any[];
        if (rows.length === 0) {
          showToast("Uploaded spreadsheet file is empty", "warning");
          return;
        }

        const parsedCourses = [];

        for (const row of rows) {
          const keys = Object.keys(row);
          const findVal = (possibleKeys: string[]) => {
            const matchKey = keys.find(k => possibleKeys.includes(k.trim().toLowerCase().replace(/[\s_-]/g, "")));
            return matchKey ? row[matchKey] : undefined;
          };

          const courseCode = findVal(["coursecode", "course_code", "course code", "code"]);
          const courseName = findVal(["coursename", "course_name", "course name", "name"]);
          const departmentId = findVal(["departmentid", "dept_id", "department id", "deptid"]) || "e381fcfa-3cd6-43a7-ab3c-586d4d1c2525";
          const numSectionsVal = findVal(["numsections", "num_sections", "sections", "sectioncount", "number of sections"]);
          const numSections = parseInt(String(numSectionsVal), 10) || 1;
          const enrollmentVal = findVal(["enrollmentpersection", "enrollment_per_section", "enrollment", "capacity", "size"]);
          const enrollmentPerSection = parseInt(String(enrollmentVal), 10) || 40;
          const facilityType = findVal(["facilitytype", "facility_type", "facility type"]) || "Lecture";

          if (courseCode) {
            parsedCourses.push({
              courseCode: String(courseCode).trim(),
              courseName: courseName ? String(courseName).trim() : String(courseCode).trim(),
              departmentId: String(departmentId).trim(),
              numSections,
              enrollmentPerSection,
              facilityType: String(facilityType).trim()
            });
          }
        }

        if (parsedCourses.length === 0) {
          showToast("Could not parse any valid courses. Check column headers.", "error");
          return;
        }

        setAllocationCoursesInput(JSON.stringify(parsedCourses, null, 2));
        showToast(`Successfully parsed ${parsedCourses.length} course sections!`, "success");
      } catch (err: any) {
        console.error(err);
        showToast("Error parsing spreadsheet file: " + err.message, "error");
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handlePreferencesCSVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: "array" });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];

        const rows = XLSX.utils.sheet_to_json(worksheet) as any[];
        if (rows.length === 0) {
          showToast("Uploaded preference sheet is empty", "warning");
          return;
        }

        const parsedPrefs = [];
        for (const row of rows) {
          const keys = Object.keys(row);
          const findVal = (possibleKeys: string[]) => {
            const matchKey = keys.find(k => possibleKeys.includes(k.trim().toLowerCase().replace(/[\s_-]/g, "")));
            return matchKey ? row[matchKey] : undefined;
          };

          const email = findVal(["email", "facultyemail", "faculty_email", "faculty"]);
          const name = findVal(["name", "fullname", "full_name", "faculty_name", "facultyname", "fullnameen", "full_name_en"]);
          const designation = findVal(["designation", "role", "designation_name", "title"]);
          const courseCode = findVal(["coursecode", "course_code", "course", "subject"]);
          const sectionVal = findVal(["section", "sectionnumber", "section_number", "section number"]);
          const choiceRankVal = findVal(["choicerank", "choice_rank", "rank", "preference"]);
          const choiceRank = parseInt(String(choiceRankVal), 10) || 1;
          const roomNumber = findVal(["roomnumber", "preferredroom", "room", "classroom", "room_number"]);

          let section = sectionVal ? String(sectionVal).trim() : "";
          if (section.length === 1 && !isNaN(Number(section))) {
            section = "0" + section;
          }

          if (email && courseCode && section) {
            parsedPrefs.push({
              email: String(email).trim(),
              name: name ? String(name).trim() : null,
              designation: designation ? String(designation).trim() : null,
              courseCode: String(courseCode).trim(),
              section: section,
              choiceRank,
              roomNumber: roomNumber ? String(roomNumber).trim() : null
            });
          }
        }

        if (parsedPrefs.length === 0) {
          showToast("Could not parse any valid preferences. Check headers (Email, CourseCode, Section, Rank).", "error");
          return;
        }

        const res = await fetch(`${backendBaseUrl}/api/admin/import-preferences`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ preferences: parsedPrefs, semester: "Spring2026" }),
        });

        const resData = await res.json();
        if (res.ok) {
          showToast(`Successfully imported ${resData.imported} preferences!`, "success");
          fetchMyCoursePreferences();
        } else {
          showToast(`Failed to import preferences: ${resData.error}`, "error");
        }
      } catch (err: any) {
        console.error(err);
        showToast("Error parsing preference sheet: " + err.message, "error");
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleDownloadTemplate = () => {
    const headers = ["courseCode", "courseName", "departmentId", "numSections", "enrollmentPerSection", "facilityType"];
    const rows = [
      ["CSE101", "Introduction to Computing", "e381fcfa-3cd6-43a7-ab3c-586d4d1c2525", "3", "45", "Lecture"],
      ["CSE201", "Data Structures", "e381fcfa-3cd6-43a7-ab3c-586d4d1c2525", "2", "40", "Lecture"],
      ["CSE210", "Computer Programming Lab", "e381fcfa-3cd6-43a7-ab3c-586d4d1c2525", "2", "30", "Lab"]
    ];
    const csvContent = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "cbs_semester_courses_template.csv");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Template CSV download initiated.", "info");
  };

  const handleDownloadPreferenceTemplate = () => {
    const headers = ["email", "name", "designation", "courseCode", "section", "choiceRank", "preferredRoom"];
    const rows = [
      ["arshad@university.edu", "Dr. Arshad Rahman", "Professor", "CSE115", "01", "1", "NAC-301"],
      ["arshad@university.edu", "Dr. Arshad Rahman", "Professor", "CSE311", "01", "2", "NAC-402"],
      ["nusrat@university.edu", "Dr. Nusrat Jahan", "Associate Professor", "CSE215", "01", "1", "SAC-201"],
      ["samiul@university.edu", "Samiul Hasan", "Lecturer", "CSE115", "02", "1", ""]
    ];
    const csvContent = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "cbs_faculty_preferences_template.csv");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Preferences Template CSV download initiated.", "info");
  };

  const handleLoadDemoPreferences = async () => {
    const demo = [
      {
        "email": "arshad.rahman@university.edu",
        "courseCode": "CSE101",
        "section": "01",
        "choiceRank": 1
      },
      {
        "email": "arshad.rahman@university.edu",
        "courseCode": "CSE201",
        "section": "01",
        "choiceRank": 2
      },
      {
        "email": "samiul.islam@university.edu",
        "courseCode": "CSE101",
        "section": "02",
        "choiceRank": 1
      }
    ];

    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/import-preferences`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ preferences: demo, semester: "Spring2026" }),
      });
      const data = await res.json();
      if (res.ok) {
        showToast(`Successfully loaded ${data.imported} demo preferences!`, "success");
        fetchMyCoursePreferences();
      } else {
        showToast(`Failed to load demo preferences: ${data.error}`, "error");
      }
    } catch (e) {
      console.error(e);
      showToast("Error loading demo preferences.", "error");
    }
  };

  const handleExportPDF = (mode: "faculty" | "room" | "full" = "faculty") => {
    if (!selectedBatchData) return;
    const { batch, allocations } = selectedBatchData;
    if (!allocations || allocations.length === 0) {
      showToast("No allocations to export.", "warning");
      return;
    }

    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      showToast("Pop-up blocker prevented opening PDF window.", "error");
      return;
    }

    const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const coverage = Math.round((batch.successfully_allocated / batch.total_sections) * 100 || 0);
    const reportDate = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
    const reportTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

    // Helper: build faculty-grouped HTML
    const buildFacultyGrouped = () => {
      let html = "";
      const grouped = new Map<string, { label: string; designation: string; items: any[] }>();
      for (const alloc of allocations) {
        const key = alloc.allocated_faculty_email || alloc.allocated_faculty_name || "Unassigned";
        if (!grouped.has(key)) {
          grouped.set(key, { label: alloc.allocated_faculty_name || key, designation: alloc.allocated_faculty_designation || "", items: [] });
        }
        grouped.get(key)!.items.push(alloc);
      }
      for (const [, group] of grouped) {
        const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        
        const timeslotSet = new Set<string>();
        group.items.forEach((a: any) => {
          if (a.allocated_start_time && a.allocated_end_time) {
            timeslotSet.add(`${a.allocated_start_time.substring(0,5)} - ${a.allocated_end_time.substring(0,5)}`);
          }
        });
        const timeslots = Array.from(timeslotSet).sort();

        let gridHTML = `<table class="matrix-table">
          <thead>
            <tr>
              <th>Time / Day</th>`;
        DAYS.forEach(day => gridHTML += `<th>${day}</th>`);
        gridHTML += `</tr></thead><tbody>`;

        if (timeslots.length === 0) {
          gridHTML += `<tr><td colspan="8" style="text-align:center; padding: 20px; color: #888;">No scheduled classes</td></tr>`;
        } else {
          timeslots.forEach(ts => {
            gridHTML += `<tr>
              <td class="row-header">${ts}</td>`;
            DAYS.forEach((day, dayIndex) => {
              const classesInSlot = group.items.filter((a: any) => 
                classMatchesDay(a, dayIndex) && 
                `${a.allocated_start_time.substring(0,5)} - ${a.allocated_end_time.substring(0,5)}` === ts
              );
              if (classesInSlot.length > 0) {
                gridHTML += `<td class="cell-active">`;
                classesInSlot.forEach((cls: any) => {
                  gridHTML += `
                    <div class="cell-class">
                      <div class="course-line"><strong>${cls.course_code}</strong> <span class="sec">Sec ${cls.section_number}</span></div>
                      ${cls.room_number ? `<div class="room-line">Room ${cls.room_number}</div>` : ""}
                    </div>`;
                });
                gridHTML += `</td>`;
              } else {
                gridHTML += `<td class="cell-empty"></td>`;
              }
            });
            gridHTML += `</tr>`;
          });
        }
        gridHTML += `</tbody></table>`;

        html += `<div class="section-block" style="page-break-after: always; margin-bottom: 40px;">
          <div class="section-header" style="border-bottom: 3px solid #0891b2; padding-bottom: 12px; margin-bottom: 20px; background: none; border-left: none; display: flex; justify-content: space-between;">
            <div>
              <span class="section-name" style="font-size: 20px; font-weight: 900;">${group.label}</span>
              ${group.designation ? `<span class="badge" style="background: #0891b2; color: #fff; font-size: 11px; padding: 4px 10px; border-radius: 12px; margin-left: 12px; vertical-align: middle;">${group.designation}</span>` : ""}
            </div>
            <span class="count-badge" style="background: #f1f5f9; color: #555; font-size: 11px;">${group.items.length} section${group.items.length !== 1 ? "s" : ""}</span>
          </div>
          ${gridHTML}
          </div>`;
      }
      return html;
    };

    // Helper: build room-grouped HTML
    const buildRoomGrouped = () => {
      let html = "";
      const grouped = new Map<string, { label: string; items: any[] }>();
      for (const alloc of allocations) {
        const key = alloc.room_number || "Unknown Room";
        if (!grouped.has(key)) grouped.set(key, { label: key, items: [] });
        grouped.get(key)!.items.push(alloc);
      }
      const sortedKeys = [...grouped.keys()].sort();
      for (const key of sortedKeys) {
        const group = grouped.get(key)!;
        
        const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        
        const timeslotSet = new Set<string>();
        group.items.forEach((a: any) => {
          if (a.allocated_start_time && a.allocated_end_time) {
            timeslotSet.add(`${a.allocated_start_time.substring(0,5)} - ${a.allocated_end_time.substring(0,5)}`);
          }
        });
        const timeslots = Array.from(timeslotSet).sort();

        let gridHTML = `<table class="matrix-table">
          <thead>
            <tr>
              <th>Time / Day</th>`;
        DAYS.forEach(day => gridHTML += `<th>${day}</th>`);
        gridHTML += `</tr></thead><tbody>`;

        if (timeslots.length === 0) {
          gridHTML += `<tr><td colspan="8" style="text-align:center; padding: 20px; color: #888;">No scheduled classes</td></tr>`;
        } else {
          timeslots.forEach(ts => {
            gridHTML += `<tr>
              <td class="row-header">${ts}</td>`;
            DAYS.forEach((day, dayIndex) => {
              const classesInSlot = group.items.filter((a: any) => 
                classMatchesDay(a, dayIndex) && 
                `${a.allocated_start_time.substring(0,5)} - ${a.allocated_end_time.substring(0,5)}` === ts
              );
              if (classesInSlot.length > 0) {
                gridHTML += `<td class="cell-active">`;
                classesInSlot.forEach((cls: any) => {
                  gridHTML += `
                    <div class="cell-class">
                      <div class="course-line"><strong>${cls.course_code}</strong> <span class="sec">Sec ${cls.section_number}</span></div>
                      ${cls.allocated_faculty_name ? `<div class="room-line">${cls.allocated_faculty_name}</div>` : `<div class="room-line" style="color:#999;font-style:italic">Unassigned</div>`}
                    </div>`;
                });
                gridHTML += `</td>`;
              } else {
                gridHTML += `<td class="cell-empty"></td>`;
              }
            });
            gridHTML += `</tr>`;
          });
        }
        gridHTML += `</tbody></table>`;

        html += `<div class="section-block" style="page-break-after: always; margin-bottom: 40px;">
          <div class="section-header" style="border-bottom: 3px solid #0891b2; padding-bottom: 12px; margin-bottom: 20px; background: none; border-left: none; display: flex; justify-content: space-between;">
            <span class="section-name" style="font-size: 20px; font-weight: 900;">🏫 Room ${group.label}</span>
            <span class="count-badge" style="background: #f1f5f9; color: #555; font-size: 11px;">${group.items.length} class${group.items.length !== 1 ? "es" : ""} scheduled</span>
          </div>
          ${gridHTML}
          </div>`;
      }
      return html;
    };

    let groupedHtml = "";
    let modeTitle = "";

    if (mode === "faculty") {
      modeTitle = "Faculty-Wise Schedule";
      groupedHtml = buildFacultyGrouped();
    } else if (mode === "room") {
      modeTitle = "Classroom-Wise Schedule";
      groupedHtml = buildRoomGrouped();
    } else {
      // Full combined report
      modeTitle = "Complete Allocation Report (Faculty-Wise + Classroom-Wise)";
      groupedHtml = `
        <div class="part-divider">📋 Part 1: Faculty-Wise Schedules</div>
        ${buildFacultyGrouped()}
        <div class="part-divider" style="margin-top:36px;">🏫 Part 2: Classroom-Wise Schedules</div>
        ${buildRoomGrouped()}
      `;
    }

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>${modeTitle} – ${batch.semester}</title>
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { font-family: 'Segoe UI', Tahoma, sans-serif; color: #1a1a1a; background: #fff; padding: 32px 40px; }
            .report-header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #0891b2; padding-bottom: 18px; margin-bottom: 24px; }
            .report-header-left h1 { font-size: 20px; font-weight: 800; letter-spacing: 0.5px; color: #0c0c0c; }
            .report-header-left p { font-size: 12px; color: #666; margin-top: 4px; }
            .report-header-right { text-align: right; font-size: 11px; color: #555; }
            .report-header-right .semester-badge { background: #0891b2; color: #fff; font-weight: 800; font-size: 12px; padding: 4px 14px; border-radius: 20px; margin-bottom: 6px; display: inline-block; }
            .meta-strip { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; background: #f8f9fa; border: 1px solid #e5e7eb; border-radius: 10px; padding: 14px 18px; margin-bottom: 28px; }
            .meta-strip .meta-item strong { display: block; font-size: 9px; text-transform: uppercase; letter-spacing: 0.8px; color: #888; margin-bottom: 3px; }
            .meta-strip .meta-item span { font-size: 13px; font-weight: 700; color: #1a1a1a; }
            .mode-label { font-size: 15px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; color: #0891b2; border-left: 4px solid #0891b2; padding-left: 12px; margin-bottom: 20px; }
            .section-block { margin-bottom: 28px; page-break-inside: avoid; }
            .section-header { display: flex; align-items: center; gap: 10px; background: #f1f5f9; border-left: 4px solid #0891b2; padding: 10px 14px; border-radius: 0 8px 8px 0; margin-bottom: 10px; }
            .section-name { font-size: 13px; font-weight: 800; color: #0c0c0c; }
            .badge { font-size: 9px; background: #dbeafe; color: #1d4ed8; font-weight: 700; padding: 2px 8px; border-radius: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
            .count-badge { font-size: 9px; background: #e0f2f1; color: #0891b2; font-weight: 700; padding: 2px 8px; border-radius: 12px; margin-left: auto; }
            table { width: 100%; border-collapse: collapse; font-size: 11px; }
            th { background: #1e293b; color: #fff; padding: 8px 10px; text-align: left; font-size: 9px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 700; }
            td { padding: 8px 10px; border-bottom: 1px solid #f0f0f0; vertical-align: top; }
            tr:nth-child(even) td { background: #fafafa; }
            .footer { margin-top: 40px; text-align: right; font-size: 10px; color: #999; border-top: 1px solid #e5e7eb; padding-top: 16px; }
            .part-divider { font-size: 16px; font-weight: 900; text-transform: uppercase; letter-spacing: 1.5px; color: #0e7490; background: #ecfeff; border: 1px solid #a5f3fc; border-radius: 8px; padding: 10px 18px; margin-bottom: 20px; }
            
            .matrix-table { width: 100%; border-collapse: collapse; font-size: 11px; table-layout: fixed; }
            .matrix-table th { background: #1e293b; color: #fff; padding: 10px; text-align: center; font-size: 10px; text-transform: uppercase; font-weight: 700; border: 1px solid #334155; }
            .matrix-table th:first-child { width: 90px; }
            .matrix-table td { border: 1px solid #cbd5e1; padding: 8px; vertical-align: top; }
            .matrix-table .row-header { background: #f8fafc; font-weight: 800; text-align: center; color: #0891b2; font-size: 10px; vertical-align: middle; }
            .matrix-table .cell-empty { background: #fafafa; }
            .matrix-table .cell-active { background: #ecfeff; border: 2px solid #0891b2; }
            .cell-class { padding: 4px 0; border-bottom: 1px dashed #a5f3fc; }
            .cell-class:last-child { border-bottom: none; padding-bottom: 0; }
            .course-line { font-size: 11px; color: #0f172a; margin-bottom: 2px; }
            .course-line strong { font-weight: 900; }
            .sec { font-size: 9px; background: #cffafe; padding: 1px 4px; border-radius: 3px; color: #0f172a; margin-left: 2px; }
            .room-line { font-size: 10px; color: #475569; font-weight: 600; }

            @media print {
              @page { size: landscape; margin: 10mm; } 
              body { padding: 16px 24px; background: #fff; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
              .no-print { display: none; }
              .section-block { page-break-inside: avoid; }
              .matrix-table th { border: 1px solid #000; background: #e2e8f0 !important; color: #000; }
              .matrix-table td { border: 1px solid #000; }
              .matrix-table .cell-active { border: 2px solid #000; background: #f8fafc !important; }
              .matrix-table .row-header { border: 1px solid #000; color: #000; }
            }
          </style>
        </head>
        <body>
          <div class="report-header">
            <div class="report-header-left">
              <h1>Classroom Booking System — Semester Allocation Report</h1>
              <p>${modeTitle} | Generated ${reportDate} at ${reportTime}</p>
            </div>
            <div class="report-header-right">
              <div class="semester-badge">${batch.semester}</div>
              <div>Batch: ${batch.batch_id.substring(0, 8)}...</div>
              <div>Status: ${batch.status}</div>
            </div>
          </div>

          <div class="meta-strip">
            <div class="meta-item"><strong>Total Sections</strong><span>${batch.total_sections}</span></div>
            <div class="meta-item"><strong>Successfully Allocated</strong><span>${batch.successfully_allocated}</span></div>
            <div class="meta-item"><strong>Conflicts</strong><span>${batch.failed_allocations}</span></div>
            <div class="meta-item"><strong>Coverage</strong><span>${coverage}%</span></div>
          </div>

          <div class="mode-label">📋 ${modeTitle}</div>

          ${groupedHtml}

          <div class="footer">
            Official Semester Timetable generated by the University Classroom Booking System (CBS).
          </div>

          <script>
            window.onload = function () { window.print(); };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Export a single allocation row as a class schedule card PDF
  const handleExportSingleClassPDF = (alloc: any) => {
    if (!selectedBatchData) return;
    const { batch } = selectedBatchData;
    const printWindow = window.open("", "_blank");
    if (!printWindow) { showToast("Pop-up blocker prevented PDF window.", "error"); return; }
    const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const day = formatAllocationDay(alloc);
    const start = (alloc.allocated_start_time || "").substring(0, 5);
    const end = (alloc.allocated_end_time || "").substring(0, 5);
    printWindow.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8">
      <title>Class Schedule — ${alloc.course_code} Sec ${alloc.section_number}</title>
      <style>
        * { box-sizing:border-box; margin:0; padding:0; }
        body { font-family:'Segoe UI',Tahoma,sans-serif; background:#fff; display:flex; align-items:center; justify-content:center; min-height:100vh; padding:20px; }
        .card { width:100%; max-width:480px; border:2px solid #0891b2; border-radius:16px; overflow:hidden; box-shadow:0 4px 24px rgba(0,0,0,0.10); }
        .card-header { background:linear-gradient(135deg,#0891b2,#0e7490); color:#fff; padding:24px 28px; }
        .card-header .institution { font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:1px; opacity:0.8; margin-bottom:6px; }
        .card-header .course-code { font-size:28px; font-weight:900; letter-spacing:1px; }
        .card-header .course-name { font-size:13px; opacity:0.9; margin-top:4px; }
        .card-body { padding:24px 28px; display:grid; grid-template-columns:1fr 1fr; gap:16px; }
        .field { }
        .field label { font-size:9px; font-weight:700; text-transform:uppercase; letter-spacing:0.8px; color:#888; display:block; margin-bottom:4px; }
        .field value { font-size:14px; font-weight:700; color:#111; display:block; }
        .field .sub { font-size:11px; color:#555; font-weight:500; margin-top:2px; }
        .card-footer { background:#f8f9fa; border-top:1px solid #e5e7eb; padding:12px 28px; font-size:10px; color:#888; text-align:right; }
        .semester-pill { display:inline-block; background:#0891b2; color:#fff; font-weight:800; font-size:10px; padding:3px 10px; border-radius:20px; margin-bottom:4px; }
        @media print { body { padding:0; } }
      </style></head><body>
      <div class="card">
        <div class="card-header">
          <div class="institution">Classroom Booking System — Class Schedule Card</div>
          <div class="course-code">${alloc.course_code} &nbsp;<span style="font-size:16px;opacity:0.75">Sec ${alloc.section_number}</span></div>
          <div class="course-name">${alloc.course_name || ""}</div>
        </div>
        <div class="card-body">
          <div class="field">
            <label>Assigned Room</label>
            <value style="color:#0891b2">${alloc.room_number}</value>
            <div class="sub">${alloc.capacity ? `Capacity: ${alloc.capacity} seats` : ""}</div>
          </div>
          <div class="field">
            <label>Schedule</label>
            <value>${day}</value>
            <div class="sub">${start} – ${end}</div>
          </div>
          <div class="field">
            <label>Faculty</label>
            <value>${alloc.allocated_faculty_name || "Unassigned"}</value>
            <div class="sub">${alloc.allocated_faculty_designation || ""}</div>
          </div>
          <div class="field">
            <label>Enrollment</label>
            <value>${alloc.enrollment_size || "—"}</value>
            <div class="sub">students enrolled</div>
          </div>
          <div class="field">
            <label>Semester</label>
            <value>${batch.semester}</value>
          </div>
          <div class="field">
            <label>Allocation Basis</label>
            <value style="font-size:12px;">${alloc.allocation_reason || "Auto-allocated"}</value>
          </div>
        </div>
        <div class="card-footer">Generated ${new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })} &nbsp;·&nbsp; CBS Automated Timetable System</div>
      </div>
      <script>window.onload=function(){window.print()};</script>
    </body></html>`);
    printWindow.document.close();
  };

  // Export all sections for one specific faculty member as PDF
  const handleExportFacultySchedulePDF = (facultyEmail: string, facultyName: string) => {
    if (!selectedBatchData) return;
    const { batch, allocations } = selectedBatchData;
    const myAllocs = allocations.filter((a: any) =>
      (a.allocated_faculty_email || "").toLowerCase() === facultyEmail.toLowerCase() ||
      (a.allocated_faculty_name || "").toLowerCase() === facultyName.toLowerCase()
    );
    if (myAllocs.length === 0) { showToast("No allocations found for this faculty.", "warning"); return; }
    const printWindow = window.open("", "_blank");
    if (!printWindow) { showToast("Pop-up blocker prevented PDF window.", "error"); return; }
    const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    
    // Extract unique timeslots
    const timeslotSet = new Set<string>();
    myAllocs.forEach((a: any) => {
      if (a.allocated_start_time && a.allocated_end_time) {
        timeslotSet.add(`${a.allocated_start_time.substring(0,5)} - ${a.allocated_end_time.substring(0,5)}`);
      }
    });
    const timeslots = Array.from(timeslotSet).sort();

    let gridHTML = `<table class="matrix-table">
      <thead>
        <tr>
          <th>Time / Day</th>`;
    DAYS.forEach(day => gridHTML += `<th>${day}</th>`);
    gridHTML += `</tr></thead><tbody>`;

    if (timeslots.length === 0) {
      gridHTML += `<tr><td colspan="8" style="text-align:center; padding: 20px; color: #888;">No scheduled classes</td></tr>`;
    } else {
      timeslots.forEach(ts => {
        gridHTML += `<tr>
          <td class="row-header">${ts}</td>`;
        DAYS.forEach((day, dayIndex) => {
          const classesInSlot = myAllocs.filter((a: any) => 
            classMatchesDay(a, dayIndex) && 
            `${a.allocated_start_time.substring(0,5)} - ${a.allocated_end_time.substring(0,5)}` === ts
          );
          if (classesInSlot.length > 0) {
            gridHTML += `<td class="cell-active">`;
            classesInSlot.forEach((cls: any) => {
              gridHTML += `
                <div class="cell-class">
                  <div class="course-line"><strong>${cls.course_code}</strong> <span class="sec">Sec ${cls.section_number}</span></div>
                  ${cls.room_number ? `<div class="room-line">Room ${cls.room_number}</div>` : ""}
                </div>`;
            });
            gridHTML += `</td>`;
          } else {
            gridHTML += `<td class="cell-empty"></td>`;
          }
        });
        gridHTML += `</tr>`;
      });
    }
    gridHTML += `</tbody></table>`;

    const faculty = myAllocs[0];
    printWindow.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8">
      <title>Faculty Schedule — ${facultyName}</title>
      <style>
        * { box-sizing:border-box; margin:0; padding:0; }
        body { font-family:'Segoe UI',Tahoma,sans-serif; color:#1a1a1a; padding:24px 32px; background: #fff; }
        .header { border-bottom:3px solid #0891b2; padding-bottom:12px; margin-bottom:16px; display:flex; justify-content:space-between; align-items:flex-start; }
        .header h1 { font-size:20px; font-weight:900; }
        .header p { font-size:11px; color:#555; margin-top:2px; }
        .semester-badge { background:#0891b2; color:#fff; font-weight:800; font-size:11px; padding:4px 12px; border-radius:20px; }
        .meta { background:#f1f5f9; border-left:4px solid #0891b2; border-radius:0 8px 8px 0; padding:10px 14px; margin-bottom:20px; display:flex; gap:24px; flex-wrap:wrap; }
        .meta span { font-size:10px; color:#555; } .meta span strong { display:block; font-size:8px; text-transform:uppercase; letter-spacing:0.8px; color:#888; margin-bottom:1px; }
        
        .matrix-table { width: 100%; border-collapse: collapse; font-size: 11px; table-layout: fixed; }
        .matrix-table th { background: #1e293b; color: #fff; padding: 10px; text-align: center; font-size: 10px; text-transform: uppercase; font-weight: 700; border: 1px solid #334155; }
        .matrix-table th:first-child { width: 90px; }
        .matrix-table td { border: 1px solid #cbd5e1; padding: 8px; vertical-align: top; }
        .matrix-table .row-header { background: #f8fafc; font-weight: 800; text-align: center; color: #0891b2; font-size: 10px; vertical-align: middle; }
        .matrix-table .cell-empty { background: #fafafa; }
        .matrix-table .cell-active { background: #ecfeff; border: 2px solid #0891b2; }
        .cell-class { padding: 4px 0; border-bottom: 1px dashed #a5f3fc; }
        .cell-class:last-child { border-bottom: none; padding-bottom: 0; }
        .course-line { font-size: 11px; color: #0f172a; margin-bottom: 2px; }
        .course-line strong { font-weight: 900; }
        .sec { font-size: 9px; background: #cffafe; padding: 1px 4px; border-radius: 3px; color: #0f172a; margin-left: 2px; }
        .room-line { font-size: 10px; color: #475569; font-weight: 600; }
        
        .footer { margin-top:24px; text-align:right; font-size:9px; color:#999; border-top:1px solid #e5e7eb; padding-top:10px; }
        
        @media print { 
          @page { size: landscape; margin: 10mm; } 
          body { padding: 0; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .matrix-table th { border: 1px solid #000; background: #e2e8f0 !important; color: #000; }
          .matrix-table td { border: 1px solid #000; }
          .matrix-table .cell-active { border: 2px solid #000; background: #f8fafc !important; }
          .matrix-table .row-header { border: 1px solid #000; color: #000; }
        }
      </style></head><body>
      <div class="header">
        <div>
          <h1>📋 ${facultyName}</h1>
          <p>${faculty.allocated_faculty_designation || "Faculty"} — Individual Teaching Schedule</p>
        </div>
        <div class="semester-badge">${batch.semester}</div>
      </div>
      <div class="meta">
        <span><strong>Total Sections</strong>${myAllocs.length} sections</span>
        <span><strong>Batch</strong>${batch.batch_id.substring(0, 8)}...</span>
        <span><strong>Generated</strong>${new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}</span>
      </div>
      
      ${gridHTML}

      <div class="footer">Official Faculty Schedule — CBS Automated Timetable System</div>
      <script>window.onload=function(){window.print()};</script>
    </body></html>`);
    printWindow.document.close();
  };

  const handleLoadDemoCourses = () => {
    const demo = [
      {
        "courseCode": "CSE101",
        "courseName": "Introduction to Computing",
        "departmentId": "e381fcfa-3cd6-43a7-ab3c-586d4d1c2525",
        "numSections": 3,
        "enrollmentPerSection": 45,
        "facilityType": "Lecture"
      },
      {
        "courseCode": "CSE201",
        "courseName": "Data Structures",
        "departmentId": "e381fcfa-3cd6-43a7-ab3c-586d4d1c2525",
        "numSections": 2,
        "enrollmentPerSection": 40,
        "facilityType": "Lecture"
      },
      {
        "courseCode": "CSE210",
        "courseName": "Computer Programming Lab",
        "departmentId": "e381fcfa-3cd6-43a7-ab3c-586d4d1c2525",
        "numSections": 2,
        "enrollmentPerSection": 30,
        "facilityType": "Lab"
      }
    ];
    setAllocationCoursesInput(JSON.stringify(demo, null, 2));
    showToast("Loaded demo course offerings list.", "info");
  };

  // Pull live summary stats from DB
  const handlePullSummary = async () => {
    if (!allocationSemester.trim()) { showToast("Enter a semester name first.", "warning"); return; }
    setPullingSummary(true);
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/pull-summary?semester=${encodeURIComponent(allocationSemester)}`);
      const data = await res.json();
      if (!res.ok) { showToast(data.error || "Failed to pull summary.", "error"); return; }
      setPullSummary(data);
      setDataPullExpanded(true);
    } catch (e) {
      showToast("Error pulling data summary.", "error");
    } finally {
      setPullingSummary(false);
    }
  };

  // Pull course sections from DB and populate JSON input
  const handlePullSections = async () => {
    if (!allocationSemester.trim()) { showToast("Enter a semester name first.", "warning"); return; }
    setPullingSections(true);
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/course-sections?semester=${encodeURIComponent(allocationSemester)}`);
      const data = await res.json();
      if (!res.ok) { showToast(data.error || "Failed to pull sections.", "error"); return; }
      if (!Array.isArray(data) || data.length === 0) {
        showToast(`No course sections found for semester "${allocationSemester}". Import them first.`, "warning");
        return;
      }
      setPulledSections(data);
      // Convert DB rows to allocation engine format
      const grouped = new Map<string, any>();
      for (const sec of data) {
        const key = sec.course_code;
        if (!grouped.has(key)) {
          grouped.set(key, {
            courseCode: sec.course_code,
            courseName: sec.course_name,
            departmentId: sec.department_id || "",
            numSections: 0,
            enrollmentPerSection: Number(sec.enrollment_size) || 30,
            facilityType: sec.facility_type || "Lecture",
          });
        }
        grouped.get(key)!.numSections += 1;
      }
      const allocationPayload = [...grouped.values()];
      setAllocationCoursesInput(JSON.stringify(allocationPayload, null, 2));
      showToast(`✅ Pulled ${data.length} sections (${allocationPayload.length} courses) from DB for ${allocationSemester}.`, "success");
    } catch (e) {
      showToast("Error pulling sections from DB.", "error");
    } finally {
      setPullingSections(false);
    }
  };

  // Pull faculty preferences from DB for the semester
  const handlePullPreferences = async () => {
    if (!allocationSemester.trim()) { showToast("Enter a semester name first.", "warning"); return; }
    setPullingPreferences(true);
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/pull-preferences?semester=${encodeURIComponent(allocationSemester)}`);
      const data = await res.json();
      if (!res.ok) { showToast(data.error || "Failed to pull preferences.", "error"); return; }
      if (!Array.isArray(data) || data.length === 0) {
        showToast(`No faculty preferences found for "${allocationSemester}". Make sure the preference window was open and faculty submitted choices.`, "warning");
        setPulledPreferences([]);
        return;
      }
      setPulledPreferences(data);
      showToast(`✅ Pulled preferences from ${[...new Set(data.map((d: any) => d.faculty_email))].length} faculty members (${data.length} total choices).`, "success");
    } catch (e) {
      showToast("Error pulling preferences from DB.", "error");
    } finally {
      setPullingPreferences(false);
    }
  };

  const handleRunAllocation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!allocationCoursesInput) {
      showToast("Please upload a CSV or load demo data first.", "warning");
      return;
    }

    let parsedCourses = null;
    try {
      parsedCourses = JSON.parse(allocationCoursesInput);
      if (!Array.isArray(parsedCourses) || parsedCourses.length === 0) {
        throw new Error("Must be a non-empty array of course sections");
      }
    } catch (err: any) {
      showToast("Invalid JSON format for course list: " + err.message, "error");
      return;
    }

    setAllocationLoading(true);
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/allocate-semester`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          semester: allocationSemester,
          adminId: user?.id || "00000000-0000-0000-0000-000000000000",
          courses: parsedCourses,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed to run semester allocation", "error");
        return;
      }

      showToast(data.message || "Allocation run completed!", "success");
      setIsCreatingBatch(false);
      setAllocationCoursesInput("");
      fetchBatches();
      fetchBatchDetails(data.batchId);
    } catch (err) {
      console.error(err);
      showToast("Error starting allocation run", "error");
    } finally {
      setAllocationLoading(false);
    }
  };

  const handleDeleteBatch = async (batchId: string) => {
    if (!confirm("Are you sure you want to delete this batch? All allocations will be removed.")) return;
    setAllocationLoading(true);
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/allocations/batches/${batchId}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to delete batch");
      showToast("Batch deleted successfully", "success");
      
      // Close details pane if the deleted batch was open
      if (selectedBatchId === batchId) {
        setSelectedBatchId("");
        setSelectedBatchData(null);
      }
      
      // Refresh list
      fetchBatches();
    } catch (e: any) {
      showToast(e.message, "error");
    } finally {
      setAllocationLoading(false);
    }
  };

  const handleConfirmBatch = async (batchId: string) => {
    setAllocationLoading(true);
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/confirm-allocation/${batchId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          adminId: user?.id || "00000000-0000-0000-0000-000000000000",
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed to confirm batch allocation", "error");
        return;
      }

      showToast(`Batch confirmed! Created ${data.confirmedBookings} active bookings.`, "success");
      fetchBatches();
      fetchBatchDetails(batchId);
      fetchRooms();
      if (selectedRoomId) fetchTimetable(selectedRoomId, timetableDate);
    } catch (err) {
      console.error(err);
      showToast("Error confirming batch allocation", "error");
    } finally {
      setAllocationLoading(false);
    }
  };

  const handlePublishTimetable = async (batchId: string) => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/publish-timetable/${batchId}`, {
        method: "POST"
      });
      const data = await res.json();
      if (data.error) {
        showToast(data.error, "error");
      } else {
        showToast("Batch successfully published to the Timetable tab!", "success");
        fetchBatches();
        if (selectedBatchId === batchId) {
          fetchBatchDetails(batchId);
        }
      }
    } catch (e) {
      console.error(e);
      showToast("Error publishing timetable", "error");
    }
  };

  const handleExportBatchCSV = (batchId: string) => {
    window.open(`${backendBaseUrl}/api/admin/allocations/export/${batchId}`, "_blank");
    showToast("Exporting batch CSV details...", "info");
  };

  // Fetch initial data
  useEffect(() => {
    fetchFaculties();
    fetchRooms();
  }, []);

  // Sync active user sessions
  useEffect(() => {
    if (user) {
      if (user.role === "Faculty" || user.role === "DeptHead") {
        fetchMyBookings();
        fetchMyNotifications();
        fetchMyCoursePreferences();
        fetchMySemesterAllocations();
        fetchPrefWindow();
      }
      if (user.role === "DeptHead" || user.role === "Admin") {
        fetchDeptBookings();
        fetchAllCourseSections();
      }
      if (user.role === "Admin") {
        fetchAdminConfig();
        fetchAuditLogs();
        fetchReports();
        fetchPrefWindow();
      }
      // Set appropriate active tab
      if (user.role === "Student") {
        setActiveTab("timetable");
      } else if (user.role === "Admin") {
        setActiveTab("admin");
      } else {
        setActiveTab("timetable");
      }
    }
  }, [user]);

  // Sync admin tab updates
  useEffect(() => {
    if (activeTab === "admin" && user?.role === "Admin") {
      fetchAdminConfig();
      fetchAuditLogs();
      fetchReports();
      fetchPrefWindow();
      fetchAdminFaculties();
    }
  }, [activeTab]);

  // Sync semester allocation batches updates
  useEffect(() => {
    if ((activeTab === "allocation" || activeTab === "timetable") && user?.role === "Admin") {
      fetchBatches();
    }
    if (activeTab === "admin" && user?.role === "Admin") {
      fetchAdminAnalytics();
    }
    if (activeTab === "search") {
      fetchHeatmapData();
    }
    if (activeTab === "profile") {
      fetchMyProfile();
    }
  }, [activeTab, user]);

  const fetchMyProfile = async () => {
    if (!user?.id) return;
    try {
      const res = await fetch(`${backendBaseUrl}/api/faculty/${user.id}`);
      const data = await res.json();
      if (res.ok) {
        setMyProfile(data.profile);
        setMyStats(data.stats);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchFaculties = async () => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/faculty`);
      const data = await res.json();
      setFaculties(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchRooms = async () => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/classrooms`);
      let data = await res.json();
      
      try {
        const utilRes = await fetch(`${backendBaseUrl}/api/admin/rooms/utilization`);
        if (utilRes.ok) {
          const utilData = await utilRes.json();
          const utilMap = new Map(utilData.map((u: any) => [u.room_id, u.utilization_rate]));
          data = data.map((r: any) => ({ ...r, utilization_rate: utilMap.get(r.room_id) || 0 }));
        }
      } catch (e) {
        console.error("Failed to fetch utilization", e);
      }

      const cleanData = Array.isArray(data) ? data : [];
      setRooms(cleanData);
      if (cleanData.length > 0 && !selectedRoomId) {
        setSelectedRoomId(cleanData[0].room_id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchMyBookings = async () => {
    if (!user?.id) return;
    try {
      const res = await fetch(`${backendBaseUrl}/api/bookings?facultyId=${user.id}`);
      const data = await res.json();
      setMyBookings(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
      setMyBookings([]);
    }
  };

  const fetchMyNotifications = async () => {
    if (!user?.id) return;
    try {
      const res = await fetch(`${backendBaseUrl}/api/faculty/${user.id}/notifications`);
      const data = await res.json();
      setMyNotifications(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchMySemesterAllocations = async () => {
    if (!user?.email) return;
    setLoadingMyAllocations(true);
    try {
      const res = await fetch(`${backendBaseUrl}/api/faculty/my-allocations?email=${encodeURIComponent(user.email)}`);
      const data = await res.json();
      setMySemesterAllocations(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
      setMySemesterAllocations([]);
    } finally {
      setLoadingMyAllocations(false);
    }
  };



  const fetchAdminAnalytics = async () => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/analytics`);
      const data = await res.json();
      setAdminAnalytics(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchHeatmapData = async () => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/classrooms/heatmap`);
      const data = await res.json();
      setHeatmapData(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchDeptBookings = async () => {
    if (!user) return;
    const dept = user.facultyDetails?.department || (user as any).department || "ECE";
    try {
      const res = await fetch(`${backendBaseUrl}/api/bookings?department=${encodeURIComponent(dept)}`);
      const data = await res.json();
      setDeptBookings(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
      setDeptBookings([]);
    }
  };

  const fetchImportedFaculty = async () => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/faculty/imported-list`);
      const data = await res.json();
      setImportedFaculty(Array.isArray(data) ? data : []);
      if (Array.isArray(data) && data.length > 0 && !selectedFacultyEmail) {
        setSelectedFacultyEmail(data[0].email);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchTimetableBatchSpecific = async (batchId: string) => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/allocation/batch/${batchId}`);
      const data = await res.json();
      setTimetableBatchData(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchPublishedTimetable = async () => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/classrooms/published-batch`);
      const data = await res.json();
      if (data.batch) {
        setTimetableBatchId(data.batch.batch_id);
        setTimetableBatchData(data);
      } else {
        setTimetableBatchId("");
        setTimetableBatchData(null);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchTimetable = async (idOrEmail: string, date: string, modeOverride?: "room" | "faculty") => {
    try {
      const activeMode = modeOverride || timetableMode;
      let url = `${backendBaseUrl}/api/classrooms/${idOrEmail}/timetable?startDate=${date}`;
      if (activeMode === "faculty") {
        url = `${backendBaseUrl}/api/faculty/timetable?email=${idOrEmail}&startDate=${date}`;
      }
      const res = await fetch(url);
      const data = await res.json();
      setTimetableData(data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    if (timetableMode === "room" && selectedRoomId && timetableDate) {
      fetchTimetable(selectedRoomId, timetableDate, "room");
    } else if (timetableMode === "faculty" && selectedFacultyEmail && timetableDate) {
      fetchTimetable(selectedFacultyEmail, timetableDate, "faculty");
    }
  }, [selectedRoomId, selectedFacultyEmail, timetableDate, timetableMode]);

  useEffect(() => {
    if (activeTab === "timetable") {
      fetchImportedFaculty();
      fetchPublishedTimetable();
    }
  }, [activeTab]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearched(true);
    try {
      let url = `${backendBaseUrl}/api/classrooms?date=${searchDate}&startTime=${searchStartTime}&endTime=${searchEndTime}&capacity=${searchCapacity}`;
      if (searchBuilding) url += `&buildingId=${searchBuilding}`;
      if (searchFloor) url += `&floor=${searchFloor}`;
      if (searchRoomType) url += `&roomType=${searchRoomType}`;
      if (searchEquipment.length > 0) url += `&equipment=${searchEquipment.join(",")}`;
      if (user?.id && user.role !== "Admin") url += `&facultyId=${user.id}`;

      const res = await fetch(url);
      const data = await res.json();
      setSearchResults(data);
      showToast(`Found ${data.length} match(es) for your request.`, "success");
    } catch (e) {
      console.error(e);
      showToast("Error searching classrooms.", "error");
    }
  };

  const submitBooking = async (confirmOpt?: string, isDraft: boolean = false) => {
    if (!user?.id || !bookingRoom) return;
    setBookingError(null);
    try {
      const payload: any = {
        facultyId: user.id,
        roomId: bookingRoom.room_id,
        courseCode,
        courseName,
        classSize: parseInt(classSize) || 30,
        bookingType,
        notes,
        isDraft,
      };

      if (bookingType === "OneTime") {
        payload.startDt = `${searchDate}T${searchStartTime}`;
        payload.endDt = `${searchDate}T${searchEndTime}`;
      } else {
        payload.pattern = pattern;
        payload.daysOfWeek = daysOfWeek;
        payload.startDate = recurStartDate;
        payload.endDate = recurEndDate;
        payload.startTime = `${searchStartTime}:00`;
        payload.endTime = `${searchEndTime}:00`;
        if (confirmOpt) payload.confirmOption = confirmOpt;
      }

      const res = await fetch(`${backendBaseUrl}/api/bookings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (res.status === 409 && data.requiresChoice) {
        setRecurConflicts(data);
        showToast("Partial conflict identified. Please review choices.", "warning");
        return;
      }

      if (!res.ok) {
        if (res.status === 400) {
          setBookingError(data.error);
        } else {
          showToast(data.error || "Failed to submit booking", "error");
        }
        return;
      }

      if (isDraft) {
        showToast(`Draft successfully saved!`, "success");
      } else if (bookingType === "OneTime") {
        showToast(`Email & SMS Sent! Booking ID: ${data.booking.booking_request_id} is ${data.resolution?.status || 'Pending'}.`, "success");
      } else {
        showToast(`Email & SMS Sent! Recurring series created. ${data.confirmedCount} confirmed, ${data.skippedCount} waitlisted.`, "success");
      }

      // Clean up modal states
      setBookingRoom(null);
      setRecurConflicts(null);
      setBookingError(null);
      setCourseCode("");
      setCourseName("");
      setClassSize("");
      setNotes("");
      fetchMyBookings();
      fetchMyNotifications();
      fetchRooms();
      if (selectedRoomId) fetchTimetable(selectedRoomId, timetableDate);
    } catch (e) {
      console.error(e);
      showToast("Error submitting booking.", "error");
    }
  };

  const handleFetchAlternatives = async (bookingId: string) => {
    try {
      setViewingAlternativesBookingId(bookingId);
      const res = await fetch(`${backendBaseUrl}/api/bookings/${bookingId}/alternatives`);
      const data = await res.json();
      setAlternativesList(data);
    } catch (e) {
      console.error(e);
      showToast("Error fetching alternatives", "error");
    }
  };

  const handleRebook = async (bookingId: string, roomId: string) => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/bookings/${bookingId}/rebook`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ roomId }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed to rebook", "error");
        return;
      }
      showToast(`One-Click Rebooked successfully! New Status: ${data.resolution?.status || 'Confirmed'}`, "success");
      setViewingAlternativesBookingId(null);
      setAlternativesList([]);
      fetchMyBookings();
      fetchRooms();
    } catch (e) {
      console.error(e);
      showToast("Error rebooking", "error");
    }
  };

  const handleModifyBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBooking) return;
    try {
      const res = await fetch(`${backendBaseUrl}/api/bookings/${editingBooking.booking_id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          notes: editNotes,
          classSize: parseInt(editClassSize) || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed to modify booking", "error");
        return;
      }
      showToast(`Booking modified successfully! New Status: ${data.resolution?.status || 'Confirmed'}`, "success");
      setEditingBooking(null);
      fetchMyBookings();
      fetchRooms();
      if (selectedRoomId) fetchTimetable(selectedRoomId, timetableDate);
    } catch (e) {
      console.error(e);
      showToast("Error modifying booking.", "error");
    }
  };

  const handleMarkUtilization = async (bookingId: string, status: "Completed" | "AutoCancelledNoShow") => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/bookings/${bookingId}/mark-status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed to mark utilization", "error");
        return;
      }
      showToast(`Booking marked as ${status === "Completed" ? "Completed" : "No-Show"} successfully!`, "success");
      fetchMyBookings();
    } catch (e) {
      console.error(e);
      showToast("Error marking utilization", "error");
    }
  };

  const handleExportBookingPDF = (b: any) => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      showToast("Pop-up blocker prevented PDF window.", "error");
      return;
    }
    
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${b.booking_id}`;
    
    printWindow.document.write(`
      <html>
        <head>
          <title>Booking Confirmation - ${b.booking_request_id}</title>
          <style>
            body { font-family: sans-serif; padding: 40px; color: #333; }
            .card { border: 2px solid #ccc; padding: 30px; border-radius: 12px; max-width: 500px; margin: 0 auto; }
            .header { text-align: center; border-bottom: 2px dashed #ccc; padding-bottom: 20px; margin-bottom: 20px; }
            .header h2 { margin: 0; color: #000; }
            .qr { text-align: center; margin: 20px 0; }
            .detail { display: flex; justify-content: space-between; margin: 10px 0; font-size: 14px; }
            .label { font-weight: bold; color: #666; }
            .value { font-weight: bold; }
          </style>
        </head>
        <body>
          <div class="card">
            <div class="header">
              <h2>CLASSROOM BOOKING</h2>
              <p style="margin:5px 0 0 0; font-size:12px; color:#888;">Official Confirmation Pass</p>
            </div>
            <div class="qr">
              <img src="${qrUrl}" alt="QR Code" />
              <p style="font-size:10px; color:#999; margin-top:5px;">Scan at classroom door to check in</p>
            </div>
            <div class="detail"><span class="label">Booking ID:</span><span class="value">${b.booking_request_id}</span></div>
            <div class="detail"><span class="label">Course:</span><span class="value">${b.course_code}</span></div>
            <div class="detail"><span class="label">Room:</span><span class="value">Room ${b.room_number || b.room_id}</span></div>
            <div class="detail"><span class="label">Date:</span><span class="value">${new Date(b.start_dt).toLocaleDateString()}</span></div>
            <div class="detail"><span class="label">Time:</span><span class="value">${new Date(b.start_dt).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})} - ${new Date(b.end_dt).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span></div>
            <div class="detail"><span class="label">Faculty:</span><span class="value">${b.full_name_en || 'Faculty Colleague'}</span></div>
            <div class="detail"><span class="label">Status:</span><span class="value" style="color: green;">${b.status}</span></div>
          </div>
          <script>
            window.onload = function() {
              window.print();
            }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleCancelBooking = async (bookingId: string) => {
    const booking = myBookings.find(b => b.booking_id === bookingId) || deptBookings.find(b => b.booking_id === bookingId);
    let scope = "instance";
    if (booking && booking.series_id) {
      const confirmSeries = confirm("This booking is part of a recurring series. Do you want to cancel the ENTIRE future series? (Click 'OK' to cancel the whole series, or 'Cancel' to cancel only this single instance)");
      if (confirmSeries) {
        scope = "series";
      }
    }

    const reason = prompt("Enter reason for cancellation:");
    if (reason === null) return;
    try {
      const res = await fetch(`${backendBaseUrl}/api/bookings/${bookingId}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          cancelRole: user?.role === "Admin" ? "Admin" : user?.role === "DeptHead" ? "Department Head" : "Faculty",
          cancelReason: reason,
          scope,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed to cancel booking", "error");
        return;
      }
      showToast(data.message || "Booking cancelled successfully", "success");
      fetchMyBookings();
      fetchDeptBookings();
      if (selectedRoomId) fetchTimetable(selectedRoomId, timetableDate);
    } catch (e) {
      console.error(e);
      showToast("Error cancelling booking.", "error");
    }
  };

  const handleCheckin = async (bookingId: string) => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/bookings/${bookingId}/checkin`, {
        method: "POST",
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed check-in", "error");
        return;
      }
      showToast("Checked in successfully!", "success");
      fetchMyBookings();
      if (selectedRoomId) fetchTimetable(selectedRoomId, timetableDate);
    } catch (e) {
      console.error(e);
      showToast("Error processing check-in.", "error");
    }
  };

  // Override Waitlist
  const handleOverride = async (bookingId: string) => {
    const reason = prompt("Enter override approval reason (Mandatory):");
    if (!reason || !reason.trim()) {
      showToast("Override reason is mandatory.", "error");
      return;
    }
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/override`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bookingId,
          overrideReason: reason,
          deptHeadId: user?.id,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed override waitlist", "error");
        return;
      }
      showToast("Override completed! Slot confirmed.", "success");
      fetchDeptBookings();
      if (selectedRoomId) fetchTimetable(selectedRoomId, timetableDate);
    } catch (e) {
      console.error(e);
      showToast("Error overrides waitlist.", "error");
    }
  };

  // Admin Config
  const fetchAdminConfig = async () => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/config`);
      const data = await res.json();
      setSysConfig(data);
      setEditConfigWindow(data.booking_window_days?.days || "60");
      setEditConfigGrace(data.no_show_grace_period?.minutes || "15");
      setEditConfigMaxWeeks(data.recurring_max_weeks?.weeks || "18");
      setEditConfigWindowExamHall(data.booking_window_ExamHall?.days || "90");
      setEditConfigWindowLectureHall(data.booking_window_LectureHall?.days || "60");
      setEditConfigWindowSeminarRoom(data.booking_window_SeminarRoom?.days || "30");
      setEditConfigWindowComputerLab(data.booking_window_ComputerLab?.days || "30");
      setEditConfigDurationExamHall(data.max_duration_ExamHall?.hours || "4");
      setEditConfigDurationLectureHall(data.max_duration_LectureHall?.hours || "4");
      setEditConfigDurationSeminarRoom(data.max_duration_SeminarRoom?.hours || "3");
      setEditConfigDurationComputerLab(data.max_duration_ComputerLab?.hours || "3");
    } catch (e) {
      console.error(e);
    }
  };

  const fetchPrefWindow = async () => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/preference-window`);
      const data = await res.json();
      setPrefWindow(data);
      if (data.semester) setPrefWindowSemester(data.semester);
      if (data.deadline) setPrefWindowDeadline(data.deadline.substring(0, 16)); // datetime-local format
      if (data.instructions) setPrefWindowInstructions(data.instructions);
    } catch (e) {
      console.error(e);
    }
  };

  const handleTogglePrefWindow = async (open: boolean) => {
    setSavingPrefWindow(true);
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/preference-window`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          open,
          semester: prefWindowSemester || null,
          deadline: prefWindowDeadline || null,
          instructions: prefWindowInstructions || null,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setPrefWindow(data.preference_window);
        showToast(open ? "✅ Preference window is now OPEN. Faculty can submit choices." : "🔒 Preference window is now CLOSED.", open ? "success" : "info");
      } else {
        showToast(data.error || "Failed to update preference window.", "error");
      }
    } catch (e) {
      showToast("Error toggling preference window.", "error");
    } finally {
      setSavingPrefWindow(false);
    }
  };

  const handleUpdateConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/config`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          booking_window_days: editConfigWindow,
          no_show_grace_period: editConfigGrace,
          recurring_max_weeks: editConfigMaxWeeks,
          booking_window_ExamHall: editConfigWindowExamHall,
          booking_window_LectureHall: editConfigWindowLectureHall,
          booking_window_SeminarRoom: editConfigWindowSeminarRoom,
          booking_window_ComputerLab: editConfigWindowComputerLab,
          max_duration_ExamHall: editConfigDurationExamHall,
          max_duration_LectureHall: editConfigDurationLectureHall,
          max_duration_SeminarRoom: editConfigDurationSeminarRoom,
          max_duration_ComputerLab: editConfigDurationComputerLab,
        }),
      });
      if (res.ok) {
        showToast("System configurations updated successfully!", "success");
        fetchAdminConfig();
      } else {
        showToast("Failed to update config.", "error");
      }
    } catch (e) {
      console.error(e);
      showToast("Error updating config.", "error");
    }
  };

  const fetchAuditLogs = async () => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/audit-logs`);
      const data = await res.json();
      setAuditLogs(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleReportIssue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedIssueBooking) return;
    try {
      const res = await fetch(`${backendBaseUrl}/api/bookings/${selectedIssueBooking.booking_id}/report-issue`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          issueType,
          description: issueDescription,
          facultyId: user?.id || "",
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed to submit issue report", "error");
        return;
      }
      showToast("Classroom issue reported to admin successfully.", "success");
      setSelectedIssueBooking(null);
      fetchMyNotifications();
    } catch (e) {
      console.error(e);
      showToast("Error reporting room issue.", "error");
    }
  };

  const handleApproveBooking = async (bookingId: string) => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/approve-booking`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bookingId,
          adminId: user?.id || "00000000-0000-0000-0000-000000000000",
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed to approve booking", "error");
        return;
      }
      showToast("Booking approved and confirmed successfully!", "success");
      fetchReports();
      fetchAuditLogs();
      if (selectedRoomId) fetchTimetable(selectedRoomId, timetableDate);
    } catch (e) {
      console.error(e);
      showToast("Error approving booking.", "error");
    }
  };

  const fetchReports = async () => {
    try {
      const uRes = await fetch(`${backendBaseUrl}/api/reports/utilization`);
      const uData = await uRes.json();
      setUtilizationReport(Array.isArray(uData) ? uData : []);

      const nRes = await fetch(`${backendBaseUrl}/api/reports/noshow`);
      const nData = await nRes.json();
      setNoShowReport(Array.isArray(nData) ? nData : []);

      const cRes = await fetch(`${backendBaseUrl}/api/reports/conflicts`);
      const cData = await cRes.json();
      setConflictReport(Array.isArray(cData) ? cData : []);

      const aRes = await fetch(`${backendBaseUrl}/api/bookings?status=PendingAdminApproval`);
      const aData = await aRes.json();
      setPendingApprovals(Array.isArray(aData) ? aData : []);

      const issuesRes = await fetch(`${backendBaseUrl}/api/faculty/00000000-0000-0000-0000-000000000000/notifications`);
      const issuesData = await issuesRes.json();
      setReportedIssues(issuesData.filter((notif: any) => notif.type === "IssueReport"));
    } catch (e) {
      console.error(e);
    }
  };

  const handleTriggerJobs = async () => {
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/run-jobs`, { method: "POST" });
      const data = await res.json();
      showToast(`Background jobs executed! Cancelled: ${data.cancelledCount} no-shows. Reminders: ${data.remindersCount} sent.`, "success");
      if (selectedRoomId) fetchTimetable(selectedRoomId, timetableDate);
      fetchReports();
    } catch (e) {
      console.error(e);
      showToast("Error running manual background jobs.", "error");
    }
  };

  const handleMaintenance = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/maintenance`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          roomId: maintRoomId,
          startDt: maintStart,
          endDt: maintEnd,
          reason: maintReason,
          adminId: user?.id || "00000000-0000-0000-0000-000000000000",
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed scheduling maintenance", "error");
        return;
      }
      showToast(`Maintenance scheduled. Cancelled ${data.cancelledCount} conflicting bookings.`, "success");
      setMaintRoomId("");
      setMaintStart("");
      setMaintEnd("");
      setMaintReason("");
      if (selectedRoomId) fetchTimetable(selectedRoomId, timetableDate);
    } catch (e) {
      console.error(e);
      showToast("Error scheduling maintenance window.", "error");
    }
  };

  const handleAddClassroom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomNumber || !newBuildingId || !newFloor || !newCapacity) {
      showToast("Please fill all required fields.", "warning");
      return;
    }

    try {
      const equipment = {
        projector: newEquipProjector,
        smart_board: newEquipSmartBoard,
        whiteboard: newEquipWhiteboard,
        air_conditioning: newEquipAC,
        audio_system: newEquipAudioSystem,
      };

      const res = await fetch(`${backendBaseUrl}/api/classrooms`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          roomNumber: newRoomNumber,
          buildingId: newBuildingId,
          floor: parseInt(newFloor, 10),
          capacity: parseInt(newCapacity, 10),
          roomType: newRoomType,
          equipment,
          operatingHours: {
            default: { open: "08:00", close: "22:00" }
          }
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed to add classroom.", "error");
        return;
      }

      showToast(`Classroom ${data.room_number} added successfully!`, "success");
      setNewRoomNumber("");
      setNewBuildingId("");
      setNewFloor("");
      setNewCapacity("");
      setNewRoomType("LectureHall");
      setNewEquipProjector(false);
      setNewEquipSmartBoard(false);
      setNewEquipWhiteboard(false);
      setNewEquipAC(false);
      setNewEquipAudioSystem(false);
      fetchRooms();
    } catch (e) {
      console.error(e);
      showToast("Error adding classroom.", "error");
    }
  };

  const handleBulkCancel = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch(`${backendBaseUrl}/api/admin/bulk-cancel`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          buildingId: bulkBldgId || undefined,
          startDt: bulkStart,
          endDt: bulkEnd,
          reason: bulkReason,
          adminId: user?.id || "00000000-0000-0000-0000-000000000000",
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Failed bulk cancellation", "error");
        return;
      }
      showToast(`Emergency cancellation complete! Cancelled ${data.cancelledCount} bookings.`, "success");
      setBulkBldgId("");
      setBulkStart("");
      setBulkEnd("");
      setBulkReason("");
      if (selectedRoomId) fetchTimetable(selectedRoomId, timetableDate);
    } catch (e) {
      console.error(e);
      showToast("Error running bulk cancellations.", "error");
    }
  };

  const downloadExcelTemplate = () => {
    try {
      const headers = [
        ["room_number", "building_code", "floor", "capacity", "room_type", "projector", "whiteboard", "smartboard", "air_conditioning", "audio_system"],
        ["NAC-501", "NAC", 5, 40, "LectureHall", "true", "true", "false", "true", "false"],
        ["SAC-202", "SAC", 2, 35, "SeminarRoom", "true", "true", "false", "true", "true"],
        ["NAC-405", "NAC", 4, 50, "ComputerLab", "true", "true", "true", "true", "false"]
      ];

      const ws = XLSX.utils.aoa_to_sheet(headers);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Classrooms Template");

      // Write and download
      XLSX.writeFile(wb, "classroom_import_template.xlsx");
      showToast("Classroom Excel template downloaded.", "success");
    } catch (e) {
      console.error(e);
      showToast("Failed to generate Excel template.", "error");
    }
  };

  const handleExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const bstr = event.target?.result;
        const workbook = XLSX.read(bstr, { type: "binary" });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const rawRows = XLSX.utils.sheet_to_json(sheet) as any[];

        const formattedRooms = rawRows.map((row: any) => {
          const equipment: any = {};
          if (row.projector === true || String(row.projector).toLowerCase() === "true" || row.projector === 1) equipment.projector = true;
          if (row.whiteboard === true || String(row.whiteboard).toLowerCase() === "true" || row.whiteboard === 1) equipment.whiteboard = true;
          if (row.smartboard === true || String(row.smartboard).toLowerCase() === "true" || row.smartboard === 1) equipment.smartboard = true;
          if (row.air_conditioning === true || String(row.air_conditioning).toLowerCase() === "true" || row.air_conditioning === 1 || row.ac === true || String(row.ac).toLowerCase() === "true" || row.ac === 1) {
            equipment.air_conditioning = true;
          }
          if (row.audio_system === true || String(row.audio_system).toLowerCase() === "true" || row.audio_system === 1) equipment.audio_system = true;

          return {
            room_number: String(row.room_number || row.roomNumber || ""),
            building_code: String(row.building_code || row.buildingCode || ""),
            floor: parseInt(row.floor, 10) || 1,
            capacity: parseInt(row.capacity, 10) || 30,
            room_type: String(row.room_type || row.roomType || "LectureHall"),
            equipment,
          };
        }).filter(r => r.room_number && r.building_code);

        if (formattedRooms.length === 0) {
          showToast("No valid room records found in the spreadsheet.", "warning");
          return;
        }

        setImportJson(JSON.stringify({ rooms: formattedRooms }, null, 2));
        showToast(`Successfully parsed ${formattedRooms.length} room(s). Review JSON details below and click Import Rooms.`, "success");
      } catch (err) {
        console.error(err);
        showToast("Failed to parse Excel file.", "error");
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleImportRooms = async () => {
    try {
      const roomsObj = JSON.parse(importJson);
      const res = await fetch(`${backendBaseUrl}/api/admin/import-rooms`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(roomsObj),
      });
      const data = await res.json();
      showToast(data.summary, data.failed > 0 ? "warning" : "success");
      fetchRooms();
    } catch (e) {
      showToast("Invalid JSON format for classroom inventory.", "error");
    }
  };

  const getWeekDays = () => {
    if (!timetableData?.weekStart) return [];
    const days = [];
    const base = new Date(timetableData.weekStart);
    for (let i = 0; i < 7; i++) {
      const d = new Date(base);
      d.setDate(base.getDate() + i);
      days.push(d);
    }
    return days;
  };

  const getDayBookings = (dayDate: Date) => {
    const combined = [];
    
    // Add Semester Allocations (Template)
    if (timetableBatchId && timetableBatchData?.allocations) {
      const dayIndex = dayDate.getDay();
      const batchBookings = timetableBatchData.allocations.filter((a: any) => {
        if (timetableMode === "room" && a.room_id !== selectedRoomId) return false;
        if (timetableMode === "faculty" && a.allocated_faculty_email !== selectedFacultyEmail && a.allocated_faculty_name !== selectedFacultyEmail) return false;
        return classMatchesDay(a, dayIndex);
      }).map((a: any) => ({
        booking_id: `alloc_${a.allocation_id}`,
        course_code: a.course_code || '—',
        course_name: `Sec ${a.section_number} (${a.enrollment_size} caps)`,
        start_dt: `${dayDate.toISOString().split('T')[0]}T${a.allocated_start_time || '00:00:00'}`,
        end_dt: `${dayDate.toISOString().split('T')[0]}T${a.allocated_end_time || '00:00:00'}`,
        faculty_name: a.allocated_faculty_name || a.allocated_faculty_email || "TBA",
        status: "Semester Allocation",
        booking_type: "Regular"
      }));
      combined.push(...batchBookings);
    }

    // Add Ad-Hoc / Extra Bookings for this specific date
    if (timetableData?.bookings) {
      const dateStr = dayDate.toISOString().split("T")[0];
      const dailyBookings = timetableData.bookings.filter((b: any) => {
        const bDate = new Date(b.start_dt).toISOString().split("T")[0];
        return bDate === dateStr;
      });
      combined.push(...dailyBookings);
    }
    
    // Sort chronologically by start time for the UI
    combined.sort((a, b) => {
      const t1 = a.start_dt.split('T')[1];
      const t2 = b.start_dt.split('T')[1];
      return t1.localeCompare(t2);
    });

    return combined;
  };

  const getDayMaintenance = (dayDate: Date) => {
    if (!timetableData?.maintenance) return [];
    const dateStr = dayDate.toISOString().split("T")[0];
    return timetableData.maintenance.filter((m: any) => {
      const mDate = new Date(m.start_dt).toISOString().split("T")[0];
      return mDate === dateStr;
    });
  };

  const formatTimeRange = (start: string, end: string) => {
    const s = new Date(start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    const e = new Date(end).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    return `${s} - ${e}`;
  };

  const handleEquipmentToggle = (eq: string) => {
    if (searchEquipment.includes(eq)) {
      setSearchEquipment(searchEquipment.filter((x) => x !== eq));
    } else {
      setSearchEquipment([...searchEquipment, eq]);
    }
  };

  const handleDayOfWeekToggle = (dayNum: number) => {
    if (daysOfWeek.includes(dayNum)) {
      setDaysOfWeek(daysOfWeek.filter((d) => d !== dayNum));
    } else {
      setDaysOfWeek([...daysOfWeek, dayNum].sort());
    }
  };

  const handleSignOut = () => {
    setUser(null);
    setMyBookings([]);
    setMyNotifications([]);
    setDeptBookings([]);
    showToast("Signed out of secure session.", "info");
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    try {
      const res = await fetch(`${backendBaseUrl}/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: loginEmail, password: loginPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        setLoginError(data.error || "Authentication failed.");
        showToast("Invalid credentials, try demo bypass selector.", "error");
        return;
      }
      setUser(data.user);
      setLoginEmail("");
      setLoginPassword("");
      showToast(`Welcome back, ${data.user.name}!`, "success");
    } catch (err) {
      setLoginError("Could not connect to backend server.");
      showToast("Backend connection offline.", "error");
    }
  };

  // LOGIN SCREEN RENDER
  if (!user) {
    return (
      <main className={`relative min-h-screen flex items-center justify-center overflow-hidden transition-colors duration-300 ${isDark ? 'bg-[#030712] text-slate-100' : 'light-mode bg-slate-100 text-slate-900'} p-4`}>
        <div className={`absolute inset-0 transition-opacity duration-500 ${isDark ? 'opacity-100' : 'opacity-20'}`} style={isDark ? { backgroundImage: 'radial-gradient(circle_at_top_left, rgba(34,211,238,0.15), transparent 45%), radial-gradient(circle_at_bottom_right, rgba(16,185,129,0.08), transparent 40%)' } : {}} />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(148,163,184,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(148,163,184,0.03)_1px,transparent_1px)] bg-[size:40px_40px] opacity-40" />

        <div className="relative w-full max-w-lg glass-panel rounded-3xl p-8 shadow-2xl backdrop-blur-xl space-y-6">
          <div className="text-center space-y-2">
            <div className="flex justify-between items-center w-full mb-4">
              <div className="inline-flex items-center gap-2 rounded-full border border-cyan-400/25 bg-cyan-400/10 px-4 py-1.5 text-xs font-semibold text-cyan-300">
                <span className="h-2 w-2 rounded-full bg-cyan-400 pulse-dot" />
                Institutional SSO Portal
              </div>
              <button
                type="button"
                onClick={toggleTheme}
                className="rounded-xl border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-300 hover:bg-white/10 transition cursor-pointer"
              >
                {isDark ? "☀️ Light" : "🌙 Dark"}
              </button>
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight text-white">
              Classroom Booking System
            </h1>
            <p className="text-xs text-slate-400">
              Provide credentials or choose a bypass profile to access resources.
            </p>
          </div>

          <form onSubmit={handleLoginSubmit} className="flex flex-col space-y-4 rounded-2xl border border-white/5 bg-slate-900/30 p-6">
            <h3 className="text-xs font-bold tracking-widest text-cyan-400 uppercase">Secure Login</h3>

            {loginError && (
              <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-300">
                ⚠️ {loginError}
              </div>
            )}

            <div>
              <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">Email / Username</label>
              <input
                type="text"
                required
                placeholder="e.g. admin or faculty email"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-sm text-slate-200 outline-none focus:ring-2 focus:ring-cyan-400/30 transition-all"
              />
            </div>

            <div>
              <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">Password</label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-sm text-slate-200 outline-none focus:ring-2 focus:ring-cyan-400/30 transition-all"
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-xl bg-cyan-400 py-3 text-sm font-bold text-slate-950 hover:bg-cyan-300 transition duration-200 shadow-lg shadow-cyan-400/10 cursor-pointer"
            >
              Sign In
            </button>

            <div className="border-t border-white/5 pt-4 space-y-2">
              <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Demo SSO Bypass Profiles</label>
              <select
                onChange={(e) => {
                  const val = e.target.value;
                  if (val) {
                    const [email, pass] = val.split(":");
                    setLoginEmail(email);
                    setLoginPassword(pass);
                  }
                }}
                className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-3 text-xs text-slate-300 outline-none focus:ring-2 focus:ring-cyan-400/30 transition-all"
              >
                <option value="">-- Choose Profile for Instant Login --</option>
                <option value="admin:admin123">Registrar (System Admin)</option>
                <option value="arshad:password123">Dr. Arshad (ECE Dept Head)</option>
                <option value="nusrat:password123">Dr. Nusrat (ECE Faculty)</option>
                <option value="samiul:password123">Samiul Hasan (Lecturer)</option>
                <option value="student:student123">Read-only Student Portal</option>
              </select>
            </div>
          </form>

          <div className="pt-2">
            <BackendStatus />
          </div>
        </div>
      </main>
    );
  }

  // STANDARD APPLICATION DASHBOARD
  return (
    <main className={`relative min-h-screen transition-colors duration-300 ${isDark ? 'bg-[#030712] text-slate-100' : 'light-mode bg-slate-100 text-slate-900'}`}>
      <div className={`absolute inset-0 transition-opacity duration-500 ${isDark ? 'opacity-100' : 'opacity-20'}`} style={isDark ? { backgroundImage: 'radial-gradient(circle_at_top_left, rgba(34,211,238,0.12), transparent 45%), radial-gradient(circle_at_bottom_right, rgba(16,185,129,0.06), transparent 40%)' } : {}} />

      {/* Floating Toast Alerts */}
      <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-3 max-w-sm w-full">
        {toasts.map((t) => {
          const typeColors = {
            success: "border-emerald-400 bg-emerald-950/90 text-emerald-300",
            error: "border-rose-400 bg-rose-950/90 text-rose-300",
            warning: "border-amber-400 bg-amber-950/90 text-amber-300",
            info: "border-cyan-400 bg-cyan-950/90 text-cyan-300"
          };
          return (
            <div
              key={t.id}
              className={`toast-animate border rounded-2xl p-4 shadow-xl backdrop-blur-md flex justify-between items-start gap-3 transition-all duration-300 ${typeColors[t.type]}`}
            >
              <div className="text-xs font-semibold leading-relaxed">{t.message}</div>
              <button
                onClick={() => setToasts((prev) => prev.filter((item) => item.id !== t.id))}
                className="text-xs opacity-75 hover:opacity-100 font-mono"
              >
                ✕
              </button>
            </div>
          );
        })}
      </div>

      <div className="relative mx-auto flex w-full max-w-7xl flex-col gap-6 px-4 py-4 sm:px-6 sm:py-6 lg:px-8 lg:py-6">

        {/* Main Header Component */}
        <header className="sticky top-3 z-30 flex flex-col gap-4 rounded-3xl border border-white/10 bg-slate-950/80 px-6 py-5 shadow-2xl backdrop-blur-md md:flex-row md:items-center md:justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-cyan-400 pulse-dot" />
              <p className="text-[10px] uppercase tracking-[0.25em] text-cyan-400 font-extrabold">
                Classroom Booking Portal
              </p>
            </div>
            <h1 className="text-2xl font-extrabold tracking-tight text-white">
              CBS Console
            </h1>
          </div>

          <nav className="flex flex-wrap items-center gap-1.5 text-xs text-slate-200">
            {[
              { id: "timetable", label: "Timetable" },
              { id: "search", label: "Book Room", hidden: user.role === "Student" },
              { id: "dashboard", label: "My Bookings", hidden: user.role === "Student" || user.role === "Admin" },
              { id: "dept", label: "Dept Console", hidden: user.role !== "DeptHead" && user.role !== "Admin" },
              { id: "allocation", label: "Semester Allocation", hidden: user.role !== "Admin" },
              { id: "admin", label: "Admin Console", hidden: user.role !== "Admin" },
            ].map(
              (tab) =>
                !tab.hidden && (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`rounded-xl px-4 py-2.5 font-bold tracking-wide transition-all ${activeTab === tab.id
                      ? "bg-cyan-400 text-slate-950 shadow-lg shadow-cyan-400/25"
                      : "border border-white/5 bg-white/5 hover:bg-white/10"
                      }`}
                  >
                    {tab.label}
                  </button>
                )
            )}
          </nav>

          <div className="flex items-center gap-3.5 rounded-2xl border border-white/5 bg-slate-900/60 p-2.5 text-xs">
            <button
              onClick={toggleTheme}
              className="rounded-xl bg-white/10 p-2.5 text-xs font-bold text-slate-200 hover:bg-white/20 transition cursor-pointer"
              title="Toggle Theme"
            >
              {isDark ? "☀️" : "🌙"}
            </button>
            <div className="text-right">
              <p className="font-bold text-white leading-tight">{user.name}</p>
              <p className="text-[9px] text-cyan-400 uppercase tracking-widest font-extrabold mt-0.5">
                {user.role === "DeptHead" ? "ECE Dept Head" : user.role}
              </p>
            </div>
            <button
              onClick={handleSignOut}
              className="rounded-xl bg-white/10 px-3.5 py-2 text-[10px] font-bold text-slate-200 hover:bg-white/20 transition cursor-pointer"
            >
              Sign Out
            </button>
          </div>
        </header>

        {/* TAB 1: WEEKLY TIMETABLE VIEW */}
        {activeTab === "timetable" && (
          <section className="grid gap-6 lg:grid-cols-[300px_1fr]">
            {/* Sidebar directory */}
            <div className="rounded-3xl border border-white/10 bg-slate-950/40 p-6 backdrop-blur-xl flex flex-col gap-4">
              {/* Toggle switch */}
              <div className="grid grid-cols-2 p-1 rounded-xl bg-slate-900/60 border border-white/5">
                <button
                  onClick={() => setTimetableMode("room")}
                  className={`py-1.5 text-[10px] font-bold rounded-lg transition cursor-pointer ${timetableMode === "room"
                      ? "bg-cyan-400 text-slate-950"
                      : "text-slate-400 hover:text-white"
                    }`}
                >
                  🏫 Rooms
                </button>
                <button
                  onClick={() => setTimetableMode("faculty")}
                  className={`py-1.5 text-[10px] font-bold rounded-lg transition cursor-pointer ${timetableMode === "faculty"
                      ? "bg-cyan-400 text-slate-950"
                      : "text-slate-400 hover:text-white"
                    }`}
                >
                  👨‍🏫 Faculty
                </button>
              </div>

              {timetableMode === "room" ? (
                <>
                  <div>
                    <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase">Classrooms Directory</h3>
                    <p className="mt-1 text-xs text-slate-400 leading-relaxed">Select a classroom layout to view its booking timetable.</p>
                  </div>

                  <form className="relative" onSubmit={(e) => {
                    e.preventDefault();
                    const filtered = rooms.filter(r => r.room_number?.toLowerCase().includes(timetableRoomSearch.toLowerCase()));
                    if (filtered.length > 0) setSelectedRoomId(filtered[0].room_id);
                  }}>
                    <input
                      type="text"
                      placeholder="🔍 Search room and press Enter"
                      value={timetableRoomSearch}
                      onChange={(e) => setTimetableRoomSearch(e.target.value)}
                      className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2 text-xs text-slate-200 focus:ring-1 focus:ring-cyan-400 outline-none placeholder:text-slate-650"
                    />
                  </form>
                  <div className="space-y-6 max-h-[440px] overflow-y-auto pr-2 custom-scrollbar">
                    {Object.entries(
                      (Array.isArray(rooms) ? rooms : [])
                        .filter(r => r.room_number?.toLowerCase().includes(timetableRoomSearch.toLowerCase()))
                        .reduce((acc, room) => {
                        if (!acc[room.building_code]) acc[room.building_code] = {};
                        if (!acc[room.building_code][room.floor]) acc[room.building_code][room.floor] = [];
                        acc[room.building_code][room.floor].push(room);
                        return acc;
                      }, {} as Record<string, Record<number, any[]>>)
                    ).map(([buildingCode, floors]) => (
                      <div key={buildingCode} className="space-y-4">
                        <h4 className="text-sm font-bold text-white border-b border-white/10 pb-1 flex items-center gap-2">
                          🏢 {buildingCode} Building
                        </h4>
                        
                        <div className="space-y-3">
                          {Object.entries(floors)
                            .sort(([fA], [fB]) => Number(fB) - Number(fA)) // Sort floors descending
                            .map(([floor, floorRooms]) => (
                            <div key={floor} className="rounded-xl bg-slate-900/50 p-3 border border-white/5">
                              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                                Floor {floor}
                              </p>
                              <div className="grid grid-cols-2 gap-2">
                                {floorRooms.map((room) => (
                                  <button
                                    key={room.room_id}
                                    onClick={() => setSelectedRoomId(room.room_id)}
                                    className={`relative flex flex-col items-center justify-center rounded-lg border p-2.5 transition-all duration-200 ${
                                      selectedRoomId === room.room_id
                                        ? "border-cyan-400 bg-cyan-400/10 text-white shadow-md shadow-cyan-400/10 scale-95"
                                        : "border-white/5 bg-slate-950 hover:bg-slate-800 text-slate-300 hover:border-white/10"
                                    }`}
                                  >
                                    <span className="font-extrabold text-sm">{room.room_number.replace(`${buildingCode}-`, '')}</span>
                                    <span className="text-[8px] text-slate-400 mt-0.5">{room.capacity} seats</span>
                                    {selectedRoomId === room.room_id && (
                                      <div className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
                                    )}
                                  </button>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase">Faculty Directory</h3>
                    <p className="mt-1 text-xs text-slate-400 leading-relaxed">Select a faculty member to view their schedule.</p>
                  </div>

                  <div className="relative">
                    <input
                      type="text"
                      placeholder="🔍 Search faculty name/email..."
                      value={facultySearchQuery}
                      onChange={(e) => setFacultySearchQuery(e.target.value)}
                      className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2 text-xs text-slate-200 focus:ring-1 focus:ring-cyan-400 outline-none placeholder:text-slate-650"
                    />
                  </div>

                  <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                    {Array.from(new Map(importedFaculty.map(f => [f.email, f])).values())
                      .filter((fac) => {
                        const q = facultySearchQuery.toLowerCase();
                        return (
                          (fac.name || "").toLowerCase().includes(q) ||
                          (fac.email || "").toLowerCase().includes(q)
                        );
                      })
                      .map((fac, idx) => (
                        <button
                          key={`${fac.email}-${idx}`}
                          onClick={() => setSelectedFacultyEmail(fac.email)}
                          className={`w-full rounded-2xl border text-left p-4 transition-all duration-200 ${selectedFacultyEmail === fac.email
                              ? "border-cyan-400 bg-cyan-400/10 text-white shadow-md shadow-cyan-400/5"
                              : "border-white/5 bg-slate-900/35 hover:bg-slate-900/60 text-slate-300"
                            }`}
                        >
                          <div className="flex justify-between items-start gap-1">
                            <div className="min-w-0 flex-1">
                              <p className="font-bold text-sm text-white truncate">{fac.name || "Unknown Name"}</p>
                              <p className="text-[10px] text-slate-400 mt-0.5 truncate">{fac.email}</p>
                            </div>
                            <span className="text-[8px] uppercase font-bold text-cyan-400 bg-cyan-400/5 px-2 py-0.5 rounded border border-cyan-400/10 whitespace-nowrap">
                              {fac.designation || "Faculty"}
                            </span>
                          </div>
                        </button>
                      ))}
                    {importedFaculty.length === 0 && (
                      <p className="text-[11px] text-slate-500 italic text-center py-4">No faculty data available.</p>
                    )}
                  </div>
                </>
              )}

              <div className="border-t border-white/10 pt-4 space-y-2.5">
                <p className="text-xs font-bold text-slate-300 uppercase tracking-wider">Status Colors</p>
                {[
                  { color: "bg-emerald-400/20 border-emerald-400/30 text-emerald-300", label: "Confirmed booking" },
                  { color: "bg-amber-400/20 border-amber-400/30 text-amber-300", label: "Waitlisted (Conflict Queue)" },
                  { color: "bg-rose-500/20 border-rose-500/30 text-rose-300", label: "Under Maintenance" },
                  { color: "bg-purple-400/20 border-purple-400/30 text-purple-300", label: "Pending Admin Approval" },
                ].map((item) => (
                  <div key={item.label} className="flex items-center gap-2.5 text-xs">
                    <span className={`h-3 w-3 rounded ${item.color.split(" ")[0]} border ${item.color.split(" ")[1]}`} />
                    <span className="text-slate-300 font-medium">{item.label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Timetable Weekly Columns */}
            <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-6">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="text-2xl font-extrabold text-white">
                    {timetableMode === "room"
                      ? `Room ${rooms.find((r) => r.room_id === selectedRoomId)?.room_number || "Schedule"}`
                      : `Faculty: ${importedFaculty.find((f) => f.email === selectedFacultyEmail)?.name || selectedFacultyEmail || "Schedule"}`}
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Weekly grid layout starting Monday {new Date(timetableData?.weekStart || "").toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {timetableBatchId && (
                    <span className="rounded-xl border border-purple-400/30 bg-purple-500/10 px-3.5 py-2 text-xs font-bold text-purple-300 flex items-center gap-2">
                      📢 {timetableBatchData?.batch?.semester} Timetable
                    </span>
                  )}
                  <input
                    type="date"
                    value={timetableDate}
                    onChange={(e) => setTimetableDate(e.target.value)}
                    onClick={(e) => e.currentTarget.showPicker?.()}
                    className="rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2 text-xs text-slate-200 focus:ring-1 focus:ring-cyan-400 outline-none cursor-pointer"
                  />
                  <button
                    onClick={() => setTimetableDate(new Date().toISOString().split("T")[0])}
                    className="rounded-xl border border-white/10 bg-white/5 px-3.5 py-2 text-xs font-bold text-white hover:bg-white/10 transition"
                  >
                    Today
                  </button>
                </div>
              </div>

              <div className="flex bg-slate-900/20 border border-white/5 rounded-2xl overflow-hidden min-h-[600px] relative">
                {/* Time Axis */}
                <div className="w-14 sm:w-16 flex flex-col border-r border-white/5 bg-slate-950/40 relative z-10 shrink-0">
                  <div className="h-14 border-b border-white/5"></div>
                  {Array.from({ length: 11 }).map((_, i) => {
                    const hour = 8 + i;
                    return (
                      <div key={hour} className="h-16 border-b border-white/5 flex items-start justify-center text-[9px] font-bold text-slate-500 pt-2">
                        {hour > 12 ? hour - 12 : hour}:00 {hour >= 12 ? 'PM' : 'AM'}
                      </div>
                    );
                  })}
                </div>

                {/* Days Grid */}
                <div className="flex-1 grid grid-cols-7 divide-x divide-white/5 overflow-x-auto relative min-w-[700px]">
                  {/* Horizontal Grid Lines */}
                  <div className="absolute inset-0 pointer-events-none">
                    <div className="h-14 border-b border-white/5 w-full"></div>
                    {Array.from({ length: 11 }).map((_, i) => (
                      <div key={i} className="h-16 border-b border-white/5 w-full"></div>
                    ))}
                  </div>

                  {getWeekDays().map((dayDate, idx) => {
                    const bList = getDayBookings(dayDate);
                    const mList = getDayMaintenance(dayDate);
                    const isToday = new Date().toDateString() === dayDate.toDateString();

                    return (
                      <div key={idx} className={`relative flex flex-col min-w-[100px] ${isToday ? "bg-cyan-400/5" : ""}`}>
                        {/* Header */}
                        <div className={`h-14 border-b border-white/5 flex flex-col items-center justify-center relative z-10 bg-slate-950/60 backdrop-blur-xl ${isToday ? 'border-b-cyan-400' : ''}`}>
                          <p className={`text-[9px] uppercase font-extrabold ${isToday ? "text-cyan-400" : "text-slate-400"}`}>
                            {dayDate.toLocaleDateString([], { weekday: "short" })}
                          </p>
                          <p className={`text-sm font-black ${isToday ? "text-cyan-400" : "text-slate-200"}`}>
                            {dayDate.getDate()}
                          </p>
                        </div>
                        
                        {/* Events Container */}
                        <div className="flex-1 relative">
                          {mList.map((m: any) => {
                            let sH = 8, sM = 0, eH = 18, eM = 0;
                            if (m.start_time) [sH, sM] = m.start_time.split(':').map(Number);
                            if (m.end_time) [eH, eM] = m.end_time.split(':').map(Number);
                            
                            const startMins = Math.max(0, (sH * 60 + sM) - (8 * 60));
                            const endMins = Math.min((18 * 60) - (8 * 60), (eH * 60 + eM) - (8 * 60));
                            
                            const topPx = (startMins / 60) * 64; 
                            const heightPx = Math.max(20, ((endMins - startMins) / 60) * 64);

                            return (
                              <div 
                                key={m.maintenance_id} 
                                className="absolute inset-x-0.5 rounded-lg border border-rose-500/30 bg-rose-500/10 p-1 text-[9px] leading-tight overflow-hidden text-rose-200 shadow-md hover:z-20 transition-all cursor-not-allowed"
                                style={{ top: `${topPx}px`, height: `${heightPx}px` }}
                                title={m.reason}
                              >
                                <p className="font-bold text-rose-300">MAINT.</p>
                              </div>
                            );
                          })}

                          {bList.map((b: any) => {
                            let sH = 8, sM = 0, eH = 9, eM = 30;
                            if (b.start_dt) {
                              const d = new Date(b.start_dt);
                              sH = d.getHours();
                              sM = d.getMinutes();
                            }
                            if (b.end_dt) {
                              const d = new Date(b.end_dt);
                              eH = d.getHours();
                              eM = d.getMinutes();
                            }
                            
                            const startMins = Math.max(0, (sH * 60 + sM) - (8 * 60));
                            const endMins = Math.min((18 * 60) - (8 * 60), (eH * 60 + eM) - (8 * 60));
                            
                            const topPx = (startMins / 60) * 64;
                            const heightPx = Math.max(24, ((endMins - startMins) / 60) * 64);
                            
                            const isConfirmed = b.status === "Confirmed" || b.status === "Semester Allocation";
                            const isWaitlisted = b.status === "Waitlisted";

                            const cardColors = isConfirmed
                              ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-100 hover:bg-emerald-400/20"
                              : isWaitlisted
                                ? "border-amber-400/30 bg-amber-400/10 text-amber-100 hover:bg-amber-400/20"
                                : "border-purple-400/30 bg-purple-400/10 text-purple-100 hover:bg-purple-400/20";

                            return (
                              <div 
                                key={b.booking_id} 
                                className={`absolute inset-x-0.5 rounded-lg border p-1 sm:p-1.5 text-[9px] sm:text-[10px] leading-tight overflow-hidden ${cardColors} shadow-md shadow-black/20 hover:z-20 hover:shadow-xl transition-all cursor-pointer backdrop-blur-md flex flex-col`}
                                style={{ top: `${topPx}px`, height: `${heightPx}px` }}
                              >
                                <p className="font-bold text-white truncate">{b.course_code}</p>
                                <p className="truncate opacity-80 mt-0.5">👤 {b.faculty_name || "Faculty"}</p>
                                <p className="font-mono mt-auto opacity-60 text-[8px] truncate">
                                  {formatTimeRange(b.start_dt, b.end_dt)}
                                </p>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </section>
        )}

        {/* TAB 2: SEARCH & BOOK ROOM */}
        {activeTab === "search" && user.role !== "Student" && (
          <section className="grid gap-6 xl:grid-cols-[380px_1fr]">
            {/* Filter controls */}
            <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-4">
              <div>
                <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase">Search Classrooms</h3>
                <p className="text-xs text-slate-400 leading-relaxed mt-1">Specify constraints to discover available classroom slots.</p>
              </div>

              <form onSubmit={handleSearch} className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Booking Date</label>
                  <input
                    type="date"
                    required
                    value={searchDate}
                    onChange={(e) => setSearchDate(e.target.value)}
                    onClick={(e) => e.currentTarget.showPicker?.()}
                    className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-sm text-slate-200 outline-none focus:ring-1 focus:ring-cyan-400 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Time Interval</label>
                  <div className="flex gap-2">
                    <input
                      type="time"
                      required
                      value={searchStartTime}
                      onChange={(e) => setSearchStartTime(e.target.value)}
                      className="w-1/2 rounded-xl border border-white/10 bg-slate-950 px-3.5 py-3 text-xs text-slate-200 outline-none"
                    />
                    <input
                      type="time"
                      required
                      value={searchEndTime}
                      onChange={(e) => setSearchEndTime(e.target.value)}
                      className="w-1/2 rounded-xl border border-white/10 bg-slate-950 px-3.5 py-3 text-xs text-slate-200 outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Minimum Capacity</label>
                  <input
                    type="number"
                    required
                    value={searchCapacity}
                    onChange={(e) => setSearchCapacity(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-sm text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Building Location</label>
                  <select
                    value={searchBuilding}
                    onChange={(e) => setSearchBuilding(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-sm text-slate-200 outline-none"
                  >
                    <option value="">Any Building Core</option>
                    <option value="74d38e97-9c0f-43e6-9eb2-af38eccf17d0">North Academic Core (NAC)</option>
                    <option value="2691f423-cec3-432d-ba65-f133a63c23dc">South Academic Core (SAC)</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Classroom Type</label>
                  <select
                    value={searchRoomType}
                    onChange={(e) => setSearchRoomType(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-sm text-slate-200 outline-none"
                  >
                    <option value="">Any Facility Type</option>
                    <option value="LectureHall">Lecture Hall</option>
                    <option value="SeminarRoom">Seminar Room</option>
                    <option value="ComputerLab">Computer Lab</option>
                    <option value="ExamHall">Exam Hall</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Required Equipments</label>
                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300">
                    {[
                      { id: "projector", label: "Projector" },
                      { id: "air_conditioning", label: "Air Conditioning" },
                      { id: "smartboard", label: "Smart Board" },
                      { id: "audio_system", label: "Audio System" },
                      { id: "whiteboard", label: "Whiteboard" },
                      { id: "video_conferencing", label: "Video Conf" },
                      { id: "lab_benches", label: "Lab Benches" },
                    ].map((eq) => (
                      <label key={eq.id} className="flex items-center gap-2 cursor-pointer hover:text-white transition">
                        <input
                          type="checkbox"
                          checked={searchEquipment.includes(eq.id)}
                          onChange={() => handleEquipmentToggle(eq.id)}
                          className="rounded bg-slate-950 border-white/10 text-cyan-400"
                        />
                        <span>{eq.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2 mt-2">
                  <input
                    type="checkbox"
                    id="showPartial"
                    checked={showPartiallyAvailable}
                    onChange={(e) => setShowPartiallyAvailable(e.target.checked)}
                    className="rounded bg-slate-950 border-white/10 text-cyan-400"
                  />
                  <label htmlFor="showPartial" className="text-xs text-slate-300 cursor-pointer">Show partially available rooms (e.g., waitlisted)</label>
                </div>

                <button
                  type="submit"
                  className="w-full rounded-xl bg-cyan-400 py-3 text-sm font-bold text-slate-950 hover:bg-cyan-300 transition shadow-lg shadow-cyan-400/10 cursor-pointer mt-4"
                >
                  Search Available Slots
                </button>
              </form>
            </div>

            {/* Results output */}
            <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-4 flex flex-col min-h-0">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-bold text-white">Eligible Classrooms</h3>
                <button
                  onClick={() => setShowHeatmap(!showHeatmap)}
                  className={`text-xs px-3 py-1.5 rounded-lg border font-bold transition cursor-pointer ${showHeatmap ? "bg-cyan-400 text-slate-950 border-cyan-400" : "bg-transparent text-cyan-400 border-cyan-400/30 hover:bg-cyan-400/10"}`}
                >
                  {showHeatmap ? "Hide Heatmap" : "View Availability Heatmap"}
                </button>
              </div>

              {showHeatmap && heatmapData && (
                <div className="bg-slate-900/60 rounded-2xl p-4 border border-white/5 mb-4 shrink-0">
                  <h4 className="text-sm font-bold text-slate-300 mb-3 text-center">Campus Weekly Heatmap (Next 30 Days)</h4>
                  <div className="grid grid-cols-6 gap-1 text-[9px] text-center font-bold text-slate-400 mb-1">
                    <div>Time</div>
                    <div>Mon</div>
                    <div>Tue</div>
                    <div>Wed</div>
                    <div>Thu</div>
                    <div>Sun</div>
                  </div>
                  <div className="space-y-1">
                    {[8, 9, 10, 11, 12, 13, 14, 15, 16, 17].map(hour => (
                      <div key={hour} className="grid grid-cols-6 gap-1 items-center">
                        <div className="text-[10px] text-slate-500 font-bold text-right pr-2">
                          {hour > 12 ? `${hour-12} PM` : (hour === 12 ? "12 PM" : `${hour} AM`)}
                        </div>
                        {[1, 2, 3, 4, 7].map(day => {
                          const val = heatmapData.heatmap?.find((h:any) => Number(h.day_of_week) === day && Number(h.hour_of_day) === hour)?.booking_count || 0;
                          const ratio = val / (heatmapData.totalRooms || 1);
                          let colorClass = "bg-emerald-500/20";
                          if (ratio > 0.3) colorClass = "bg-emerald-400/40";
                          if (ratio > 0.6) colorClass = "bg-amber-400/50";
                          if (ratio > 0.8) colorClass = "bg-rose-500/60";
                          
                          return (
                            <div 
                              key={`${day}-${hour}`}
                              className={`h-6 rounded-sm ${colorClass} flex items-center justify-center text-[8px] font-bold text-white/70 hover:brightness-125 transition cursor-pointer`}
                              title={`${val} bookings out of ${heatmapData.totalRooms} rooms at this time`}
                            >
                              {val > 0 ? val : ''}
                            </div>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              <p className="text-xs text-slate-400 mt-1 mb-4">Classrooms sorted based on compatibility match score.</p>

              {hasSearched && (() => {
                const filteredRooms = searchResults.filter(room => showPartiallyAvailable || room.isAvailable);
                const topPicks = filteredRooms.filter(r => r.isAvailable).sort((a,b) => (b.matchScore || 0) - (a.matchScore || 0)).slice(0,3);

                return (
                  <div className="space-y-6">
                    {topPicks.length > 0 && (
                      <div className="bg-cyan-500/10 border border-cyan-500/20 rounded-3xl p-6 shadow-xl shadow-cyan-900/10">
                        <h4 className="text-cyan-400 font-bold mb-4 flex items-center gap-2"><span>⭐</span> Quick-Book Recommendations</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {topPicks.map(room => (
                            <div key={`pick-${room.room_id}`} className="bg-slate-900 border border-cyan-500/30 rounded-2xl p-4 flex flex-col justify-between hover:bg-slate-800 transition shadow-lg">
                              <div>
                                <div className="flex justify-between items-center mb-2">
                                  <h5 className="font-bold text-white text-lg">{room.room_number}</h5>
                                  <span className="text-xs font-bold text-emerald-400 px-2 py-1 bg-emerald-500/10 rounded-lg">{room.matchScore}% Match</span>
                                </div>
                                <p className="text-[10px] text-slate-400">{room.building_code} · {room.capacity} seats · {room.room_type}</p>
                              </div>
                              <button
                                onClick={() => setBookingRoom(room)}
                                className="mt-4 w-full bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold py-2 rounded-xl text-xs transition cursor-pointer shadow-lg shadow-cyan-400/20"
                              >
                                ⚡ Book Now
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {filteredRooms.length === 0 ? (
                      <div className="text-center py-16 border border-dashed border-white/10 rounded-3xl">
                        <span className="text-sm text-slate-500 italic">No available classrooms matched your constraints.</span>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <h4 className="text-slate-300 font-bold text-sm">All Matching Rooms</h4>
                        {filteredRooms.map(room => (
                          <div
                            key={room.room_id}
                            className={`rounded-2xl border p-5 transition flex flex-col md:flex-row md:items-center md:justify-between gap-4 ${room.isAvailable
                              ? "border-emerald-500/20 bg-emerald-500/[0.02] hover:bg-emerald-500/[0.04]"
                              : "border-rose-500/15 bg-rose-500/[0.01] opacity-80"
                              }`}
                          >
                            <div className="space-y-1.5 flex-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <h4 className="text-base font-bold text-white">{room.room_number}</h4>
                                <span className="rounded bg-slate-900 border border-white/5 px-2.5 py-0.5 text-[10px] font-semibold text-slate-300">
                                  {room.building_code} · Flr {room.floor}
                                </span>
                                <span className="rounded bg-slate-900 border border-white/5 px-2.5 py-0.5 text-[10px] font-semibold text-slate-300">
                                  {room.capacity} seats
                                </span>
                                <span className="rounded bg-cyan-950 border border-cyan-400/25 px-2.5 py-0.5 text-[10px] font-bold text-cyan-300">
                                  {room.room_type}
                                </span>
                              </div>
                              <p className="text-xs text-slate-400 flex flex-wrap gap-1 items-center">
                                {Object.entries(room.equipment || {})
                                  .filter(([_, v]) => v)
                                  .map(([k]) => (
                                    <span key={k} className="bg-slate-800 text-[9px] px-1.5 py-0.5 rounded text-slate-300">{k.replace("_", " ")}</span>
                                  ))
                                }
                              </p>
                              {room.isAvailable ? (
                                <div className="flex items-center gap-1 text-xs text-emerald-400 font-bold mt-2">
                                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                                  <span>Fully available for slot</span>
                                </div>
                              ) : (
                                <div className="flex items-center gap-1 text-xs text-rose-400 font-bold mt-2">
                                  <span className="h-1.5 w-1.5 rounded-full bg-rose-400 animate-pulse" />
                                  <span>Conflicting reservation: {room.conflictReason}</span>
                                </div>
                              )}
                            </div>

                            <div className="flex items-center gap-4 self-start md:self-center shrink-0">
                              <div className="text-right">
                                <p className="text-[9px] text-slate-400 uppercase tracking-widest font-extrabold">Match</p>
                                <p className={`text-xl font-black ${(room.matchScore || 0) > 75 ? 'text-emerald-400 glow-text-emerald' : (room.matchScore || 0) > 40 ? 'text-cyan-400 glow-text-cyan' : 'text-slate-400'}`}>{room.matchScore || 0}%</p>
                              </div>

                              <button
                                onClick={() => setBookingRoom(room)}
                                className={`rounded-xl px-5 py-3 text-xs font-bold transition cursor-pointer shadow-lg ${room.isAvailable
                                  ? "bg-emerald-400 hover:bg-emerald-300 text-slate-950 shadow-emerald-400/20"
                                  : "bg-amber-400/20 border border-amber-400/35 text-amber-300 hover:bg-amber-400/30"
                                  }`}
                              >
                                {room.isAvailable ? "⚡ Book Now" : "Join Waitlist"}
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })()}

              {!hasSearched && (
                <div className="text-center py-16 border border-dashed border-white/10 rounded-3xl mt-4">
                  <span className="text-sm text-slate-500 italic">Enter parameters in the left panel and click search.</span>
                </div>
              )}
            </div>
          </section>
        )}

        {/* TAB PROFILE: FACULTY SELF-VIEW */}
        {activeTab === "profile" && (user.role === "Faculty" || user.role === "DeptHead") && myProfile && (
          <section className="space-y-6">
            <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 md:p-8 backdrop-blur-xl">
              <div className="flex flex-col md:flex-row gap-8 items-start">
                <div className="flex flex-col gap-4 items-center">
                  <div className="w-32 h-32 rounded-full bg-slate-800 border-4 border-cyan-400 overflow-hidden flex items-center justify-center">
                    {myProfile.profile_photo_url ? (
                      <img src={myProfile.profile_photo_url} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-4xl font-black text-slate-400">{myProfile.full_name_en?.charAt(0)}</span>
                    )}
                  </div>
                  <span className="bg-cyan-400/20 border border-cyan-400/50 text-cyan-300 font-bold px-4 py-1.5 rounded-full text-xs tracking-wider">
                    Rank: {myProfile.seniority_rank}
                  </span>
                </div>
                
                <div className="flex-1 space-y-4 w-full">
                  <div>
                    <h2 className="text-3xl font-extrabold text-white">{myProfile.full_name_en}</h2>
                    <p className="text-sm text-slate-400 mt-1 font-medium">{myProfile.full_name_bn} · {myProfile.designation}</p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm mt-4">
                    <div className="space-y-1 bg-slate-900/50 p-4 rounded-2xl border border-white/5">
                      <p className="text-cyan-500 uppercase text-[10px] font-bold tracking-wider">Employee ID</p>
                      <p className="text-slate-200 font-semibold">{myProfile.employee_id}</p>
                    </div>
                    <div className="space-y-1 bg-slate-900/50 p-4 rounded-2xl border border-white/5">
                      <p className="text-cyan-500 uppercase text-[10px] font-bold tracking-wider">Department</p>
                      <p className="text-slate-200 font-semibold">{myProfile.department || 'N/A'}</p>
                    </div>
                    <div className="space-y-1 bg-slate-900/50 p-4 rounded-2xl border border-white/5">
                      <p className="text-cyan-500 uppercase text-[10px] font-bold tracking-wider">Email Address</p>
                      <p className="text-slate-200 font-semibold">{myProfile.email}</p>
                    </div>
                    <div className="space-y-1 bg-slate-900/50 p-4 rounded-2xl border border-white/5">
                      <p className="text-cyan-500 uppercase text-[10px] font-bold tracking-wider">Phone Number</p>
                      <p className="text-slate-200 font-semibold">{myProfile.phone || 'N/A'}</p>
                    </div>
                  </div>
                  
                  {myProfile.rank_justification && (
                    <div className="mt-4 p-5 rounded-2xl bg-amber-500/5 border border-amber-500/20">
                      <h4 className="text-[10px] font-bold text-amber-500 uppercase tracking-wider mb-1.5 flex items-center gap-2">
                        <span>⚠️</span> Manual Rank Override Active
                      </h4>
                      <p className="text-sm text-amber-200/80 leading-relaxed italic">"{myProfile.rank_justification}"</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Stats row */}
            {myStats && (
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="rounded-3xl border border-white/5 bg-slate-950/45 p-6 flex flex-col justify-between hover:bg-slate-900/50 transition">
                  <h4 className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Total Requests</h4>
                  <p className="text-4xl font-black text-white mt-3">{myStats.total}</p>
                </div>
                <div className="rounded-3xl border border-emerald-500/20 bg-emerald-500/5 p-6 flex flex-col justify-between hover:bg-emerald-500/10 transition">
                  <h4 className="text-[10px] uppercase font-bold text-emerald-500 tracking-wider">Confirmed</h4>
                  <p className="text-4xl font-black text-emerald-400 mt-3">{myStats.confirmed}</p>
                </div>
                <div className="rounded-3xl border border-amber-500/20 bg-amber-500/5 p-6 flex flex-col justify-between hover:bg-amber-500/10 transition">
                  <h4 className="text-[10px] uppercase font-bold text-amber-500 tracking-wider">Waitlisted</h4>
                  <p className="text-4xl font-black text-amber-400 mt-3">{myStats.waitlisted}</p>
                </div>
                <div className="rounded-3xl border border-rose-500/20 bg-rose-500/5 p-6 flex flex-col justify-between hover:bg-rose-500/10 transition">
                  <h4 className="text-[10px] uppercase font-bold text-rose-500 tracking-wider">No-Shows</h4>
                  <p className="text-4xl font-black text-rose-400 mt-3">{myStats.noshows}</p>
                </div>
              </div>
            )}
          </section>
        )}

        {/* TAB 3: FACULTY PORTAL */}
        {activeTab === "dashboard" && (user.role === "Faculty" || user.role === "DeptHead") && (
          <section className="grid gap-6 lg:grid-cols-[1fr_360px]">
            {/* Faculty reservations list */}
            <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-6">
              <div>
                <h3 className="text-lg font-bold text-white">Your Bookings & Requests</h3>
                <p className="text-xs text-slate-400 mt-1">Manage check-in status, draft cancellations, and check allocation logs.</p>
              </div>

              <div className="space-y-3">
                {(!Array.isArray(myBookings) || myBookings.length === 0) && (
                  <div className="text-center py-16 border border-dashed border-white/10 rounded-3xl">
                    <span className="text-sm text-slate-500 italic">No reservation records found. Make a booking request to begin.</span>
                  </div>
                )}

                {Array.isArray(myBookings) && myBookings.map((b) => {
                  const isConfirmed = b.status === "Confirmed";
                  const isWaitlisted = b.status === "Waitlisted";
                  const isPending = b.status === "Pending" || b.status === "PendingAdminApproval";

                  const tagColors = isConfirmed
                    ? "bg-emerald-400/10 text-emerald-300 border-emerald-400/20"
                    : isWaitlisted
                      ? "bg-amber-400/10 text-amber-300 border-amber-400/20"
                      : isPending
                        ? "bg-purple-400/10 text-purple-300 border-purple-400/20"
                        : "bg-slate-800 text-slate-400 border-white/5";

                  return (
                    <div
                      key={b.booking_id}
                      className="rounded-2xl border border-white/5 bg-slate-900/30 p-5 flex flex-col gap-4 hover:border-white/10 transition"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                        <div className="space-y-1.5 flex-1">
                          <div className="flex flex-wrap items-center gap-2.5">
                            <span className={`rounded-full border px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-wider ${tagColors}`}>
                              {b.status}
                            </span>
                            <h4 className="font-bold text-sm text-white">{b.course_code} - {b.course_name}</h4>
                            <span className="text-[10px] text-slate-400 font-medium">({b.booking_type})</span>
                          </div>
                          <p className="text-xs text-slate-300 font-bold">
                            Room {b.room_number} · {new Date(b.start_dt).toLocaleDateString()} at {new Date(b.start_dt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })} - {new Date(b.end_dt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
                          </p>
                          {b.notes && <p className="text-[10px] text-slate-400 italic">Notes: {b.notes}</p>}
                          {b.checkin_at && (
                            <p className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                              ✓ Checked in at {new Date(b.checkin_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
                            </p>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-2 self-end sm:self-center shrink-0">
                          {isConfirmed && (
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleExportBookingPDF(b)}
                                className="rounded-xl border border-cyan-400/30 bg-cyan-400/10 hover:bg-cyan-400/20 px-3 py-2 text-xs font-bold text-cyan-300 transition flex items-center gap-1"
                                title="Download PDF Confirmation Pass"
                              >
                                📄 PDF Confirmation
                              </button>
                              <a
                                href={getGoogleCalendarUrl(b)}
                                target="_blank"
                                rel="noreferrer"
                                className="rounded-xl border border-cyan-400/30 bg-cyan-400/5 hover:bg-cyan-400/20 px-3 py-2 text-xs font-bold text-cyan-300 transition flex items-center gap-1"
                                title="Sync to Google Calendar"
                              >
                                📅 Google
                              </a>
                              <button
                                onClick={() => downloadICSFile(b)}
                                className="rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-3 py-2 text-xs font-bold text-slate-200 transition flex items-center gap-1"
                                title="Download Outlook/Apple iCal file"
                              >
                                📥 .ics
                              </button>
                            </div>
                          )}
                          {isConfirmed && !b.checkin_at && (new Date(b.start_dt).toDateString() === new Date().toDateString()) && (
                            <button
                              onClick={() => handleCheckin(b.booking_id)}
                              className="rounded-xl bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer"
                            >
                              Check In
                            </button>
                          )}
                          {isConfirmed && (new Date(b.start_dt).toDateString() === new Date().toDateString()) && (
                            <button
                              onClick={() => {
                                setSelectedIssueBooking(b);
                                setIssueType("Projector / Display Issue");
                                setIssueDescription("");
                              }}
                              className="rounded-xl border border-amber-400/30 bg-amber-400/5 px-4 py-2 text-xs font-bold text-amber-300 hover:bg-amber-400/20 transition cursor-pointer"
                            >
                              ⚠️ Report Issue
                            </button>
                          )}
                          {isWaitlisted && (
                            <button
                              onClick={() => handleFetchAlternatives(b.booking_id)}
                              className="rounded-xl border border-cyan-400/30 bg-cyan-400/5 hover:bg-cyan-400/20 px-4 py-2 text-xs font-bold text-cyan-300 transition cursor-pointer"
                            >
                              💡 View Alternatives
                            </button>
                          )}
                          {(!["CancelledByFaculty", "CancelledByAdmin", "AutoCancelledNoShow", "Completed"].includes(b.status) && new Date(b.start_dt) > new Date()) && (
                            <button
                              onClick={() => {
                                setEditingBooking(b);
                                setEditNotes(b.notes || "");
                                setEditClassSize(String(b.class_size));
                              }}
                              className="rounded-xl border border-white/10 bg-slate-900 px-4 py-2 text-xs font-bold text-white hover:bg-slate-800 transition cursor-pointer"
                            >
                              ✏️ Edit
                            </button>
                          )}
                          {isConfirmed && new Date(b.end_dt) < new Date() && (
                            <div className="flex gap-1.5">
                              <button
                                onClick={() => handleMarkUtilization(b.booking_id, "Completed")}
                                className="rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/35 px-3 py-1.5 text-[10px] font-bold hover:bg-emerald-500/30 transition cursor-pointer"
                              >
                                ✓ Completed
                              </button>
                              <button
                                onClick={() => handleMarkUtilization(b.booking_id, "AutoCancelledNoShow")}
                                className="rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/35 px-3 py-1.5 text-[10px] font-bold hover:bg-rose-500/30 transition cursor-pointer"
                              >
                                ✗ No-Show
                              </button>
                            </div>
                          )}
                          {!["CancelledByFaculty", "CancelledByAdmin", "AutoCancelledNoShow", "Completed"].includes(b.status) && (
                            <button
                              onClick={() => handleCancelBooking(b.booking_id)}
                              className="rounded-xl border border-rose-500/25 bg-rose-500/10 px-4 py-2 text-xs font-bold text-rose-300 hover:bg-rose-500/20 transition cursor-pointer"
                            >
                              Cancel
                            </button>
                          )}
                        </div>
                      </div>

                      {isWaitlisted && viewingAlternativesBookingId === b.booking_id && (
                        <div className="border-t border-white/5 pt-3 space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-bold text-cyan-300 uppercase tracking-wider">5 Available Alternative Rooms for same slot</span>
                            <button
                              onClick={() => setViewingAlternativesBookingId(null)}
                              className="text-[10px] text-slate-400 hover:text-white"
                            >
                              Hide
                            </button>
                          </div>
                          {alternativesList.length === 0 ? (
                            <p className="text-xs text-slate-500 italic">No alternative classrooms are fully available for this time slot.</p>
                          ) : (
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                              {alternativesList.map((alt) => (
                                <div key={alt.room_id} className="bg-slate-900/60 border border-white/5 rounded-xl p-3 flex items-center justify-between gap-2">
                                  <div>
                                    <p className="font-bold text-white text-xs">{alt.room_number}</p>
                                    <p className="text-[9px] text-slate-400">{alt.building_code} · {alt.capacity} seats</p>
                                  </div>
                                  <button
                                    onClick={() => handleRebook(b.booking_id, alt.room_id)}
                                    className="px-2.5 py-1.5 rounded-lg bg-emerald-400 hover:bg-emerald-300 text-slate-950 text-[10px] font-bold transition cursor-pointer shadow-md shadow-emerald-400/15"
                                  >
                                    ⚡ Rebook
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Course Preference Console — gated by admin preference window */}
              <div className={`rounded-3xl border p-6 backdrop-blur-xl space-y-4 transition-all ${prefWindow.open ? "border-cyan-500/25 bg-cyan-500/[0.03]" : "border-white/10 bg-slate-950/45"}`}>
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <div className={`h-2.5 w-2.5 rounded-full ${prefWindow.open ? "bg-emerald-400 animate-pulse shadow-lg shadow-emerald-400/40" : "bg-rose-500"}`} />
                      <h3 className="text-lg font-bold text-white">Course Preference Console</h3>
                      <span className={`rounded-full px-2.5 py-0.5 text-[9px] font-black uppercase tracking-widest ${prefWindow.open ? "bg-emerald-400/20 text-emerald-300 border border-emerald-400/30" : "bg-rose-500/20 text-rose-300 border border-rose-500/30"}`}>
                        {prefWindow.open ? "OPEN" : "CLOSED"}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      {prefWindow.open
                        ? `Submissions open for ${prefWindow.semester || "current semester"}. Senior faculty choices receive priority allocation.`
                        : "Preference submissions are currently closed. The admin will open this window before the next semester allocation."}
                    </p>
                  </div>
                  <button onClick={fetchPrefWindow} className="rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-3 py-1.5 text-[10px] font-bold text-slate-300 transition cursor-pointer">
                    ↻ Refresh
                  </button>
                </div>

                {/* Window Closed Banner */}
                {!prefWindow.open ? (
                  <div className="rounded-2xl border border-rose-500/20 bg-rose-500/5 p-6 text-center space-y-2">
                    <div className="text-3xl">🔒</div>
                    <p className="font-bold text-rose-300 text-sm">Preference Window is Closed</p>
                    <p className="text-xs text-slate-400">The admin has not yet opened the preference submission window for the upcoming semester.</p>
                    <p className="text-[10px] text-slate-500 mt-2">Your previously submitted preferences are still saved and visible below.</p>
                    {myPreferences.length > 0 && (
                      <div className="mt-4 text-left space-y-2">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Your Last Submitted Choices:</p>
                        {myPreferences.map((pref) => (
                          <div key={pref.preference_id} className="rounded-xl border border-white/5 bg-slate-900/40 p-2.5 flex justify-between items-center text-xs">
                            <div>
                              <p className="font-bold text-white">{pref.course_code} - Sec {pref.section_number}</p>
                              <p className="text-[10px] text-slate-400">{pref.start_time?.substring(0, 5)} – {pref.end_time?.substring(0, 5)}</p>
                            </div>
                            <span className="rounded bg-slate-700 text-slate-300 px-2 py-0.5 text-[9px] font-black uppercase">Rank {pref.choice_rank}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <>
                    {/* Window open — show active info banner */}
                    <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3 space-y-1">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <p className="text-xs font-bold text-emerald-300">✅ Submission window is open for: <span className="text-white">{prefWindow.semester}</span></p>
                        {prefWindow.deadline && (
                          <p className="text-[10px] text-amber-300 font-bold">⏰ Deadline: {new Date(prefWindow.deadline).toLocaleString()}</p>
                        )}
                      </div>
                      {prefWindow.instructions && (
                        <p className="text-[11px] text-slate-300 leading-relaxed">{prefWindow.instructions}</p>
                      )}
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      {/* Left: Available Sections Catalog */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wide flex items-center gap-2">
                            Available Course Sections
                            <span className="rounded bg-white/10 text-slate-400 px-2 py-0.5 text-[9px] font-bold">{allCourseSections.length}</span>
                          </h4>
                        </div>

                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs">🔍</span>
                          <input
                            type="text"
                            placeholder="Search course code or name..."
                            value={preferenceSearchQuery}
                            onChange={(e) => setPreferenceSearchQuery(e.target.value)}
                            className="w-full rounded-xl border border-white/10 bg-slate-900/50 pl-8 pr-3 py-2 text-xs text-slate-200 outline-none focus:ring-1 focus:ring-cyan-500/50 transition-all placeholder:text-slate-500"
                          />
                        </div>

                        <div className="space-y-2 max-h-[320px] overflow-y-auto pr-1 custom-scrollbar">
                          {(() => {
                            const filteredSections = allCourseSections.filter(sec =>
                              (sec.course_code || "").toLowerCase().includes(preferenceSearchQuery.toLowerCase()) ||
                              (sec.course_name || "").toLowerCase().includes(preferenceSearchQuery.toLowerCase())
                            );

                            if (allCourseSections.length === 0) {
                              return (
                                <div className="text-center py-10 border border-dashed border-white/5 rounded-xl">
                                  <p className="text-slate-500 italic text-xs">No course sections available yet.</p>
                                </div>
                              );
                            }

                            if (filteredSections.length === 0) {
                              return (
                                <div className="text-center py-10 border border-dashed border-white/5 rounded-xl">
                                  <p className="text-slate-500 italic text-xs">No matching courses found.</p>
                                </div>
                              );
                            }

                            return filteredSections.map((sec) => {
                              const isChosen = myPreferences.find((p) => p.section_id === sec.section_id);
                              return (
                                <div
                                  key={sec.section_id}
                                  className={`rounded-xl border p-3 flex justify-between items-center text-xs transition ${isChosen ? "border-cyan-400/25 bg-cyan-400/5" : "border-white/5 bg-slate-900/25 hover:border-white/10"}`}
                                >
                                  <div className="min-w-0">
                                    <p className="font-bold text-white">{sec.course_code} <span className="text-slate-400 font-normal">Sec {sec.section_number}</span></p>
                                    <p className="text-[10px] text-slate-400 mt-0.5 truncate">{sec.course_name}</p>
                                    <p className="text-[9px] text-cyan-400 font-mono mt-0.5">
                                      {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][sec.day_of_week?.[0] || 1]} · {sec.start_time?.substring(0, 5)}–{sec.end_time?.substring(0, 5)}
                                    </p>
                                  </div>
                                  <button
                                    onClick={() => handleTogglePreference(sec.section_id)}
                                    className={`ml-3 flex-shrink-0 rounded-lg px-2.5 py-1.5 text-[10px] font-bold transition cursor-pointer ${isChosen
                                      ? "bg-rose-500/20 text-rose-300 border border-rose-500/30 hover:bg-rose-500/30"
                                      : "bg-cyan-400 text-slate-950 hover:bg-cyan-300"
                                      }`}
                                  >
                                    {isChosen ? "✕ Remove" : "+ Add"}
                                  </button>
                                </div>
                              );
                            });
                          })()}
                        </div>
                      </div>

                      {/* Right: My Choice Rankings */}
                      <div className="space-y-3 border-l border-white/5 pl-4">
                        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wide flex items-center gap-2">
                          My Choice Rankings
                          <span className={`rounded px-2 py-0.5 text-[9px] font-bold ${myPreferences.length > 0 ? "bg-cyan-400/20 text-cyan-300" : "bg-white/10 text-slate-400"}`}>{myPreferences.length} selected</span>
                        </h4>
                        <div className="space-y-2 max-h-[320px] overflow-y-auto pr-1 custom-scrollbar">
                          {myPreferences.length === 0 ? (
                            <div className="text-center py-12 border border-dashed border-white/5 rounded-xl">
                              <p className="text-slate-500 italic text-[11px]">No choices added yet.</p>
                              <p className="text-slate-600 text-[10px] mt-1">Add from the catalog on the left.</p>
                            </div>
                          ) : (
                            myPreferences.map((pref) => (
                              <div
                                key={pref.preference_id}
                                className="rounded-xl border border-cyan-400/20 bg-cyan-400/5 p-3 flex justify-between items-center text-xs"
                              >
                                <div className="min-w-0">
                                  <p className="font-bold text-white">{pref.course_code} <span className="text-slate-400 font-normal">Sec {pref.section_number}</span></p>
                                  <p className="text-[10px] text-slate-400 mt-0.5">{pref.start_time?.substring(0, 5)} – {pref.end_time?.substring(0, 5)}</p>
                                </div>
                                <div className="flex items-center gap-2 flex-shrink-0">
                                  <span className="rounded bg-cyan-400 text-slate-950 px-2 py-0.5 text-[9px] font-black uppercase">
                                    #{pref.choice_rank}
                                  </span>
                                  <button
                                    onClick={() => handleTogglePreference(pref.section_id)}
                                    className="rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2 py-0.5 text-[9px] font-bold hover:bg-rose-500/30 transition cursor-pointer"
                                  >
                                    ✕
                                  </button>
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                        {myPreferences.length > 0 && (
                          <p className="text-[10px] text-slate-500 text-center">
                            Choices are saved automatically. Lower rank number = higher priority.
                          </p>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Sidebar Notification Logs & KPI stats */}
            <div className="flex flex-col gap-6">
              {/* Analytics metrics */}
              <div className="rounded-3xl border border-white/10 bg-slate-950/40 p-6 backdrop-blur-xl">
                <h3 className="text-xs font-bold tracking-wider text-cyan-400 uppercase">My Booking Statistics</h3>
                <div className="mt-4 grid grid-cols-2 gap-3 text-center">
                  {[
                    { label: "Active Confirmed", val: myBookings.filter((b) => b.status === "Confirmed").length, color: "text-emerald-400" },
                    { label: "Waitlisted Queue", val: myBookings.filter((b) => b.status === "Waitlisted").length, color: "text-amber-400" },
                    { label: "Cancelled Run", val: myBookings.filter((b) => b.status.startsWith("Cancelled")).length, color: "text-rose-400" },
                    { label: "Auto No Show", val: myBookings.filter((b) => b.status === "AutoCancelledNoShow").length, color: "text-purple-400" },
                  ].map((stat) => (
                    <div key={stat.label} className="rounded-2xl border border-white/5 bg-slate-900/40 p-4">
                      <p className={`text-2xl font-black ${stat.color}`}>{stat.val}</p>
                      <p className="text-[9px] text-slate-400 font-extrabold uppercase mt-1 leading-tight">{stat.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* My Semester Schedule Card */}
              <div className="rounded-3xl border border-white/10 bg-slate-950/40 p-6 backdrop-blur-xl">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-xs font-bold tracking-wider text-cyan-400 uppercase">My Semester Schedule</h3>
                    <p className="text-[10px] text-slate-400 mt-1">Allocated sections from confirmed/draft batches.</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={fetchMySemesterAllocations}
                      disabled={loadingMyAllocations}
                      className="rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-3 py-1.5 text-[10px] font-bold text-slate-300 transition cursor-pointer disabled:opacity-50"
                    >
                      {loadingMyAllocations ? "⏳ Loading..." : "↻ Refresh"}
                    </button>
                    {mySemesterAllocations.length > 0 && (
                      <button
                        onClick={() => {
                          const allocs = mySemesterAllocations;
                          if (!allocs.length) return;
                          const printWindow = window.open("", "_blank");
                          if (!printWindow) { showToast("Pop-up blocked.", "error"); return; }
                          const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                          // Group by semester
                          const bySemester = new Map<string, any[]>();
                          for (const a of allocs) {
                            const sem = a.semester || "Unknown Semester";
                            if (!bySemester.has(sem)) bySemester.set(sem, []);
                            bySemester.get(sem)!.push(a);
                          }
                          let semHtml = "";
                          for (const [sem, items] of bySemester) {
                            const sorted = [...items].sort((a, b) => a.allocated_day_of_week - b.allocated_day_of_week || (a.allocated_start_time || "").localeCompare(b.allocated_start_time || ""));
                            const rows = sorted.map((a: any) => `<tr>
                              <td style="font-family:monospace;font-weight:700;">${formatAllocationDay(a)}</td>
                              <td style="font-family:monospace;">${(a.allocated_start_time || "").substring(0, 5)} – ${(a.allocated_end_time || "").substring(0, 5)}</td>
                              <td style="font-weight:800;">${a.course_code}</td>
                              <td>${a.course_name || ""}</td>
                              <td style="text-align:center;font-family:monospace;">${a.section_number}</td>
                              <td style="font-weight:700;color:#0891b2;">${a.room_number || a.room_number_actual || "—"}</td>
                              <td style="text-align:center;">${a.capacity || "—"}</td>
                              <td style="font-size:10px;color:#555;">${a.batch_status || ""}</td>
                            </tr>`).join("");
                            semHtml += `
                              <div style="margin-bottom:28px;page-break-inside:avoid;">
                                <div style="background:#f1f5f9;border-left:4px solid #0891b2;border-radius:0 8px 8px 0;padding:10px 16px;margin-bottom:10px;display:flex;align-items:center;gap:12px;">
                                  <span style="font-size:13px;font-weight:900;color:#0c0c0c;">${sem}</span>
                                  <span style="font-size:9px;background:#e0f2f1;color:#0891b2;font-weight:700;padding:2px 8px;border-radius:12px;margin-left:auto;">${items.length} section${items.length !== 1 ? "s" : ""}</span>
                                </div>
                                <table style="width:100%;border-collapse:collapse;font-size:11px;">
                                  <thead><tr style="background:#1e293b;">
                                    <th style="color:#fff;padding:8px 10px;text-align:left;font-size:9px;text-transform:uppercase;letter-spacing:0.5px;">Day</th>
                                    <th style="color:#fff;padding:8px 10px;text-align:left;font-size:9px;text-transform:uppercase;letter-spacing:0.5px;">Time</th>
                                    <th style="color:#fff;padding:8px 10px;text-align:left;font-size:9px;text-transform:uppercase;letter-spacing:0.5px;">Course</th>
                                    <th style="color:#fff;padding:8px 10px;text-align:left;font-size:9px;text-transform:uppercase;letter-spacing:0.5px;">Course Name</th>
                                    <th style="color:#fff;padding:8px 10px;text-align:center;font-size:9px;text-transform:uppercase;letter-spacing:0.5px;">Sec</th>
                                    <th style="color:#fff;padding:8px 10px;text-align:left;font-size:9px;text-transform:uppercase;letter-spacing:0.5px;">Room</th>
                                    <th style="color:#fff;padding:8px 10px;text-align:center;font-size:9px;text-transform:uppercase;letter-spacing:0.5px;">Cap</th>
                                    <th style="color:#fff;padding:8px 10px;text-align:left;font-size:9px;text-transform:uppercase;letter-spacing:0.5px;">Status</th>
                                  </tr></thead>
                                  <tbody>${rows}</tbody>
                                </table>
                              </div>`;
                          }
                          const faculty = allocs[0];
                          printWindow.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8">
                            <title>My Teaching Schedule — ${faculty.allocated_faculty_name || user?.name}</title>
                            <style>
                              * { box-sizing:border-box; margin:0; padding:0; }
                              body { font-family:'Segoe UI',Tahoma,sans-serif; color:#1a1a1a; padding:32px 40px; }
                              tr:nth-child(even) td { background:#fafafa; }
                              td { padding:8px 10px; border-bottom:1px solid #f0f0f0; vertical-align:top; }
                              .footer { margin-top:36px; text-align:right; font-size:10px; color:#999; border-top:1px solid #e5e7eb; padding-top:14px; }
                              @media print { body { padding:16px 24px; } }
                            </style></head><body>
                            <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #0891b2;padding-bottom:18px;margin-bottom:24px;">
                              <div>
                                <h1 style="font-size:22px;font-weight:900;">📋 ${faculty.allocated_faculty_name || user?.name}</h1>
                                <p style="font-size:12px;color:#555;margin-top:4px;">${faculty.allocated_faculty_designation || "Faculty"} — My Teaching Schedule</p>
                              </div>
                              <div style="text-align:right;">
                                <div style="background:#0891b2;color:#fff;font-weight:800;font-size:11px;padding:4px 14px;border-radius:20px;margin-bottom:4px;display:inline-block;">OFFICIAL SCHEDULE</div>
                                <div style="font-size:11px;color:#555;">Generated: ${new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}</div>
                              </div>
                            </div>
                            ${semHtml}
                            <div class="footer">Official Faculty Teaching Schedule — CBS Automated Timetable System</div>
                            <script>window.onload=function(){window.print()};</script>
                          </body></html>`);
                          printWindow.document.close();
                        }}
                        className="rounded-xl border border-cyan-500/35 bg-cyan-500/5 hover:bg-cyan-500/15 px-3 py-1.5 text-[10px] font-bold text-cyan-300 transition cursor-pointer flex items-center gap-1"
                      >
                        📄 Export PDF
                      </button>
                    )}
                  </div>
                </div>

                {loadingMyAllocations ? (
                  <div className="text-center py-8">
                    <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-cyan-400 border-t-transparent" />
                    <p className="text-xs text-slate-500 mt-2">Loading your schedule…</p>
                  </div>
                ) : mySemesterAllocations.length === 0 ? (
                  <div className="text-center py-8 border border-dashed border-white/5 rounded-2xl">
                    <p className="text-xs text-slate-500 italic">No confirmed semester allocations found.</p>
                    <p className="text-[10px] text-slate-600 mt-1">Allocations will appear here once an admin runs and confirms a semester batch.</p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1 custom-scrollbar">
                    {(() => {
                      const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
                      // Group by semester
                      const grouped = new Map<string, any[]>();
                      for (const a of mySemesterAllocations) {
                        const sem = a.semester || "Unknown";
                        if (!grouped.has(sem)) grouped.set(sem, []);
                        grouped.get(sem)!.push(a);
                      }
                      return [...grouped.entries()].map(([sem, items]) => (
                        <div key={sem}>
                          <p className="text-[9px] font-black uppercase tracking-widest text-slate-500 px-1 mb-1.5">{sem}</p>
                          {items.map((a: any) => (
                            <div key={a.allocation_id} className="rounded-xl border border-white/5 bg-slate-900/30 px-3.5 py-2.5 mb-1.5 flex items-center justify-between gap-3 hover:border-white/10 transition">
                              <div className="min-w-0">
                                <div className="flex items-center gap-2">
                                  <span className="font-black text-white text-xs">{a.course_code}</span>
                                  <span className="text-[9px] text-slate-500 font-mono">Sec {a.section_number}</span>
                                  <span className={`text-[8px] px-1.5 py-0.5 rounded font-bold uppercase ${a.batch_status === "Confirmed" ? "bg-emerald-500/20 text-emerald-300" : "bg-amber-500/20 text-amber-300"}`}>
                                    {a.batch_status}
                                  </span>
                                </div>
                                <p className="text-[10px] text-slate-400 truncate mt-0.5">{a.course_name}</p>
                                <p className="text-[9px] font-mono text-cyan-300 mt-0.5">
                                  {formatAllocationDay(a)} · {(a.allocated_start_time || "").substring(0, 5)}–{(a.allocated_end_time || "").substring(0, 5)} · <span className="font-bold">{a.room_number || a.room_number_actual || "?"}</span>
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      ));
                    })()}
                  </div>
                )}
              </div>

              {/* Notification logs */}
              <div className="rounded-3xl border border-white/10 bg-slate-950/40 p-6 backdrop-blur-xl flex-1 flex flex-col">
                <h3 className="text-xs font-bold tracking-wider text-cyan-400 uppercase">Notification logs</h3>
                <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">Simulated institutional email alerts and confirmations.</p>

                <div className="mt-4 flex-1 overflow-y-auto max-h-[350px] space-y-2 pr-1">
                  {myNotifications.length === 0 && (
                    <div className="text-center py-10">
                      <span className="text-xs text-slate-500 italic">No notifications generated yet.</span>
                    </div>
                  )}
                  {myNotifications.map((n) => (
                    <div key={n.notif_id} className="rounded-xl border border-white/5 bg-slate-900/20 p-4 leading-relaxed hover:border-white/10 transition">
                      <div className="flex justify-between items-center">
                        <span className="text-[8px] uppercase font-black text-cyan-400 bg-cyan-400/5 px-2 py-0.5 rounded border border-cyan-400/10">
                          {n.type}
                        </span>
                        <span className="text-[9px] text-slate-500 font-semibold">
                          {new Date(n.sent_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
                        </span>
                      </div>
                      <p className="text-xs font-bold text-white mt-2">{n.subject}</p>
                      <p className="text-[10px] text-slate-300 mt-1 leading-relaxed">{n.body}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {/* TAB 4: DEPT CONSOLE */}
        {activeTab === "dept" && (user.role === "DeptHead" || user.role === "Admin") && (
          <section className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white">Department Booking console</h3>
              <p className="text-xs text-slate-400 mt-1">Review department bookings and approve priority overrides.</p>
            </div>

            {/* Department Mandatory Course Assignments */}
            <div className="space-y-4 p-6 rounded-2xl bg-gradient-to-br from-indigo-900/40 to-slate-900/60 border border-indigo-500/30 shadow-lg shadow-indigo-500/10 mb-8">
              <div>
                <h4 className="text-xs font-bold tracking-wider text-cyan-400 uppercase flex items-center gap-1.5 mb-1">
                  🏫 Mandatory Course Allocations & Faculty Mandates
                </h4>
                <p className="text-[11px] text-slate-400">Assign specific faculty members (especially Lecturers / younger staff) to course sections. The allocation engine will prioritize these mandates over junior faculty preference choices.</p>
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-2 mb-4">
                <div className="relative flex-1">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <span className="text-slate-400">🔍</span>
                  </div>
                  <input
                    type="text"
                    value={mandateSearchQuery}
                    onChange={(e) => setMandateSearchQuery(e.target.value)}
                    placeholder="Search by course code or name (e.g. CSE101)..."
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-white/10 bg-slate-900/50 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition"
                  />
                </div>
                <div className="flex bg-slate-900/50 rounded-xl p-1 border border-white/10">
                  {(["all", "assigned", "unassigned"] as const).map((mode) => (
                    <button
                      key={mode}
                      onClick={() => setMandateFilterMode(mode)}
                      className={`px-3 py-1.5 text-[10px] font-bold rounded-lg transition-colors capitalize ${
                        mandateFilterMode === mode
                          ? "bg-cyan-500/20 text-cyan-300"
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4 max-h-[450px] overflow-y-auto pr-2 custom-scrollbar">
                {(() => {
                  let filtered = Array.isArray(allCourseSections) ? allCourseSections : [];
                  if (mandateSearchQuery.trim()) {
                    const q = mandateSearchQuery.toLowerCase();
                    filtered = filtered.filter(s => 
                      s.course_code.toLowerCase().includes(q) || 
                      s.course_name.toLowerCase().includes(q)
                    );
                  }
                  if (mandateFilterMode === "assigned") {
                    filtered = filtered.filter(s => s.assigned_faculty_id !== null);
                  } else if (mandateFilterMode === "unassigned") {
                    filtered = filtered.filter(s => s.assigned_faculty_id === null);
                  }

                  if (filtered.length === 0) {
                    return (
                      <div className="text-center py-12 border border-dashed border-white/10 rounded-2xl">
                        <p className="text-sm text-slate-500 italic">No sections found matching your criteria.</p>
                      </div>
                    );
                  }

                  // Group by course code
                  const grouped = new Map<string, any[]>();
                  for (const sec of filtered) {
                    if (!grouped.has(sec.course_code)) grouped.set(sec.course_code, []);
                    grouped.get(sec.course_code)!.push(sec);
                  }

                  return [...grouped.entries()].map(([courseCode, sections]) => (
                    <div key={courseCode} className="rounded-2xl border border-white/5 bg-slate-900/20 overflow-hidden">
                      <div className="bg-slate-900/50 px-4 py-3 border-b border-white/5 flex items-center justify-between">
                        <div>
                          <h4 className="font-extrabold text-white text-sm">{courseCode}</h4>
                          <p className="text-[10px] text-slate-400 mt-0.5">{sections[0].course_name}</p>
                        </div>
                        <span className="px-2 py-1 bg-white/5 rounded text-[9px] font-bold text-slate-400">
                          {sections.length} Section{sections.length !== 1 ? 's' : ''}
                        </span>
                      </div>
                      <div className="p-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                        {sections.map((sec) => {
                          const isAssigned = !!sec.assigned_faculty_id;
                          return (
                            <div
                              key={sec.section_id}
                              className={`rounded-xl border p-3 flex flex-col justify-between gap-3 transition-colors ${
                                isAssigned 
                                  ? "border-emerald-500/20 bg-emerald-500/[0.02]" 
                                  : "border-white/5 bg-slate-900/40 hover:border-white/10"
                              }`}
                            >
                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <h5 className="font-bold text-xs text-slate-200">Section {sec.section_number}</h5>
                                  {isAssigned && (
                                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 pulse-dot shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                                  )}
                                </div>
                                <p className="text-[9px] text-slate-500 font-mono">
                                  {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][sec.day_of_week?.[0] || 1]} {sec.start_time?.substring(0, 5)} - {sec.end_time?.substring(0, 5)}
                                </p>
                                {sec.room_number && (
                                  <p className="text-[9px] text-cyan-500/80 font-mono mt-0.5">
                                    Room: {sec.room_number}
                                  </p>
                                )}
                              </div>

                              <div className="space-y-1">
                                <select
                                  value={sec.assigned_faculty_id || ""}
                                  onChange={(e) => handleAssignFaculty(sec.section_id, e.target.value || null)}
                                  className={`w-full rounded-lg border px-2 py-1.5 text-[10px] font-medium outline-none transition-colors ${
                                    isAssigned
                                      ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
                                      : "border-white/10 bg-slate-950 text-slate-300 focus:border-cyan-500/50"
                                  }`}
                                >
                                  <option value="">-- Unassigned --</option>
                                  {faculties.filter(f => {
                                    if (!sec.day_of_week || !sec.start_time || !sec.end_time) return true;
                                    for (const otherSec of allCourseSections) {
                                      if (otherSec.section_id === sec.section_id) continue;
                                      if (otherSec.assigned_faculty_id !== f.faculty_id) continue;
                                      if (!otherSec.day_of_week || !otherSec.start_time || !otherSec.end_time) continue;
                                      const daysOverlap = otherSec.day_of_week.some((d: number) => sec.day_of_week.includes(d));
                                      if (daysOverlap && otherSec.start_time < sec.end_time && otherSec.end_time > sec.start_time) {
                                        return false;
                                      }
                                    }
                                    return true;
                                  }).map((f) => (
                                    <option key={f.faculty_id} value={f.faculty_id}>
                                      {f.full_name_en} ({f.designation})
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ));
                })()}
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-xs font-bold tracking-wider text-cyan-400 uppercase border-b border-white/10 pb-2 flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-cyan-400 pulse-dot" />
                Waitlisted Department Requests
              </h4>

              <div className="grid gap-4 sm:grid-cols-2">
                {(!Array.isArray(deptBookings) || deptBookings.filter((b) => b.status === "Waitlisted").length === 0) && (
                  <div className="col-span-2 text-center py-12 border border-dashed border-white/10 rounded-3xl">
                    <span className="text-sm text-slate-500 italic">No waitlisted requests currently in your department catalog.</span>
                  </div>
                )}

                {Array.isArray(deptBookings) && deptBookings
                  .filter((b) => b.status === "Waitlisted")
                  .map((b) => (
                    <div
                      key={b.booking_id}
                      className="rounded-2xl border border-white/5 bg-slate-900/35 p-5 flex flex-col justify-between gap-4 hover:border-white/10 transition"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2">
                          <span className="rounded bg-amber-400/10 text-amber-300 border border-amber-400/25 px-2 py-0.5 text-[9px] font-bold uppercase">
                            Waitlisted
                          </span>
                          <h4 className="font-bold text-sm text-white">{b.course_code} - {b.course_name}</h4>
                        </div>
                        <p className="text-xs text-slate-200">
                          Room {b.room_number} · {new Date(b.start_dt).toLocaleDateString()} at {formatTimeRange(b.start_dt, b.end_dt)}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          👤 Faculty: {b.faculty_name} ({b.faculty_designation})
                        </p>
                      </div>

                      <button
                        onClick={() => handleOverride(b.booking_id)}
                        className="rounded-xl bg-amber-400 px-4 py-2.5 text-xs font-bold text-slate-950 hover:bg-amber-300 transition cursor-pointer self-start"
                      >
                        Override Waitlist
                      </button>
                    </div>
                  ))}
              </div>
            </div>

            {/* Department Timetable logs */}
            <div className="space-y-4 pt-4">
              <h4 className="text-xs font-bold tracking-wider text-cyan-400 uppercase border-b border-white/10 pb-2">
                All Department Timetable reservations
              </h4>
              <div className="overflow-x-auto border border-white/5 rounded-2xl">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-white/10 bg-slate-950/60 text-slate-400 font-bold uppercase tracking-wider text-[9px]">
                      <th className="py-3 px-4">Request ID</th>
                      <th className="py-3 px-4">Course</th>
                      <th className="py-3 px-4">Room</th>
                      <th className="py-3 px-4">Faculty Member</th>
                      <th className="py-3 px-4">Schedule Time</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-300">
                    {Array.isArray(deptBookings) && deptBookings.map((b) => (
                      <tr key={b.booking_id} className="hover:bg-white/[0.01] transition-colors">
                        <td className="py-4 px-4 font-mono text-cyan-400">{b.booking_request_id}</td>
                        <td className="py-4 px-4">
                          <p className="font-bold text-white">{b.course_code}</p>
                          <p className="text-[10px] text-slate-400 truncate max-w-[150px]">{b.course_name}</p>
                        </td>
                        <td className="py-4 px-4 font-bold text-slate-200">{b.room_number}</td>
                        <td className="py-4 px-4">
                          <p className="font-semibold text-slate-200">{b.faculty_name}</p>
                          <p className="text-[10px] text-slate-400">{b.faculty_designation}</p>
                        </td>
                        <td className="py-4 px-4 font-mono text-[11px] leading-relaxed">
                          {new Date(b.start_dt).toLocaleDateString()}
                          <br />
                          {formatTimeRange(b.start_dt, b.end_dt)}
                        </td>
                        <td className="py-4 px-4">
                          <span
                            className={`rounded px-2.5 py-0.5 text-[9px] font-bold border ${b.status === "Confirmed"
                              ? "bg-emerald-400/10 text-emerald-300 border-emerald-400/20"
                              : b.status === "Waitlisted"
                                ? "bg-amber-400/10 text-amber-300 border-amber-400/20"
                                : "bg-slate-800 text-slate-400 border-white/5"
                              }`}
                          >
                            {b.status}
                          </span>
                        </td>
                        <td className="py-4 px-4 text-right">
                          {!["CancelledByFaculty", "CancelledByAdmin", "AutoCancelledNoShow"].includes(b.status) && (
                            <button
                              onClick={() => handleCancelBooking(b.booking_id)}
                              className="text-rose-400 hover:text-rose-300 transition text-xs font-bold cursor-pointer"
                            >
                              Cancel Booking
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            
          </section>
        )}

        {/* TAB 5: ADMIN CONSOLE */}
        {activeTab === "admin" && user.role === "Admin" && (
          <div className="space-y-6">
            {/* Sub-tabs header */}
            <div className="flex border-b border-white/10 pb-1 gap-6">
              <button
                onClick={() => setAdminSubTab("dashboard")}
                className={`pb-3 text-sm font-bold transition cursor-pointer relative ${adminSubTab === "dashboard" ? "text-cyan-400 font-extrabold" : "text-slate-400 hover:text-white"
                  }`}
              >
                📊 Dashboard & Reports
                {adminSubTab === "dashboard" && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400" />}
              </button>
              <button
                onClick={() => setAdminSubTab("inventory")}
                className={`pb-3 text-sm font-bold transition cursor-pointer relative ${adminSubTab === "inventory" ? "text-cyan-400 font-extrabold" : "text-slate-400 hover:text-white"
                  }`}
              >
                🏫 Classroom Inventory Filter
                {adminSubTab === "inventory" && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400" />}
              </button>
              <button
                onClick={() => setAdminSubTab("faculty")}
                className={`pb-3 text-sm font-bold transition cursor-pointer relative ${adminSubTab === "faculty" ? "text-cyan-400 font-extrabold" : "text-slate-400 hover:text-white"}`}
              >
                Faculty Profiles
                {adminSubTab === "faculty" && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400" />}
              </button>

            </div>

            {adminSubTab === "dashboard" ? (
              <section className="grid gap-6 xl:grid-cols-[1fr_400px]">
                {/* Left Column: Configs & Reports */}
                <div className="flex flex-col gap-6">

                  {/* Analytics Dashboard */}
                  {adminAnalytics && (
                    <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-6">
                      <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase border-b border-white/10 pb-3">Platform Analytics</h3>
                      
                      <div className="grid grid-cols-2 gap-6">
                        {/* Bookings by Building (Bar Chart) */}
                        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/5 h-64">
                          <h4 className="text-xs font-bold text-slate-300 mb-4 text-center">Bookings per Building</h4>
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={adminAnalytics.buildingVolume}>
                              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                              <XAxis dataKey="building_code" stroke="#94a3b8" fontSize={10} />
                              <YAxis stroke="#94a3b8" fontSize={10} />
                              <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '8px' }} />
                              <Bar dataKey="total_bookings" fill="#22d3ee" radius={[4, 4, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>

                        {/* Recent Bookings Trend (Area Chart) */}
                        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/5 h-64">
                          <h4 className="text-xs font-bold text-slate-300 mb-4 text-center">Booking Activity (7 Days)</h4>
                          <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={adminAnalytics.bookingTrends}>
                              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                              <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} tickFormatter={(val) => val.split('-').slice(1).join('/')} />
                              <YAxis stroke="#94a3b8" fontSize={10} />
                              <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '8px' }} />
                              <Area type="monotone" dataKey="count" stroke="#818cf8" fill="#818cf8" fillOpacity={0.2} />
                            </AreaChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Configurations */}
                  <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-4">
                    <div className="flex items-center justify-between border-b border-white/10 pb-3">
                      <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase">System Configurations</h3>
                      <button
                        onClick={handleTriggerJobs}
                        className="rounded-xl bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer"
                      >
                        ⚡ Force Background Jobs
                      </button>
                    </div>
                    <form onSubmit={handleUpdateConfig} className="space-y-4">
                      <div className="grid gap-4 sm:grid-cols-3">
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Global Booking Window (Days)</label>
                          <input
                            type="number"
                            value={editConfigWindow}
                            onChange={(e) => setEditConfigWindow(e.target.value)}
                            className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-sm text-slate-200 outline-none"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">No-Show Grace (Mins)</label>
                          <input
                            type="number"
                            value={editConfigGrace}
                            onChange={(e) => setEditConfigGrace(e.target.value)}
                            className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-sm text-slate-200 outline-none"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Max Recurring (Weeks)</label>
                          <input
                            type="number"
                            value={editConfigMaxWeeks}
                            onChange={(e) => setEditConfigMaxWeeks(e.target.value)}
                            className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-sm text-slate-200 outline-none"
                          />
                        </div>
                      </div>

                      <div className="border-t border-white/5 pt-3 space-y-3">
                        <span className="text-[10px] font-bold text-cyan-300 uppercase block tracking-wider">Per Room-Type Booking Windows (Days)</span>
                        <div className="grid gap-4 sm:grid-cols-4">
                          <div>
                            <label className="text-[9px] font-bold text-slate-400 block mb-1">Exam Hall</label>
                            <input
                              type="number"
                              value={editConfigWindowExamHall}
                              onChange={(e) => setEditConfigWindowExamHall(e.target.value)}
                              className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] font-bold text-slate-400 block mb-1">Lecture Hall</label>
                            <input
                              type="number"
                              value={editConfigWindowLectureHall}
                              onChange={(e) => setEditConfigWindowLectureHall(e.target.value)}
                              className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] font-bold text-slate-400 block mb-1">Seminar Room</label>
                            <input
                              type="number"
                              value={editConfigWindowSeminarRoom}
                              onChange={(e) => setEditConfigWindowSeminarRoom(e.target.value)}
                              className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] font-bold text-slate-400 block mb-1">Computer Lab</label>
                            <input
                              type="number"
                              value={editConfigWindowComputerLab}
                              onChange={(e) => setEditConfigWindowComputerLab(e.target.value)}
                              className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-white/5 pt-3 space-y-3">
                        <span className="text-[10px] font-bold text-cyan-300 uppercase block tracking-wider">Per Room-Type Max Booking Durations (Hours)</span>
                        <div className="grid gap-4 sm:grid-cols-4">
                          <div>
                            <label className="text-[9px] font-bold text-slate-400 block mb-1">Exam Hall</label>
                            <input
                              type="number"
                              step="0.5"
                              value={editConfigDurationExamHall}
                              onChange={(e) => setEditConfigDurationExamHall(e.target.value)}
                              className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] font-bold text-slate-400 block mb-1">Lecture Hall</label>
                            <input
                              type="number"
                              step="0.5"
                              value={editConfigDurationLectureHall}
                              onChange={(e) => setEditConfigDurationLectureHall(e.target.value)}
                              className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] font-bold text-slate-400 block mb-1">Seminar Room</label>
                            <input
                              type="number"
                              step="0.5"
                              value={editConfigDurationSeminarRoom}
                              onChange={(e) => setEditConfigDurationSeminarRoom(e.target.value)}
                              className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] font-bold text-slate-400 block mb-1">Computer Lab</label>
                            <input
                              type="number"
                              step="0.5"
                              value={editConfigDurationComputerLab}
                              onChange={(e) => setEditConfigDurationComputerLab(e.target.value)}
                              className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-xs text-slate-200 outline-none"
                            />
                          </div>
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full rounded-xl bg-cyan-400 py-3 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer"
                      >
                        Update Configurations
                      </button>
                    </form>
                  </div>

                  {/* ─── Preference Collection Window ─── */}
                  <div className={`rounded-3xl border p-6 backdrop-blur-xl space-y-4 transition-all ${prefWindow.open ? "border-emerald-500/40 bg-emerald-500/5" : "border-white/10 bg-slate-950/45"}`}>
                    <div className="flex items-center justify-between border-b border-white/10 pb-3">
                      <div className="flex items-center gap-3">
                        <div className={`h-3 w-3 rounded-full shadow-lg ${prefWindow.open ? "bg-emerald-400 shadow-emerald-400/50 animate-pulse" : "bg-slate-600"}`} />
                        <div>
                          <h3 className="text-sm font-bold tracking-wider text-white uppercase">Faculty Preference Collection Window</h3>
                          <p className="text-[10px] text-slate-400 mt-0.5">Controls whether faculty can submit course section choices. Shown live on their dashboard.</p>
                        </div>
                      </div>
                      <span className={`rounded-full px-3 py-1 text-[10px] font-black uppercase tracking-widest ${prefWindow.open ? "bg-emerald-400/20 text-emerald-300 border border-emerald-400/30" : "bg-slate-700/60 text-slate-400 border border-white/10"}`}>
                        {prefWindow.open ? "🟢 OPEN" : "🔴 CLOSED"}
                      </span>
                    </div>

                    {prefWindow.open && prefWindow.toggled_at && (
                      <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-2.5 text-xs text-emerald-300 flex items-center gap-2">
                        <span>✅ Window opened</span>
                        {prefWindow.semester && <span className="font-bold">· Semester: {prefWindow.semester}</span>}
                        {prefWindow.deadline && <span>· Deadline: {new Date(prefWindow.deadline).toLocaleString()}</span>}
                      </div>
                    )}

                    <div className="grid gap-3 sm:grid-cols-2">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Target Semester</label>
                        <input
                          type="text"
                          placeholder="e.g. Spring 2026"
                          value={prefWindowSemester}
                          onChange={(e) => setPrefWindowSemester(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-sm text-slate-200 outline-none focus:border-cyan-500/50 transition"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Submission Deadline</label>
                        <input
                          type="datetime-local"
                          value={prefWindowDeadline}
                          onChange={(e) => setPrefWindowDeadline(e.target.value)}
                          onClick={(e) => e.currentTarget.showPicker?.()}
                          className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-sm text-slate-200 outline-none focus:border-cyan-500/50 transition cursor-pointer"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Instructions for Faculty (optional)</label>
                        <textarea
                          rows={2}
                          placeholder="e.g. Please submit your top 3 course preferences. Senior faculty choices will be prioritised."
                          value={prefWindowInstructions}
                          onChange={(e) => setPrefWindowInstructions(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5 text-sm text-slate-200 outline-none resize-none focus:border-cyan-500/50 transition"
                        />
                      </div>
                    </div>

                    <div className="flex gap-3 pt-1">
                      {!prefWindow.open ? (
                        <button
                          onClick={() => handleTogglePrefWindow(true)}
                          disabled={savingPrefWindow || !prefWindowSemester.trim()}
                          className="rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 disabled:cursor-not-allowed px-6 py-2.5 text-xs font-black text-white transition cursor-pointer shadow-lg shadow-emerald-500/20 flex items-center gap-2"
                        >
                          {savingPrefWindow ? "⏳ Saving..." : "🟢 Open Preference Window"}
                        </button>
                      ) : (
                        <button
                          onClick={() => handleTogglePrefWindow(false)}
                          disabled={savingPrefWindow}
                          className="rounded-xl bg-rose-500 hover:bg-rose-400 disabled:opacity-50 disabled:cursor-not-allowed px-6 py-2.5 text-xs font-black text-white transition cursor-pointer shadow-lg shadow-rose-500/20 flex items-center gap-2"
                        >
                          {savingPrefWindow ? "⏳ Saving..." : "🔒 Close Preference Window"}
                        </button>
                      )}
                      <button
                        onClick={() => handleTogglePrefWindow(prefWindow.open)}
                        disabled={savingPrefWindow}
                        className="rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-4 py-2.5 text-xs font-bold text-slate-300 transition cursor-pointer"
                      >
                        ↻ Update Settings
                      </button>
                      {!prefWindowSemester.trim() && !prefWindow.open && (
                        <span className="text-[10px] text-amber-400 self-center">⚠ Enter a semester name to open the window</span>
                      )}
                    </div>
                  </div>

                  {/* Pending approvals queue */}
                  <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-4">
                    <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase border-b border-white/10 pb-2">
                      Pending Admin Approvals Queue ({pendingApprovals.length})
                    </h3>
                    <div className="space-y-3">
                      {pendingApprovals.length === 0 ? (
                        <div className="text-center py-6 border border-dashed border-white/5 rounded-2xl">
                          <p className="text-slate-500 italic text-xs">No pending requests require admin approval.</p>
                        </div>
                      ) : (
                        pendingApprovals.map((b) => (
                          <div
                            key={b.booking_id}
                            className="rounded-2xl border border-white/5 bg-slate-900/35 p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 hover:border-white/10 transition"
                          >
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="rounded bg-purple-400/10 text-purple-300 border border-purple-400/25 px-2 py-0.5 text-[9px] font-bold uppercase">
                                  Pending Approval
                                </span>
                                <h4 className="font-bold text-xs text-white">{b.course_code} - {b.course_name}</h4>
                              </div>
                              <p className="text-[11px] text-slate-300">
                                Room {b.room_number} · {new Date(b.start_dt).toLocaleDateString()} at {formatTimeRange(b.start_dt, b.end_dt)}
                              </p>
                              <p className="text-[10px] text-slate-400">
                                👤 Requested by: {b.full_name_en} ({b.designation})
                              </p>
                            </div>

                            <button
                              onClick={() => handleApproveBooking(b.booking_id)}
                              className="rounded-xl bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer"
                            >
                              Approve Request
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Active Classroom Alerts */}
                  <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-4">
                    <h3 className="text-sm font-bold tracking-wider text-rose-400 uppercase border-b border-white/10 pb-2">
                      ⚠️ Active Classroom Alerts & Issues ({reportedIssues.length})
                    </h3>
                    <div className="space-y-3 max-h-[350px] overflow-y-auto custom-scrollbar">
                      {reportedIssues.length === 0 ? (
                        <div className="text-center py-6 border border-dashed border-white/5 rounded-2xl">
                          <p className="text-slate-500 italic text-xs">No active room issues reported today.</p>
                        </div>
                      ) : (
                        reportedIssues.map((issue) => (
                          <div
                            key={issue.notification_id}
                            className="rounded-2xl border border-rose-500/20 bg-rose-500/5 p-4 space-y-2 hover:border-rose-500/30 transition"
                          >
                            <div className="flex items-center justify-between">
                              <h4 className="font-extrabold text-xs text-rose-300">{issue.subject}</h4>
                              <span className="text-[9px] text-slate-400">
                                {new Date(issue.sent_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
                              </span>
                            </div>
                            <p className="text-xs text-slate-200 leading-relaxed">{issue.body}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Occupancy reports */}
                  <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-6">
                    <div>
                      <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase border-b border-white/10 pb-2">
                        Occupancy & Booking Reports
                      </h3>
                    </div>

                    <div className="space-y-3">
                      <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wide">Room Utilization Breakdown</h4>
                      <div className="grid gap-4 sm:grid-cols-3">
                        {(Array.isArray(utilizationReport) ? utilizationReport : []).map((row) => (
                          <div key={row.roomId} className="rounded-2xl border border-white/5 bg-slate-900/35 p-4 text-center leading-relaxed">
                            <p className="text-base font-extrabold text-white">{row.roomNumber}</p>
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">{row.roomType}</p>
                            <p className="text-2xl font-black text-cyan-400 glow-text-cyan mt-2">{row.utilizationRate}%</p>
                            <p className="text-[9px] text-slate-500 mt-1">Booked: {row.bookedHours}h / Total: {row.availableHours}h</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid gap-6 sm:grid-cols-2 pt-2">
                      <div className="space-y-3">
                        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wide">No-Show metrics</h4>
                        <div className="divide-y divide-white/5 border border-white/5 rounded-2xl bg-slate-900/20 px-4">
                          {noShowReport.slice(0, 3).map((f) => (
                            <div key={f.faculty_id} className="py-3 flex items-center justify-between text-xs">
                              <div>
                                <p className="font-bold text-white">{f.full_name_en}</p>
                                <p className="text-[9px] text-slate-400 mt-0.5">{f.designation}</p>
                              </div>
                              <div className="text-right">
                                <p className="font-mono font-bold text-rose-400">{Math.round(f.noshow_rate)}% rate</p>
                                <p className="text-[9px] text-slate-500 mt-0.5">{f.noshow_bookings} no-shows</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-3">
                        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wide">Priority Conflict metrics</h4>
                        <div className="rounded-2xl border border-white/5 bg-slate-900/20 p-4 space-y-3 text-xs leading-relaxed">
                          <div className="flex justify-between">
                            <span className="text-slate-400 font-medium">Total Reservations</span>
                            <span className="font-bold text-white">{conflictReport?.totalRequests || 0}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400 font-medium">Waitlisted Requests</span>
                            <span className="font-bold text-amber-400">{conflictReport?.waitlistedRequests || 0}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400 font-medium">Auto waitlist promotions</span>
                            <span className="font-bold text-emerald-400">{conflictReport?.autoPromotions || 0}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400 font-medium">Dept Overrides</span>
                            <span className="font-bold text-cyan-400">{conflictReport?.manualOverrides || 0}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Audit trail */}
                  <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-3">
                    <h3 className="text-xs font-bold tracking-wider text-cyan-400 uppercase border-b border-white/10 pb-2">
                      System Audit Logs
                    </h3>
                    <div className="overflow-y-auto max-h-[300px] space-y-2 pr-1">
                      {auditLogs.map((log) => (
                        <div key={log.log_id} className="rounded-xl border border-white/5 bg-slate-900/20 p-4 leading-relaxed text-xs">
                          <div className="flex justify-between text-[10px] text-slate-400 font-extrabold uppercase">
                            <span>{log.action}</span>
                            <span>{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}</span>
                          </div>
                          <p className="mt-2 text-slate-200">
                            {log.user_role} {log.faculty_name && `(${log.faculty_name})`} modified {log.entity_type}
                          </p>
                          {log.field_changed && (
                            <p className="text-[10px] text-slate-400 mt-2 bg-black/40 p-2 rounded-lg border border-white/5 font-mono leading-relaxed">
                              Field: {log.field_changed} | {JSON.stringify(log.old_value)} → {JSON.stringify(log.new_value)}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right Column: Maintenance & Bulk Emergency Controls */}
                <div className="flex flex-col gap-6">
                  {/* Maintenance scheduling */}
                  <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl">
                    <h3 className="text-xs font-bold tracking-wider text-cyan-400 uppercase border-b border-white/10 pb-2">
                      Room Maintenance Block
                    </h3>
                    <form onSubmit={handleMaintenance} className="mt-4 space-y-4">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Target Classroom</label>
                        <select
                          required
                          value={maintRoomId}
                          onChange={(e) => setMaintRoomId(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-sm text-slate-200 outline-none focus:ring-1 focus:ring-cyan-400"
                        >
                          <option value="">Select Room</option>
                          {rooms.map((r) => (
                            <option key={r.room_id} value={r.room_id}>
                              {r.room_number} ({r.room_type})
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Start Date & Time</label>
                        <input
                          type="datetime-local"
                          required
                          value={maintStart}
                          onChange={(e) => setMaintStart(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-xs text-slate-200 outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">End Date & Time</label>
                        <input
                          type="datetime-local"
                          required
                          value={maintEnd}
                          onChange={(e) => setMaintEnd(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-xs text-slate-200 outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Reason Description</label>
                        <textarea
                          required
                          rows={2}
                          value={maintReason}
                          onChange={(e) => setMaintReason(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-xs text-slate-200 outline-none"
                        />
                      </div>
                      <button
                        type="submit"
                        className="w-full rounded-xl bg-rose-500 py-3 text-xs font-bold text-slate-950 hover:bg-rose-400 transition cursor-pointer"
                      >
                        Schedule Block
                      </button>
                    </form>
                  </div>

                  {/* Emergency Bulk Cancellation */}
                  <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl">
                    <h3 className="text-xs font-bold tracking-wider text-cyan-400 uppercase border-b border-white/10 pb-2">
                      Emergency Bulk Cancellation
                    </h3>
                    <form onSubmit={handleBulkCancel} className="mt-4 space-y-4">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Academic Building Core</label>
                        <select
                          value={bulkBldgId}
                          onChange={(e) => setBulkBldgId(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-sm text-slate-200 outline-none"
                        >
                          <option value="">All Buildings</option>
                          <option value="74d38e97-9c0f-43e6-9eb2-af38eccf17d0">North Academic Core (NAC)</option>
                          <option value="2691f423-cec3-432d-ba65-f133a63c23dc">South Academic Core (SAC)</option>
                        </select>
                      </div>
                      <div className="grid gap-2 grid-cols-2">
                        <div>
                          <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Start Time</label>
                          <input
                            type="datetime-local"
                            required
                            value={bulkStart}
                            onChange={(e) => setBulkStart(e.target.value)}
                            className="w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-2.5 text-[11px] text-slate-200 outline-none"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">End Time</label>
                          <input
                            type="datetime-local"
                            required
                            value={bulkEnd}
                            onChange={(e) => setBulkEnd(e.target.value)}
                            className="w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-2.5 text-[11px] text-slate-200 outline-none"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Reason</label>
                        <textarea
                          required
                          rows={2}
                          value={bulkReason}
                          onChange={(e) => setBulkReason(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-xs text-slate-200 outline-none"
                        />
                      </div>
                      <button
                        type="submit"
                        className="w-full rounded-xl bg-amber-400 py-3 text-xs font-bold text-slate-950 hover:bg-amber-300 transition cursor-pointer"
                      >
                        Execute Bulk Cancellation
                      </button>
                    </form>
                  </div>

                  {/* Add classroom */}
                  <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl">
                    <h3 className="text-xs font-bold tracking-wider text-cyan-400 uppercase border-b border-white/10 pb-2">
                      Add New Classroom record
                    </h3>
                    <form onSubmit={handleAddClassroom} className="mt-4 space-y-4">
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Room Number</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. NAC-501"
                            value={newRoomNumber}
                            onChange={(e) => setNewRoomNumber(e.target.value)}
                            className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-xs text-slate-200 outline-none"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Building</label>
                          <select
                            required
                            value={newBuildingId}
                            onChange={(e) => setNewBuildingId(e.target.value)}
                            className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-xs text-slate-200 outline-none"
                          >
                            <option value="">Select Building</option>
                            <option value="74d38e97-9c0f-43e6-9eb2-af38eccf17d0">North Academic Core (NAC)</option>
                            <option value="2691f423-cec3-432d-ba65-f133a63c23dc">South Academic Core (SAC)</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid gap-3 sm:grid-cols-3">
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Floor</label>
                          <input
                            type="number"
                            required
                            placeholder="5"
                            value={newFloor}
                            onChange={(e) => setNewFloor(e.target.value)}
                            className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-xs text-slate-200 outline-none"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Capacity</label>
                          <input
                            type="number"
                            required
                            placeholder="45"
                            value={newCapacity}
                            onChange={(e) => setNewCapacity(e.target.value)}
                            className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-xs text-slate-200 outline-none"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Type</label>
                          <select
                            value={newRoomType}
                            onChange={(e) => setNewRoomType(e.target.value)}
                            className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-xs text-slate-200 outline-none"
                          >
                            <option value="LectureHall">Lecture Hall</option>
                            <option value="SeminarRoom">Seminar Room</option>
                            <option value="ComputerLab">Computer Lab</option>
                            <option value="ExamHall">Exam Hall</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Equipment</label>
                        <div className="grid grid-cols-2 gap-2 text-xs text-slate-300">
                          <label className="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" checked={newEquipProjector} onChange={(e) => setNewEquipProjector(e.target.checked)} className="rounded border-white/10 bg-slate-950 text-cyan-400" />
                            <span>Projector</span>
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" checked={newEquipSmartBoard} onChange={(e) => setNewEquipSmartBoard(e.target.checked)} className="rounded border-white/10 bg-slate-950 text-cyan-400" />
                            <span>Smart Board</span>
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" checked={newEquipWhiteboard} onChange={(e) => setNewEquipWhiteboard(e.target.checked)} className="rounded border-white/10 bg-slate-950 text-cyan-400" />
                            <span>Whiteboard</span>
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" checked={newEquipAC} onChange={(e) => setNewEquipAC(e.target.checked)} className="rounded border-white/10 bg-slate-950 text-cyan-400" />
                            <span>Air Conditioning</span>
                          </label>
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full rounded-xl bg-cyan-400 py-3 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer"
                      >
                        Add Classroom Record
                      </button>
                    </form>
                  </div>

                  {/* Bulk import UI */}
                  <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-4">
                    <div className="flex items-center justify-between border-b border-white/10 pb-2">
                      <h3 className="text-xs font-bold tracking-wider text-cyan-400 uppercase">
                        Inventory Bulk Import (Excel / CSV)
                      </h3>
                      <button
                        onClick={downloadExcelTemplate}
                        className="text-[10px] font-bold text-cyan-400 hover:underline cursor-pointer"
                      >
                        📥 Download Excel Template
                      </button>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1.5">
                          Upload Spreadsheet File (.xlsx, .xls, .csv)
                        </label>
                        <input
                          type="file"
                          accept=".xlsx, .xls, .csv"
                          onChange={handleExcelImport}
                          className="w-full text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-[11px] file:font-bold file:bg-white/10 file:text-white file:hover:bg-white/15 cursor-pointer file:cursor-pointer"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1.5">
                          Or Edit Raw JSON Preview
                        </label>
                        <textarea
                          rows={5}
                          value={importJson}
                          onChange={(e) => setImportJson(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-xs font-mono text-slate-300 outline-none"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => { setIsCreatingRoom(true); setEditRoomForm({}); }}
                          className="w-full rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 py-2.5 px-4 text-xs font-bold hover:bg-emerald-500/30 transition cursor-pointer"
                        >
                          + Create Room
                        </button>
                        <button
                          onClick={handleImportRooms}
                          className="w-full rounded-xl bg-cyan-400 py-2.5 px-4 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer whitespace-nowrap"
                        >
                          Import Inventory
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            ) : adminSubTab === "inventory" ? (
              <div className="space-y-6">
                <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-4">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                      <h3 className="text-lg font-bold text-white">Classroom Directory Manager</h3>
                      <p className="text-xs text-slate-400 mt-1">Filter and view physical inventory profiles by building code and floor level.</p>
                    </div>

                    <div className="flex flex-wrap gap-3 items-center">
                      <input 
                        type="text" 
                        placeholder="Search room (e.g. NAC-501)" 
                        className="rounded-xl border border-white/10 bg-slate-900 px-3 py-1.5 text-xs text-slate-200 outline-none min-w-[150px] focus:border-cyan-400/50"
                        value={adminRoomSearch}
                        onChange={e => setAdminRoomSearch(e.target.value)}
                      />
                      {/* Building filter */}
                      <div>
                        <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Building</label>
                        <select
                          value={adminFilterBuilding}
                          onChange={(e) => setAdminFilterBuilding(e.target.value)}
                          className="rounded-xl border border-white/10 bg-slate-900 px-3 py-1.5 text-xs text-slate-200 outline-none"
                        >
                          <option value="All">All Buildings</option>
                          {Array.from(new Set(rooms.map((r) => r.building_code))).filter(Boolean).map((code) => (
                            <option key={code} value={code}>{code}</option>
                          ))}
                        </select>
                      </div>

                      {/* Floor filter */}
                      <div>
                        <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Floor</label>
                        <select
                          value={adminFilterFloor}
                          onChange={(e) => setAdminFilterFloor(e.target.value)}
                          className="rounded-xl border border-white/10 bg-slate-900 px-3 py-1.5 text-xs text-slate-200 outline-none"
                        >
                          <option value="All">All Floors</option>
                          {Array.from(new Set(rooms.map((r) => r.floor))).sort((a, b) => a - b).map((floor) => (
                            <option key={floor} value={String(floor)}>{floor}th Floor</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Classroom cards grid */}
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {rooms
                    .filter((room) => {
                      const matchSearch = room.room_number?.toLowerCase().includes(adminRoomSearch.toLowerCase()) || room.room_type?.toLowerCase().includes(adminRoomSearch.toLowerCase());
                      const matchBuilding = adminFilterBuilding === "All" || room.building_code === adminFilterBuilding;
                      const matchFloor = adminFilterFloor === "All" || String(room.floor) === adminFilterFloor;
                      return matchSearch && matchBuilding && matchFloor;
                    })
                    .map((room) => {
                      return (
                        <div
                          key={room.room_id}
                          className="rounded-2xl border border-white/5 bg-slate-900/35 p-5 space-y-3 hover:border-white/10 transition flex flex-col justify-between"
                        >
                          <div className="space-y-2">
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="font-extrabold text-base text-white">{room.room_number}</h4>
                                <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold mt-0.5">
                                  {room.building_name} · Floor {room.floor}
                                </p>
                              </div>
                              <span className="rounded bg-cyan-400/10 text-cyan-300 border border-cyan-400/25 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider">
                                {room.room_type}
                              </span>
                            </div>

                            <div className="flex justify-between items-center text-[11px] text-slate-300">
                              <div className="flex items-center gap-1.5">
                                <span>👥 Capacity:</span>
                                <span className="font-extrabold text-white">{room.capacity} seats</span>
                              </div>
                              {room.utilization_rate !== undefined && (
                                <div className="flex items-center gap-1.5" title="Weekly Utilization Rate">
                                  <span>📊 Util:</span>
                                  <span className={`font-extrabold ${room.utilization_rate > 80 ? 'text-rose-400' : room.utilization_rate > 50 ? 'text-amber-400' : 'text-emerald-400'}`}>
                                    {room.utilization_rate}%
                                  </span>
                                </div>
                              )}
                            </div>

                            {/* Equipment badges */}
                            <div className="flex flex-wrap gap-1.5 pt-1.5">
                              {room.equipment?.projector && (
                                <span className="rounded bg-white/5 border border-white/10 px-2 py-0.5 text-[9px] text-slate-300 flex items-center gap-1">
                                  📹 Projector
                                </span>
                              )}
                              {room.equipment?.air_conditioning && (
                                <span className="rounded bg-white/5 border border-white/10 px-2 py-0.5 text-[9px] text-slate-300 flex items-center gap-1">
                                  ❄️ AC
                                </span>
                              )}
                              {room.equipment?.whiteboard && (
                                <span className="rounded bg-white/5 border border-white/10 px-2 py-0.5 text-[9px] text-slate-300 flex items-center gap-1">
                                  📝 Whiteboard
                                </span>
                              )}
                              {room.equipment?.smartboard && (
                                <span className="rounded bg-white/5 border border-white/10 px-2 py-0.5 text-[9px] text-slate-300 flex items-center gap-1">
                                  🖥️ Smart Board
                                </span>
                              )}
                              {room.equipment?.audio_system && (
                                <span className="rounded bg-white/5 border border-white/10 px-2 py-0.5 text-[9px] text-slate-300 flex items-center gap-1">
                                  🔊 Audio
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Status and Actions */}
                          <div className="border-t border-white/5 pt-3 flex flex-col gap-3">
                            <div className="flex justify-between items-center">
                              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Status:</span>
                              <span className={`rounded border px-2 py-0.5 text-[9px] font-bold ${
                                room.status === 'Active' ? 'bg-emerald-400/10 text-emerald-300 border-emerald-400/25' : 
                                room.status === 'Maintenance' ? 'bg-amber-400/10 text-amber-300 border-amber-400/25' : 
                                'bg-slate-500/10 text-slate-400 border-slate-500/25'
                              }`}>
                                {room.status}
                              </span>
                            </div>
                            <div className="flex gap-2 justify-end">
                              <button onClick={() => { setEditRoomId(room.room_id); setEditRoomForm({...room, equipment: room.equipment || {}}); }} className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-cyan-400 transition cursor-pointer" title="Edit">✏️</button>
                              {room.status === 'Active' && <button onClick={() => setMaintenanceRoomId(room.room_id)} className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-amber-400 transition cursor-pointer" title="Set Maintenance">🛠️</button>}
                              {room.status !== 'Inactive' && <button onClick={() => setDeactivateRoomId(room.room_id)} className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-rose-400 transition cursor-pointer" title="Deactivate">🛑</button>}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>

                {/* Room Create/Edit Modal */}
                {(isCreatingRoom || editRoomId) && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
                    <div className="bg-slate-900 border border-white/10 rounded-3xl p-6 w-full max-w-2xl shadow-2xl max-h-[90vh] overflow-y-auto custom-scrollbar">
                      <h3 className="text-xl font-black text-cyan-400 mb-6">
                        {isCreatingRoom ? "Create New Classroom" : "Edit Classroom Profile"}
                      </h3>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div>
                          <label className="text-[10px] uppercase text-slate-400 font-bold mb-1 block">Room Number *</label>
                          <input type="text" className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-cyan-400/50" 
                            value={editRoomForm.room_number || ''} onChange={e => setEditRoomForm({...editRoomForm, room_number: e.target.value})} placeholder="e.g. NAC-501" />
                        </div>
                        <div>
                          <label className="text-[10px] uppercase text-slate-400 font-bold mb-1 block">Building Code *</label>
                          <select className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-cyan-400/50" 
                            value={editRoomForm.building_code || ''} onChange={e => setEditRoomForm({...editRoomForm, building_code: e.target.value})}>
                            <option value="">Select Building</option>
                            <option value="NAC">NAC</option>
                            <option value="SAC">SAC</option>
                            <option value="LIB">LIB</option>
                          </select>
                        </div>
                        <div>
                          <label className="text-[10px] uppercase text-slate-400 font-bold mb-1 block">Floor *</label>
                          <input type="number" className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-cyan-400/50" 
                            value={editRoomForm.floor || ''} onChange={e => setEditRoomForm({...editRoomForm, floor: parseInt(e.target.value)})} />
                        </div>
                        <div>
                          <label className="text-[10px] uppercase text-slate-400 font-bold mb-1 block">Capacity *</label>
                          <input type="number" className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-cyan-400/50" 
                            value={editRoomForm.capacity || ''} onChange={e => setEditRoomForm({...editRoomForm, capacity: parseInt(e.target.value)})} />
                        </div>
                        <div>
                          <label className="text-[10px] uppercase text-slate-400 font-bold mb-1 block">Room Type *</label>
                          <select className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-cyan-400/50" 
                            value={editRoomForm.room_type || 'Theory'} onChange={e => setEditRoomForm({...editRoomForm, room_type: e.target.value})}>
                            <option value="Theory">Theory</option>
                            <option value="Lab">Lab</option>
                            <option value="ExamHall">Exam Hall</option>
                          </select>
                        </div>
                      </div>

                      <div className="mb-6">
                        <label className="text-[10px] uppercase text-slate-400 font-bold mb-2 block border-b border-white/10 pb-1">Equipment Flags</label>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                          {['projector', 'smartboard', 'whiteboard', 'air_conditioning', 'audio_system', 'video_conferencing', 'lab_benches'].map(eq => (
                            <label key={eq} className="flex items-center gap-2 cursor-pointer group">
                              <input type="checkbox" className="w-4 h-4 rounded border-white/10 bg-slate-950 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-slate-900" 
                                checked={!!editRoomForm.equipment?.[eq]} 
                                onChange={(e) => setEditRoomForm({
                                  ...editRoomForm, 
                                  equipment: { ...editRoomForm.equipment, [eq]: e.target.checked }
                                })} 
                              />
                              <span className="text-xs text-slate-300 group-hover:text-white capitalize">{eq.replace('_', ' ')}</span>
                            </label>
                          ))}
                        </div>
                        <div className="mt-3">
                          <label className="text-[10px] uppercase text-slate-400 font-bold mb-1 block">Computer Stations (Count)</label>
                          <input type="number" className="w-full sm:w-1/3 bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-cyan-400/50" 
                            value={editRoomForm.equipment?.computer_stations || ''} 
                            onChange={e => setEditRoomForm({
                              ...editRoomForm, 
                              equipment: { ...editRoomForm.equipment, computer_stations: parseInt(e.target.value) || 0 }
                            })} 
                            placeholder="0" />
                        </div>
                      </div>

                      <div className="flex gap-4">
                        <button onClick={() => { setIsCreatingRoom(false); setEditRoomId(null); setEditRoomForm({}); }} className="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 px-4 rounded-xl transition cursor-pointer">
                          Cancel
                        </button>
                        <button onClick={() => isCreatingRoom ? handleCreateRoom() : handleUpdateRoom(editRoomId!)} className="flex-1 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-3 px-4 rounded-xl transition cursor-pointer">
                          {isCreatingRoom ? "Create Room" : "Save Changes"}
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Deactivate Room Modal */}
                {deactivateRoomId && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
                    <div className="bg-slate-900 border border-rose-500/30 rounded-3xl p-6 w-full max-w-sm shadow-2xl">
                      <h3 className="text-xl font-black text-rose-400 mb-2">Deactivate Room?</h3>
                      <p className="text-sm text-slate-300 mb-6">
                        Are you sure you want to deactivate this room? It will be hidden from searches but retained in historical records.
                      </p>
                      <div className="flex gap-4">
                        <button onClick={() => setDeactivateRoomId(null)} className="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 px-4 rounded-xl transition cursor-pointer">
                          Cancel
                        </button>
                        <button onClick={handleDeactivateRoom} className="flex-1 bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 border border-rose-500/50 font-bold py-3 px-4 rounded-xl transition cursor-pointer">
                          Confirm
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Set Maintenance Modal */}
                {maintenanceRoomId && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
                    <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 w-full max-w-md shadow-2xl">
                      <h3 className="text-xl font-black text-amber-400 mb-2">Set Room Maintenance</h3>
                      <p className="text-sm text-slate-300 mb-6">
                        Define a maintenance window. <strong className="text-rose-400">WARNING:</strong> Any existing confirmed bookings overlapping this window will be auto-cancelled and the respective faculty members will be notified.
                      </p>
                      <div className="space-y-4 mb-6">
                        <div>
                          <label className="text-[10px] uppercase text-slate-400 font-bold mb-1 block">Start Date/Time</label>
                          <input type="datetime-local" className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-amber-400/50"
                            value={maintenanceForm.startDt} onChange={e => setMaintenanceForm({...maintenanceForm, startDt: e.target.value})} />
                        </div>
                        <div>
                          <label className="text-[10px] uppercase text-slate-400 font-bold mb-1 block">End Date/Time</label>
                          <input type="datetime-local" className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-amber-400/50"
                            value={maintenanceForm.endDt} onChange={e => setMaintenanceForm({...maintenanceForm, endDt: e.target.value})} />
                        </div>
                        <div>
                          <label className="text-[10px] uppercase text-slate-400 font-bold mb-1 block">Reason</label>
                          <textarea className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-amber-400/50"
                            rows={3} placeholder="e.g. AC repair..."
                            value={maintenanceForm.reason} onChange={e => setMaintenanceForm({...maintenanceForm, reason: e.target.value})}></textarea>
                        </div>
                      </div>
                      <div className="flex gap-4">
                        <button onClick={() => setMaintenanceRoomId(null)} className="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 px-4 rounded-xl transition cursor-pointer">
                          Cancel
                        </button>
                        <button onClick={handleSetMaintenance} className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-3 px-4 rounded-xl transition cursor-pointer">
                          Confirm Maintenance
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : adminSubTab === "faculty" ? (
              <div className="space-y-6">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm">
                  <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase border-b border-white/10 pb-3 mb-4">Create New Faculty Profile</h3>
                  
                  {facultyCreationStatus && (
                    <div className={`mb-4 p-3 rounded-lg text-xs font-bold ${facultyCreationStatus.includes('Error') ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'}`}>
                      {facultyCreationStatus}
                    </div>
                  )}

                  <form onSubmit={handleFacultyCreate} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Username</label>
                        <input type="text" required value={facultyForm.username} onChange={e => setFacultyForm({...facultyForm, username: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Full Name (English)</label>
                        <input type="text" required value={facultyForm.full_name_en} onChange={e => setFacultyForm({...facultyForm, full_name_en: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Full Name (Bengali)</label>
                        <input type="text" value={facultyForm.full_name_bn} onChange={e => setFacultyForm({...facultyForm, full_name_bn: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div className="col-span-2">
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Email Address</label>
                        <input type="email" required value={facultyForm.email} onChange={e => setFacultyForm({...facultyForm, email: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Designation</label>
                        <select value={facultyForm.designation} onChange={e => setFacultyForm({...facultyForm, designation: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50">
                          <option value="Professor">Professor</option>
                          <option value="AssociateProfessor">Associate Professor</option>
                          <option value="AssistantProfessor">Assistant Professor</option>
                          <option value="Lecturer">Lecturer</option>
                          <option value="Adjunct">Adjunct</option>
                          <option value="Visiting">Visiting</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Department</label>
                        <input type="text" value={facultyForm.department} onChange={e => setFacultyForm({...facultyForm, department: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Phone</label>
                        <input type="text" value={facultyForm.phone} onChange={e => setFacultyForm({...facultyForm, phone: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Seniority Rank (1=Highest, 4=Lowest)</label>
                        <input type="number" min="1" max="4" required value={facultyForm.seniority_rank} onChange={e => setFacultyForm({...facultyForm, seniority_rank: parseInt(e.target.value)})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Joining Date (Optional)</label>
                        <input type="date" value={facultyForm.joining_date} onChange={e => setFacultyForm({...facultyForm, joining_date: e.target.value})} onClick={(e) => e.currentTarget.showPicker?.()} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-400 outline-none focus:border-cyan-400/50 cursor-pointer" />
                      </div>
                      <div className="flex items-center gap-2 pt-6">
                        <input type="checkbox" id="deptHead" checked={facultyForm.dept_head_flag} onChange={e => setFacultyForm({...facultyForm, dept_head_flag: e.target.checked})} className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-cyan-400" />
                        <label htmlFor="deptHead" className="text-xs font-bold text-slate-300">Is Department Head?</label>
                      </div>
                    </div>
                    <div className="pt-4 border-t border-white/10 flex justify-end">
                      <button type="submit" className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-2 px-6 rounded-xl shadow-lg shadow-cyan-500/20 transition cursor-pointer">
                        Create Faculty Profile
                      </button>
                    </div>
                  </form>
                </div>

                {/* Faculty Directory Table */}
                <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl mt-6">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-white/10 pb-3 mb-4 gap-4">
                    <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase flex items-center">
                      Faculty Directory
                      <button onClick={fetchAdminFaculties} className="ml-4 text-xs bg-slate-800 px-3 py-1 rounded-lg text-slate-300 hover:text-white transition cursor-pointer">Refresh</button>
                      <button onClick={handleSyncHR} className="ml-2 text-xs bg-emerald-500/20 px-3 py-1 rounded-lg text-emerald-400 font-bold hover:bg-emerald-500/30 transition cursor-pointer flex items-center gap-1">
                        <span className="text-[10px]">🔄</span> Sync HR API
                      </button>
                    </h3>
                    <input 
                      type="text" 
                      placeholder="Search faculty..." 
                      className="bg-slate-900 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400/50 min-w-[200px]"
                      value={adminFacultySearch}
                      onChange={e => setAdminFacultySearch(e.target.value)}
                    />
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm text-slate-400">
                      <thead className="bg-slate-900/50 text-xs uppercase text-slate-300">
                        <tr>
                          <th className="px-4 py-3 font-bold rounded-tl-xl">ID / Emp ID</th>
                          <th className="px-4 py-3 font-bold">Name (EN/BN)</th>
                          <th className="px-4 py-3 font-bold">Contact / Rank</th>
                          <th className="px-4 py-3 font-bold">Status</th>
                          <th className="px-4 py-3 font-bold rounded-tr-xl text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {adminFaculties.filter((f: any) => 
                          (f.full_name_en?.toLowerCase() || "").includes(adminFacultySearch.toLowerCase()) || 
                          (f.employee_id?.toLowerCase() || "").includes(adminFacultySearch.toLowerCase()) ||
                          (f.designation?.toLowerCase() || "").includes(adminFacultySearch.toLowerCase())
                        ).map((f: any) => (
                          <tr key={f.faculty_id} className="hover:bg-white/[0.02] transition">
                            {editFacultyId === f.faculty_id ? (
                              <td colSpan={5} className="p-4 bg-slate-900/80 rounded-xl">
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                                  <div><label className="text-[10px] uppercase text-slate-400">Employee ID</label><input type="text" className="w-full bg-slate-800 rounded px-2 py-1 text-white" value={editFacultyForm.employee_id} onChange={e => setEditFacultyForm({...editFacultyForm, employee_id: e.target.value})} /></div>
                                  <div><label className="text-[10px] uppercase text-slate-400">Username</label><input type="text" className="w-full bg-slate-800 rounded px-2 py-1 text-white" value={editFacultyForm.username} onChange={e => setEditFacultyForm({...editFacultyForm, username: e.target.value})} /></div>
                                  <div><label className="text-[10px] uppercase text-slate-400">Full Name (EN)</label><input type="text" className="w-full bg-slate-800 rounded px-2 py-1 text-white" value={editFacultyForm.full_name_en} onChange={e => setEditFacultyForm({...editFacultyForm, full_name_en: e.target.value})} /></div>
                                  <div><label className="text-[10px] uppercase text-slate-400">Full Name (BN)</label><input type="text" className="w-full bg-slate-800 rounded px-2 py-1 text-white" value={editFacultyForm.full_name_bn || ''} onChange={e => setEditFacultyForm({...editFacultyForm, full_name_bn: e.target.value})} /></div>
                                  <div><label className="text-[10px] uppercase text-slate-400">Email</label><input type="email" className="w-full bg-slate-800 rounded px-2 py-1 text-white" value={editFacultyForm.email} onChange={e => setEditFacultyForm({...editFacultyForm, email: e.target.value})} /></div>
                                  <div>
                                    <label className="text-[10px] uppercase text-slate-400">Designation</label>
                                    <select className="w-full bg-slate-800 rounded px-2 py-1 text-white" value={editFacultyForm.designation} onChange={e => setEditFacultyForm({...editFacultyForm, designation: e.target.value})}>
                                      <option value="Professor">Professor</option>
                                      <option value="AssociateProfessor">Associate Professor</option>
                                      <option value="AssistantProfessor">Assistant Professor</option>
                                      <option value="Lecturer">Lecturer</option>
                                      <option value="Adjunct">Adjunct</option>
                                      <option value="Visiting">Visiting</option>
                                    </select>
                                  </div>
                                  <div><label className="text-[10px] uppercase text-slate-400">Rank (1-4)</label><input type="number" min="1" max="4" className="w-full bg-slate-800 rounded px-2 py-1 text-white" value={editFacultyForm.seniority_rank} onChange={e => setEditFacultyForm({...editFacultyForm, seniority_rank: parseInt(e.target.value)})} /></div>
                                  <div><label className="text-[10px] uppercase text-slate-400">Joining Date</label><input type="date" className="w-full bg-slate-800 rounded px-2 py-1 text-white cursor-pointer" value={editFacultyForm.joining_date || ''} onChange={e => setEditFacultyForm({...editFacultyForm, joining_date: e.target.value})} onClick={(e) => e.currentTarget.showPicker?.()} /></div>
                                </div>
                                <div className="flex justify-end gap-2">
                                  <button onClick={() => setEditFacultyId(null)} className="px-3 py-1 bg-slate-700 text-white rounded text-xs cursor-pointer">Cancel</button>
                                  <button onClick={() => handleUpdateFaculty(f.faculty_id)} className="px-3 py-1 bg-cyan-500 text-slate-950 font-bold rounded text-xs cursor-pointer">Save</button>
                                </div>
                              </td>
                            ) : (
                              <>
                                <td className="px-4 py-3">
                                  <div className="font-mono text-cyan-400">{f.employee_id}</div>
                                  <div className="text-xs text-slate-500">@{f.username}</div>
                                </td>
                                <td className="px-4 py-3">
                                  <div className="text-slate-200 font-bold">{f.full_name_en}</div>
                                  {f.full_name_bn && <div className="text-xs text-slate-500">{f.full_name_bn}</div>}
                                </td>
                                <td className="px-4 py-3">
                                  <div className="text-slate-300">{f.designation} <span className="text-slate-500 bg-slate-800 px-1 rounded">Rank: {f.seniority_rank}</span></div>
                                  <div className="text-xs text-slate-500">{f.email}</div>
                                </td>
                                <td className="px-4 py-3">
                                  <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider ${f.status === 'Active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-500/20 text-slate-400'}`}>
                                    {f.status}
                                  </span>
                                  {f.dept_head_flag && <span className="ml-2 px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider bg-fuchsia-500/20 text-fuchsia-400">Head</span>}
                                </td>
                                <td className="px-4 py-3 text-right">
                                  {f.status === 'Active' ? (
                                    <div className="flex items-center justify-end gap-2">
                                      <button onClick={() => setViewRoutineFaculty(f)} className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-cyan-400 transition cursor-pointer" title="View Routine">🗓️</button>
                                      <button onClick={() => { setEditFacultyId(f.faculty_id); setEditFacultyForm({...f}); }} className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-cyan-400 transition cursor-pointer" title="Edit">✏️</button>
                                      <button onClick={() => setOverrideRankId(f.faculty_id)} className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-fuchsia-400 transition cursor-pointer" title="Adjust Rank">⭐</button>
                                      <button onClick={() => setResetPasswordFacultyId(f.faculty_id)} className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-amber-400 transition cursor-pointer" title="Reset Password">🔑</button>
                                      <button onClick={() => setDeactivateFacultyId(f.faculty_id)} className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-rose-400 transition cursor-pointer" title="Deactivate">🛑</button>
                                    </div>
                                  ) : (
                                    <div className="text-xs text-slate-500 italic">Inactive</div>
                                  )}
                                </td>
                              </>
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Adjust Rank Modal */}
                {overrideRankId && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
                    <div className="bg-slate-900 border border-white/10 p-6 rounded-3xl max-w-md w-full shadow-2xl">
                      <h2 className="text-xl font-black text-white mb-2">Adjust Faculty Rank</h2>
                      <p className="text-sm text-slate-400 mb-6">This action will manually override the faculty's seniority rank and will be logged in the system audit trail.</p>
                      
                      <form onSubmit={handleOverrideRank} className="space-y-4">
                        <div>
                          <label className="block text-[10px] text-slate-400 uppercase mb-1">Target Rank (1=Highest, 4=Lowest)</label>
                          <input 
                            type="number" min="1" max="4" required 
                            value={overrideRankForm.targetRank} 
                            onChange={e => setOverrideRankForm({...overrideRankForm, targetRank: parseInt(e.target.value)})} 
                            className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" 
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-400 uppercase mb-1">Written Justification</label>
                          <textarea 
                            required rows={3}
                            value={overrideRankForm.justification} 
                            onChange={e => setOverrideRankForm({...overrideRankForm, justification: e.target.value})} 
                            className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50 resize-none" 
                            placeholder="Reason for rank override (e.g., Visiting Professor, Emeritus)"
                          ></textarea>
                        </div>
                        <div className="flex gap-3 justify-end pt-4">
                          <button type="button" onClick={() => setOverrideRankId(null)} className="px-5 py-2.5 rounded-xl text-sm font-bold text-slate-300 hover:bg-slate-800 transition cursor-pointer">Cancel</button>
                          <button type="submit" className="px-5 py-2.5 rounded-xl text-sm font-bold bg-fuchsia-500 hover:bg-fuchsia-400 text-white shadow-lg shadow-fuchsia-500/20 transition cursor-pointer">Submit Override</button>
                        </div>
                      </form>
                    </div>
                  </div>
                )}

                {/* Deactivate Faculty Modal */}
                {deactivateFacultyId && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
                    <div className="bg-slate-900 border border-rose-500/30 rounded-3xl p-6 w-full max-w-lg shadow-2xl">
                      <h3 className="text-xl font-black text-rose-400 mb-2">Deactivate Faculty?</h3>
                      <p className="text-sm text-slate-300 mb-6">
                        This will mark the faculty as Inactive. If they have active bookings or courses, they will be left without an instructor.
                        To prevent this, you can optionally transfer their workload to another active faculty member.
                      </p>
                      
                      <div className="mb-6">
                        <label className="block text-[10px] text-slate-400 uppercase mb-2">Replacement Faculty (Optional)</label>
                        <select 
                          className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-sm text-slate-200 outline-none focus:border-cyan-400/50"
                          value={replacementFacultyId}
                          onChange={(e) => setReplacementFacultyId(e.target.value)}
                        >
                          <option value="">-- No Replacement (Auto-Cancel active bookings) --</option>
                          {adminFaculties.filter(f => f.status === 'Active' && f.faculty_id !== deactivateFacultyId).map(f => (
                            <option key={f.faculty_id} value={f.faculty_id}>{f.full_name_en} ({f.employee_id})</option>
                          ))}
                        </select>
                      </div>

                      <div className="flex gap-4">
                        <button onClick={() => { setDeactivateFacultyId(null); setReplacementFacultyId(""); }} className="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 px-4 rounded-xl transition cursor-pointer">
                          Cancel
                        </button>
                        <button onClick={handleDeactivateFaculty} className="flex-1 bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 border border-rose-500/50 font-bold py-3 px-4 rounded-xl transition cursor-pointer">
                          Confirm Deactivation
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Reset Password Modal */}
                {resetPasswordFacultyId && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
                    <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 w-full max-w-sm shadow-2xl">
                      <h3 className="text-xl font-black text-amber-400 mb-2">Reset Password</h3>
                      <p className="text-sm text-slate-300 mb-6">Enter a new password for this faculty member.</p>
                      
                      <div className="mb-6">
                        <input 
                          type="text" 
                          placeholder="New Password"
                          className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-sm text-slate-200 outline-none focus:border-amber-400/50"
                          value={resetPasswordValue}
                          onChange={(e) => setResetPasswordValue(e.target.value)}
                        />
                      </div>

                      <div className="flex gap-4">
                        <button onClick={() => { setResetPasswordFacultyId(null); setResetPasswordValue(""); }} className="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 px-4 rounded-xl transition cursor-pointer">
                          Cancel
                        </button>
                        <button onClick={handleResetPassword} className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-3 px-4 rounded-xl transition cursor-pointer">
                          Save Password
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* View Routine Modal */}
                {viewRoutineFaculty && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
                    <div className="bg-slate-900 border border-cyan-500/30 rounded-3xl flex flex-col w-full max-w-5xl shadow-2xl" style={{ height: '80vh' }}>
                      <div className="p-4 border-b border-white/10 flex justify-between items-center bg-slate-800/50 rounded-t-3xl">
                        <div>
                          <h3 className="text-xl font-black text-cyan-400">{viewRoutineFaculty.full_name_en}&apos;s Weekly Routine</h3>
                          <p className="text-xs text-slate-400">{viewRoutineFaculty.designation} • {viewRoutineFaculty.employee_id}</p>
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => handleExportFacultySchedulePDF(viewRoutineFaculty.email, viewRoutineFaculty.full_name_en)} className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-1.5 px-4 rounded-lg text-sm transition cursor-pointer">
                            Export PDF
                          </button>
                          <button onClick={() => setViewRoutineFaculty(null)} className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-lg cursor-pointer">
                            ✕
                          </button>
                        </div>
                      </div>
                      
                      <div className="flex-1 overflow-auto p-6 bg-slate-950/50">
                        {selectedBatchData ? (
                          <div className="bg-slate-900 border border-white/5 rounded-2xl p-4">
                            {(() => {
                              const fAllocs = selectedBatchData.allocations.filter((a: any) => 
                                (a.allocated_faculty_email || "").toLowerCase() === viewRoutineFaculty.email.toLowerCase() ||
                                (a.allocated_faculty_name || "").toLowerCase() === viewRoutineFaculty.full_name_en.toLowerCase()
                              );
                              if (fAllocs.length === 0) return <div className="text-center p-12 text-slate-500">No classes scheduled for this faculty.</div>;
                              
                              const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                              const START_HOUR = 8;
                              const END_HOUR = 18;
                              
                              return (
                                <div className="grid grid-cols-[60px_1fr_1fr_1fr_1fr_1fr_1fr_1fr] gap-1">
                                  {/* Time Axis */}
                                  <div className="flex flex-col pt-[30px]">
                                    {Array.from({ length: END_HOUR - START_HOUR + 1 }).map((_, i) => (
                                      <div key={i} className="h-[60px] flex items-start justify-end pr-2 relative">
                                        <span className="text-[10px] font-bold text-slate-500 -translate-y-1/2">
                                          {START_HOUR + i > 12 ? START_HOUR + i - 12 : START_HOUR + i}:00 {START_HOUR + i >= 12 ? 'PM' : 'AM'}
                                        </span>
                                      </div>
                                    ))}
                                  </div>
                                  
                                  {/* Day Columns */}
                                  {DAYS.map((day, dayIndex) => {
                                    const dayAllocs = fAllocs.filter((a: any) => classMatchesDay(a, dayIndex));
                                    return (
                                      <div key={day} className="flex flex-col bg-slate-950 rounded-xl overflow-hidden border border-white/5">
                                        <div className="bg-slate-900 text-center py-2 text-[10px] font-bold text-slate-300 uppercase tracking-wider border-b border-white/10 z-10">
                                          {day}
                                        </div>
                                        <div className="relative flex-1" style={{ height: `${(END_HOUR - START_HOUR + 1) * 60}px` }}>
                                          {Array.from({ length: END_HOUR - START_HOUR + 1 }).map((_, i) => (
                                            <div key={i} className="absolute left-0 right-0 h-[1px] bg-white/5" style={{ top: `${i * 60}px` }} />
                                          ))}
                                          
                                          {dayAllocs.map((alloc: any, i: number) => {
                                            const startStr = alloc.allocated_start_time || "08:00:00";
                                            const endStr = alloc.allocated_end_time || "09:30:00";
                                            const [sH, sM] = startStr.split(':').map(Number);
                                            const [eH, eM] = endStr.split(':').map(Number);
                                            
                                            const top = ((sH + sM/60) - START_HOUR) * 60;
                                            const height = ((eH + eM/60) - (sH + sM/60)) * 60;
                                            
                                            return (
                                              <div 
                                                key={i}
                                                className="absolute left-1 right-1 bg-cyan-950/40 border border-cyan-500/30 border-l-4 border-l-cyan-500 rounded-md p-1.5 hover:bg-cyan-900/60 hover:z-20 transition shadow-lg shadow-black/20"
                                                style={{ top: `${top}px`, height: `${height}px` }}
                                              >
                                                <div className="text-[9px] font-bold text-cyan-400 mb-0.5">{startStr.substring(0,5)} - {endStr.substring(0,5)}</div>
                                                <div className="text-[10px] font-black text-slate-200 leading-tight mb-0.5">{alloc.course_code}</div>
                                                <div className="text-[9px] font-bold text-slate-400 bg-slate-900/50 inline-block px-1 rounded mb-1">Sec {alloc.section_number}</div>
                                                <div className="text-[9px] text-slate-300 mt-auto">Room {alloc.room_number}</div>
                                              </div>
                                            );
                                          })}
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              );
                            })()}
                          </div>
                        ) : (
                          <div className="text-center p-12 text-slate-500">No active batch data available to show timetable.</div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : null}
          </div>

        )}

        {/* TAB: SEMESTER ALLOCATION */}
        {activeTab === "allocation" && user.role === "Admin" && (
          <section className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl">
              <div>
                <h2 className="text-2xl font-black text-white flex items-center gap-2">
                  <span className="h-3 w-3 rounded-full bg-cyan-400 pulse-dot" />
                  Bulk Semester Allocation Console
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Draft, optimize, resolve scheduling conflicts, and finalize the university semester timetable.
                </p>
              </div>
              <div className="flex gap-2">
                {!isCreatingBatch && !selectedBatchId && (
                  <button
                    onClick={() => {
                      setIsCreatingBatch(true);
                      handleLoadDemoCourses();
                    }}
                    className="rounded-xl bg-cyan-400 px-4 py-2.5 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition shadow-lg shadow-cyan-400/10 cursor-pointer"
                  >
                    + Create New Batch Run
                  </button>
                )}
                {(isCreatingBatch || selectedBatchId) && (
                  <button
                    onClick={() => {
                      setIsCreatingBatch(false);
                      setSelectedBatchId("");
                      setSelectedBatchData(null);
                      fetchBatches();
                    }}
                    className="rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-xs font-bold text-slate-200 hover:bg-white/10 transition cursor-pointer"
                  >
                    ← Back to Batches Directory
                  </button>
                )}
              </div>
            </div>

            {allocationLoading ? (
              <div className="flex flex-col items-center justify-center py-24 rounded-3xl border border-white/10 bg-slate-950/20 backdrop-blur-xl space-y-4">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-cyan-400 border-t-transparent" />
                <p className="text-sm text-slate-400">Processing allocation engine calculations... Please wait.</p>
              </div>
            ) : isCreatingBatch ? (
              /* CREATE BATCH PANEL */
              <div className="grid gap-6 lg:grid-cols-3">
                <div className="lg:col-span-2 rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-5">

                  {/* ─── STEP 0: DATA PULL CONSOLE ─── */}
                  <div className="rounded-2xl border border-cyan-500/20 bg-cyan-500/5 p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
                        <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase">0. Pull Data from Database</h3>
                      </div>
                      <button
                        onClick={() => setDataPullExpanded(!dataPullExpanded)}
                        className="text-[10px] text-slate-400 hover:text-cyan-300 transition font-bold"
                      >
                        {dataPullExpanded ? "▲ Collapse" : "▼ Expand"}
                      </button>
                    </div>

                    {/* Pull Action Buttons */}
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={handlePullSummary}
                        disabled={pullingSummary}
                        className="rounded-xl border border-cyan-400/30 bg-cyan-400/10 hover:bg-cyan-400/20 disabled:opacity-50 px-3 py-2.5 text-[10px] font-bold text-cyan-300 transition cursor-pointer flex flex-col items-center gap-1"
                      >
                        <span className="text-lg">{pullingSummary ? "⏳" : "📊"}</span>
                        {pullingSummary ? "Checking..." : "Check Readiness"}
                      </button>
                      <button
                        onClick={handlePullSections}
                        disabled={pullingSections}
                        className="rounded-xl border border-emerald-400/30 bg-emerald-400/10 hover:bg-emerald-400/20 disabled:opacity-50 px-3 py-2.5 text-[10px] font-bold text-emerald-300 transition cursor-pointer flex flex-col items-center gap-1"
                      >
                        <span className="text-lg">{pullingSections ? "⏳" : "📚"}</span>
                        {pullingSections ? "Pulling..." : "Pull Sections"}
                      </button>
                      <button
                        onClick={handlePullPreferences}
                        disabled={pullingPreferences}
                        className="rounded-xl border border-purple-400/30 bg-purple-400/10 hover:bg-purple-400/20 disabled:opacity-50 px-3 py-2.5 text-[10px] font-bold text-purple-300 transition cursor-pointer flex flex-col items-center gap-1"
                      >
                        <span className="text-lg">{pullingPreferences ? "⏳" : "🎯"}</span>
                        {pullingPreferences ? "Pulling..." : "Pull Preferences"}
                      </button>
                    </div>

                    {/* Summary Stats Panel */}
                    {pullSummary && (
                      <div className="space-y-3">
                        <div className="grid grid-cols-3 gap-2 text-center">
                          {/* Sections */}
                          <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-3">
                            <p className="text-xl font-black text-emerald-400">{pullSummary.sections?.total_sections ?? "—"}</p>
                            <p className="text-[9px] text-emerald-300 uppercase font-bold mt-0.5">Sections</p>
                            <p className="text-[9px] text-slate-500 mt-0.5">{pullSummary.sections?.unique_courses} unique courses</p>
                          </div>
                          {/* Preferences */}
                          <div className="rounded-xl border border-purple-500/20 bg-purple-500/10 p-3">
                            <p className="text-xl font-black text-purple-400">{pullSummary.preferences?.faculty_submitted ?? "—"}</p>
                            <p className="text-[9px] text-purple-300 uppercase font-bold mt-0.5">Faculty Voted</p>
                            <p className="text-[9px] text-slate-500 mt-0.5">{pullSummary.preferences?.total_choices} choices total</p>
                          </div>
                          {/* Rooms */}
                          <div className="rounded-xl border border-cyan-500/20 bg-cyan-500/10 p-3">
                            <p className="text-xl font-black text-cyan-400">{pullSummary.classrooms?.total_rooms ?? "—"}</p>
                            <p className="text-[9px] text-cyan-300 uppercase font-bold mt-0.5">Rooms Available</p>
                            <p className="text-[9px] text-slate-500 mt-0.5">{pullSummary.classrooms?.lecture_rooms} lecture · {pullSummary.classrooms?.lab_rooms} lab</p>
                          </div>
                        </div>

                        {/* Readiness indicator */}
                        {(() => {
                          const secs = Number(pullSummary.sections?.total_sections || 0);
                          const rooms = Number(pullSummary.classrooms?.total_rooms || 0);
                          const prefs = Number(pullSummary.preferences?.total_choices || 0);
                          const ready = secs > 0 && rooms > 0;
                          return (
                            <div className={`rounded-xl px-4 py-2.5 flex items-center gap-3 ${ready ? "bg-emerald-500/10 border border-emerald-500/25" : "bg-amber-500/10 border border-amber-500/25"}`}>
                              <span className="text-xl">{ready ? "✅" : "⚠️"}</span>
                              <div className="text-xs">
                                <p className={`font-bold ${ready ? "text-emerald-300" : "text-amber-300"}`}>
                                  {ready ? "Ready to run allocation" : "Not ready — missing data"}
                                </p>
                                <p className="text-slate-400 text-[10px]">
                                  {!secs && "⚠ No course sections for this semester. "}
                                  {!rooms && "⚠ No available classrooms found. "}
                                  {prefs === 0 && "ℹ No faculty preferences — will auto-assign. "}
                                  {ready && `${secs} sections will be allocated across ${rooms} rooms.${prefs > 0 ? ` Faculty preferences: ${prefs}.` : " Auto-assignment mode."}`}
                                </p>
                              </div>
                            </div>
                          );
                        })()}
                      </div>
                    )}

                    {/* Pulled Preferences Preview */}
                    {dataPullExpanded && pulledPreferences.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-purple-300 uppercase tracking-wider flex items-center gap-2">
                          🎯 Faculty Preferences Preview
                          <span className="rounded bg-purple-400/20 text-purple-300 px-2 py-0.5 text-[9px] font-bold">{pulledPreferences.length} choices from {[...new Set(pulledPreferences.map((d) => d.faculty_email))].length} faculty</span>
                        </p>
                        <div className="max-h-[200px] overflow-y-auto custom-scrollbar space-y-1">
                          {(() => {
                            const grouped = new Map<string, any[]>();
                            for (const p of pulledPreferences) {
                              if (!grouped.has(p.faculty_name || p.faculty_email)) grouped.set(p.faculty_name || p.faculty_email, []);
                              grouped.get(p.faculty_name || p.faculty_email)!.push(p);
                            }
                            return [...grouped.entries()].map(([name, choices]) => (
                              <div key={name} className="rounded-xl border border-white/5 bg-slate-900/40 p-2.5">
                                <div className="flex items-center gap-2 mb-1.5">
                                  <span className="font-bold text-white text-[10px]">{name}</span>
                                  <span className="text-[8px] text-purple-300 bg-purple-400/10 px-1.5 py-0.5 rounded font-bold">{choices[0].faculty_designation || "Faculty"}</span>
                                  <span className="text-[8px] text-slate-500">Rank {choices[0].seniority_rank}</span>
                                </div>
                                <div className="flex flex-wrap gap-1">
                                  {choices.sort((a, b) => a.choice_rank - b.choice_rank).map((c) => (
                                    <span key={c.choice_rank} className="text-[9px] bg-slate-800 text-slate-300 rounded px-2 py-0.5 font-mono">
                                      #{c.choice_rank} {c.course_code}-Sec{c.section_number}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            ));
                          })()}
                        </div>
                      </div>
                    )}

                    {/* Pulled Sections Preview */}
                    {dataPullExpanded && pulledSections.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-2">
                          📚 Course Sections in DB
                          <span className="rounded bg-emerald-400/20 text-emerald-300 px-2 py-0.5 text-[9px] font-bold">{pulledSections.length} sections</span>
                          <span className="text-slate-500">→ Loaded into JSON below</span>
                        </p>
                        <div className="max-h-[150px] overflow-y-auto custom-scrollbar">
                          <table className="w-full text-[9px] text-left border-collapse">
                            <thead><tr className="border-b border-white/5 text-slate-500 uppercase">
                              <th className="py-1.5 px-2">Code</th><th className="py-1.5 px-2">Name</th>
                              <th className="py-1.5 px-2 text-center">Sec</th><th className="py-1.5 px-2 text-center">Enroll</th>
                              <th className="py-1.5 px-2">Type</th><th className="py-1.5 px-2">Faculty</th>
                            </tr></thead>
                            <tbody>
                              {pulledSections.map((s, i) => (
                                <tr key={i} className="border-b border-white/[0.03] hover:bg-white/5">
                                  <td className="py-1.5 px-2 font-mono font-bold text-white">{s.course_code}</td>
                                  <td className="py-1.5 px-2 text-slate-400 truncate max-w-[120px]">{s.course_name}</td>
                                  <td className="py-1.5 px-2 text-center text-slate-300">{s.section_number}</td>
                                  <td className="py-1.5 px-2 text-center text-slate-300">{s.enrollment_size}</td>
                                  <td className="py-1.5 px-2">
                                    <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold ${s.facility_type === 'Lab' ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-700 text-slate-300'}`}>{s.facility_type || 'Lecture'}</span>
                                  </td>
                                  <td className="py-1.5 px-2 text-slate-400 truncate max-w-[100px]">{s.assigned_faculty_name || <span className="text-slate-600 italic">unassigned</span>}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex justify-between items-center border-b border-white/5 pb-3">
                    <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase">1. Import Course Sections Spreadsheet</h3>
                    <button
                      onClick={handleDownloadTemplate}
                      className="text-[10px] text-cyan-400 font-bold hover:underline flex items-center gap-1"
                    >
                      📥 Excel Template
                    </button>
                  </div>

                  <div className="border border-dashed border-white/10 hover:border-cyan-400/40 rounded-2xl bg-slate-950/30 p-8 text-center transition relative flex flex-col items-center justify-center group">
                    <input
                      type="file"
                      accept=".csv, .xlsx, .xls"
                      onChange={handleCSVUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                    />
                    <div className="space-y-2">
                      <div className="mx-auto w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center text-slate-400 group-hover:text-cyan-400 transition text-2xl">
                        📊
                      </div>
                      <p className="text-xs font-bold text-white">Drag & drop your Excel (.xlsx / .xls) or CSV sheet here</p>
                      <p className="text-[10px] text-slate-400">
                        File columns should match template properties.
                      </p>
                    </div>
                  </div>

                  {/* Faculty preferences dropzone */}
                  <div className="flex justify-between items-center border-b border-white/5 pb-3 pt-3">
                    <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase">2. Bulk Import Faculty Preferences (Optional)</h3>
                    <button
                      onClick={handleDownloadPreferenceTemplate}
                      className="text-[10px] text-cyan-400 font-bold hover:underline flex items-center gap-1"
                    >
                      📥 Choices Template
                    </button>
                  </div>

                  <div className="border border-dashed border-white/10 hover:border-cyan-400/40 rounded-2xl bg-slate-950/30 p-8 text-center transition relative flex flex-col items-center justify-center group">
                    <input
                      type="file"
                      accept=".csv, .xlsx, .xls"
                      onChange={handlePreferencesCSVUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                    />
                    <div className="space-y-2">
                      <div className="mx-auto w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center text-slate-400 group-hover:text-cyan-400 transition text-2xl">
                        📥
                      </div>
                      <p className="text-xs font-bold text-white">Upload Faculty Choices Sheet (.xlsx / .xls / .csv)</p>
                      <p className="text-[10px] text-slate-400">
                        Required Columns: Email, CourseCode, Section, ChoiceRank
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Raw Course Draft Data (JSON Input)</label>
                    <textarea
                      rows={8}
                      value={allocationCoursesInput}
                      onChange={(e) => setAllocationCoursesInput(e.target.value)}
                      placeholder="Paste JSON list of sections..."
                      className="w-full rounded-2xl border border-white/10 bg-slate-950 px-4 py-3 text-xs font-mono text-slate-300 outline-none focus:ring-1 focus:ring-cyan-400"
                    />
                  </div>
                </div>

                <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl flex flex-col justify-between">
                  <div className="space-y-5">
                    <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase border-b border-white/5 pb-3">3. Batch Details & Run</h3>

                    <div>
                      <label className="text-xs font-bold text-slate-400 uppercase block mb-1">Target Semester</label>
                      <input
                        type="text"
                        required
                        value={allocationSemester}
                        onChange={(e) => setAllocationSemester(e.target.value)}
                        placeholder="e.g. Spring2026"
                        className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-sm text-slate-200 outline-none"
                      />
                    </div>

                    <div className="rounded-2xl border border-white/5 bg-slate-900/30 p-4 text-[11px] leading-relaxed text-slate-400 space-y-2">
                      <p className="font-bold text-slate-200">Priority Engine Constraints:</p>
                      <p>• Classrooms capacity: buffer is 20% (Enrollment × 1.2 buffer check).</p>
                      <p>• Allocations can be adjusted manually before finalizing batch bookings.</p>
                    </div>
                  </div>

                  <div className="mt-6 space-y-2">
                    <button
                      onClick={handleLoadDemoCourses}
                      type="button"
                      className="w-full rounded-xl border border-white/10 bg-white/5 py-2.5 text-xs font-bold text-slate-200 hover:bg-white/10 transition cursor-pointer"
                    >
                      💡 Load Demo Sections
                    </button>
                    <button
                      onClick={handleLoadDemoPreferences}
                      type="button"
                      className="w-full rounded-xl border border-white/10 bg-white/5 py-2.5 text-xs font-bold text-slate-200 hover:bg-white/10 transition cursor-pointer"
                    >
                      💡 Load Demo Choices
                    </button>
                    <button
                      onClick={handleRunAllocation}
                      className="w-full rounded-xl bg-cyan-400 py-3.5 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition shadow-lg"
                    >
                      🚀 Run Allocation Engine
                    </button>
                  </div>
                </div>
              </div>
            ) : selectedBatchId && selectedBatchData && selectedBatchData.batch ? (
              /* DETAIL BATCH RUN */
              <div className="space-y-6">
                <div className="grid gap-4 sm:grid-cols-4">
                  <div className="rounded-2xl border border-white/5 bg-slate-950/45 p-5 backdrop-blur-xl">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Semester</p>
                    <p className="text-xl font-extrabold text-white mt-1">{selectedBatchData.batch.semester}</p>
                    <p className="text-[9px] text-slate-500 mt-1 truncate">ID: {selectedBatchData.batch.batch_id}</p>
                  </div>
                  <div className="rounded-2xl border border-white/5 bg-slate-950/45 p-5 backdrop-blur-xl">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Allocated Success</p>
                    <p className="text-xl font-extrabold text-emerald-400 mt-1">
                      {selectedBatchData.batch.successfully_allocated} / {selectedBatchData.batch.total_sections}
                    </p>
                    <p className="text-[9px] text-slate-500 mt-1">Sections mapped to classrooms</p>
                  </div>
                  <div className="rounded-2xl border border-white/5 bg-slate-950/45 p-5 backdrop-blur-xl">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Active Conflicts</p>
                    <p className="text-xl font-extrabold text-rose-400 mt-1">
                      {selectedBatchData.batch.failed_allocations}
                    </p>
                    <p className="text-[9px] text-slate-500 mt-1">Sections requiring review</p>
                  </div>
                  <div className="rounded-2xl border border-white/5 bg-slate-950/45 p-5 backdrop-blur-xl">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Batch Status</p>
                    <div className="mt-1 flex items-center gap-1.5">
                      <span className={`h-2.5 w-2.5 rounded-full ${selectedBatchData.batch.status === "Confirmed" ? "bg-emerald-400" : "bg-amber-400 animate-pulse"
                        }`} />
                      <p className="text-sm font-bold text-white uppercase tracking-wider">
                        {selectedBatchData.batch.status}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl">
                  <div className="flex justify-between items-center text-xs font-bold text-slate-300 mb-2">
                    <span>Allocation Engine Coverage</span>
                    <span>
                      {Math.round((selectedBatchData.batch.successfully_allocated / selectedBatchData.batch.total_sections) * 100 || 0)}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-900 rounded-full h-2.5">
                    <div
                      className="bg-cyan-400 h-2.5 rounded-full transition-all duration-500"
                      style={{ width: `${(selectedBatchData.batch.successfully_allocated / selectedBatchData.batch.total_sections) * 100 || 0}%` }}
                    />
                  </div>
                </div>

                <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-6">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/5 pb-4">
                    <div className="flex gap-2">
                      <button
                        onClick={() => setAllocationDetailTab("allocated")}
                        className={`rounded-full px-4 py-2 text-xs font-bold transition-all ${allocationDetailTab === "allocated"
                          ? "bg-cyan-400 text-slate-950"
                          : "border border-white/5 bg-white/5 text-slate-300"
                          }`}
                      >
                        Allocated List ({selectedBatchData.allocations.length})
                      </button>
                      <button
                        onClick={() => setAllocationDetailTab("conflicts")}
                        className={`rounded-full px-4 py-2 text-xs font-bold transition-all ${allocationDetailTab === "conflicts"
                          ? "bg-rose-500 text-white"
                          : "border border-white/5 bg-white/5 text-slate-300"
                          }`}
                      >
                        Conflicts List ({selectedBatchData.conflicts.length})
                      </button>
                    </div>

                    <div className="flex gap-2 flex-wrap">
                      <div className="flex rounded-xl overflow-hidden border border-cyan-500/35">
                        <button
                          onClick={() => handleExportPDF("faculty")}
                          title="Export PDF grouped by faculty"
                          className="bg-cyan-500/5 hover:bg-cyan-500/15 px-3.5 py-2.5 text-xs font-bold text-cyan-300 transition cursor-pointer flex items-center gap-1.5 border-r border-cyan-500/25"
                        >
                          👨‍🏫 Faculty PDF
                        </button>
                        <button
                          onClick={() => handleExportPDF("room")}
                          title="Export PDF grouped by classroom"
                          className="bg-cyan-500/5 hover:bg-cyan-500/15 px-3.5 py-2.5 text-xs font-bold text-cyan-300 transition cursor-pointer flex items-center gap-1.5 border-r border-cyan-500/25"
                        >
                          🏫 Room PDF
                        </button>
                        <button
                          onClick={() => handleExportPDF("full" as any)}
                          title="Export complete allocation report with all sections"
                          className="bg-cyan-500/5 hover:bg-cyan-500/15 px-3.5 py-2.5 text-xs font-bold text-cyan-300 transition cursor-pointer flex items-center gap-1.5"
                        >
                          📋 Full Report
                        </button>
                      </div>
                      {selectedBatchData.batch.is_published ? (
                        <span className="rounded-xl bg-purple-500/25 px-4 py-2 text-xs font-bold text-purple-300 border border-purple-400/35 flex items-center gap-1">
                          📢 Active Timetable
                        </span>
                      ) : (
                        <button
                          onClick={() => handlePublishTimetable(selectedBatchId)}
                          className="rounded-xl bg-purple-500 px-4 py-2.5 text-xs font-bold text-white hover:bg-purple-400 transition cursor-pointer shadow-lg shadow-purple-500/20"
                        >
                          📢 Publish to Timetable
                        </button>
                      )}
                      <button
                        onClick={() => handleExportBatchCSV(selectedBatchId)}
                        className="rounded-xl border border-emerald-500/35 bg-emerald-500/5 hover:bg-emerald-500/10 px-4 py-2.5 text-xs font-bold text-emerald-300 transition cursor-pointer"
                      >
                        📥 Export Draft CSV
                      </button>
                      {selectedBatchData.batch.status !== "Confirmed" ? (
                        <button
                          onClick={() => handleConfirmBatch(selectedBatchId)}
                          className="rounded-xl bg-cyan-400 px-4 py-2.5 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer shadow-lg shadow-cyan-400/15"
                        >
                          ✓ Confirm & Create Bookings
                        </button>
                      ) : (
                        <span className="rounded-xl bg-emerald-500/25 px-4 py-2 text-xs font-bold text-emerald-300 border border-emerald-400/35 flex items-center gap-1">
                          ✓ Finalized
                        </span>
                      )}
                    </div>
                  </div>

                  {allocationDetailTab === "allocated" ? (
                    <div className="overflow-x-auto border border-white/5 rounded-2xl">
                      {selectedBatchData.allocations.length === 0 ? (
                        <div className="text-center py-16 border border-dashed border-white/5 rounded-2xl">
                          <p className="text-slate-500 italic text-sm">No course sections successfully allocated yet.</p>
                        </div>
                      ) : (
                        <table className="w-full text-left text-xs border-collapse">
                          <thead>
                            <tr className="border-b border-white/10 bg-slate-950/60 text-slate-400 font-bold uppercase tracking-wider text-[9px]">
                              <th className="py-3 px-4">Course</th>
                              <th className="py-3 px-4">Section</th>
                              <th className="py-3 px-4">Size</th>
                              <th className="py-3 px-4">Room Assigned</th>
                              <th className="py-3 px-4">Faculty Assigned</th>
                              <th className="py-3 px-4">Time Slot</th>
                              <th className="py-3 px-4">Allocation Basis</th>
                              <th className="py-3 px-4 text-right">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5 text-slate-300">
                            {selectedBatchData.allocations.map((alloc: any) => (
                              <tr key={alloc.allocation_id} className="hover:bg-white/[0.01]">
                                <td className="py-3.5 px-4">
                                  <span className="font-bold text-white">{alloc.course_code}</span>
                                  <span className="text-[10px] text-slate-400 block truncate max-w-[200px] mt-0.5">{alloc.course_name}</span>
                                </td>
                                <td className="py-3.5 px-4 font-mono">{alloc.section_number}</td>
                                <td className="py-3.5 px-4">{alloc.enrollment_size}</td>
                                <td className="py-3.5 px-4">
                                  <span className="font-bold text-cyan-300">{alloc.room_number}</span>
                                  <span className="text-[10px] text-slate-400 block mt-0.5">({alloc.capacity} seats)</span>
                                </td>
                                <td className="py-3.5 px-4">
                                  {alloc.allocated_faculty_name ? (
                                    <>
                                      <p className="font-semibold text-white">{alloc.allocated_faculty_name}</p>
                                      <p className="text-[10px] text-slate-400">{alloc.allocated_faculty_designation}</p>
                                    </>
                                  ) : (
                                    <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 text-[10px] font-bold text-amber-400">
                                      🧑‍🏫 Faculty TBA
                                    </span>
                                  )}
                                </td>
                                <td className="py-3.5 px-4 font-mono leading-relaxed">
                                  {formatAllocationDay(alloc)}
                                  <br />
                                  {alloc.allocated_start_time.substring(0, 5)} - {alloc.allocated_end_time.substring(0, 5)}
                                </td>
                                <td className="py-3.5 px-4">
                                  <span className="text-xs text-slate-300">
                                    {alloc.allocation_reason || "Auto-allocated"}
                                  </span>
                                </td>
                                <td className="py-3.5 px-4 text-right">
                                  <div className="flex items-center justify-end gap-1.5">
                                    <button
                                      onClick={() => handleExportSingleClassPDF(alloc)}
                                      title="Export class schedule card"
                                      className="rounded-lg bg-cyan-500/10 border border-cyan-500/25 px-2 py-1 text-[9px] font-bold text-cyan-300 hover:bg-cyan-500/20 transition cursor-pointer"
                                    >
                                      📄 Class
                                    </button>
                                    {alloc.allocated_faculty_name && (
                                      <button
                                        onClick={() => handleExportFacultySchedulePDF(
                                          alloc.allocated_faculty_email || "",
                                          alloc.allocated_faculty_name
                                        )}
                                        title="Export full faculty schedule"
                                        className="rounded-lg bg-purple-500/10 border border-purple-500/25 px-2 py-1 text-[9px] font-bold text-purple-300 hover:bg-purple-500/20 transition cursor-pointer"
                                      >
                                        👨‍🏫 Faculty
                                      </button>
                                    )}
                                    {selectedBatchData.batch.status !== "Confirmed" && (
                                      <button
                                        onClick={() => handleOpenAdjust(alloc)}
                                        className="rounded-lg bg-white/5 border border-white/5 px-2 py-1 text-[9px] font-bold text-slate-300 hover:bg-white/10 transition cursor-pointer"
                                      >
                                        ✏️ Adjust
                                      </button>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {selectedBatchData.conflicts.length > 0 && (
                        <div className="flex justify-end mb-4">
                          <button
                            onClick={handleAutoResolveAll}
                            className="flex items-center gap-2 rounded-xl bg-indigo-500 hover:bg-indigo-400 px-4 py-2 text-sm font-bold text-white transition-all cursor-pointer shadow-[0_0_15px_rgba(99,102,241,0.4)]"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                            Auto-Resolve All Conflicts
                          </button>
                        </div>
                      )}
                      {selectedBatchData.conflicts.length === 0 ? (
                        <div className="text-center py-16 border border-dashed border-white/5 rounded-2xl">
                          <p className="text-slate-500 italic text-sm">No conflicts identified! All courses allocated.</p>
                        </div>
                      ) : (
                        selectedBatchData.conflicts.map((conflict: any) => (
                          <div
                            key={conflict.conflict_id}
                            className="rounded-2xl border border-rose-500/25 bg-rose-500/[0.02] p-4.5 flex flex-col md:flex-row md:items-center md:justify-between gap-4"
                          >
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2 py-0.5 text-[9px] font-bold uppercase">
                                  {conflict.conflict_type}
                                </span>
                                <h4 className="font-bold text-sm text-white">
                                  {conflict.course_code} · Section {conflict.section_number}
                                </h4>
                              </div>
                              <p className="text-xs text-rose-300 leading-relaxed mt-1">{conflict.description}</p>
                            </div>

                            {selectedBatchData.batch.status !== "Confirmed" && (
                              <button
                                onClick={() => handleOpenAdjust(conflict)}
                                className="rounded-xl bg-rose-500/10 border border-rose-500/25 px-4 py-2 text-xs font-bold text-rose-300 hover:bg-rose-500/20 transition cursor-pointer"
                              >
                                Resolve Manually
                              </button>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              /* BATCH RUN DIRECTORY */
              <div className="rounded-3xl border border-white/10 bg-slate-950/45 p-6 backdrop-blur-xl space-y-4">
                <div className="flex justify-between items-center border-b border-white/5 pb-3">
                  <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase">Allocation Batches</h3>
                  <span className="text-[10px] text-slate-500">Showing finished and draft schedule runs</span>
                </div>

                <div className="overflow-x-auto border border-white/5 rounded-2xl">
                  {batches.length === 0 ? (
                    <div className="text-center py-20 border border-dashed border-white/10 rounded-2xl">
                      <p className="text-slate-400 italic text-sm">No allocation runs found. Click "+ Create New Batch" to draft a schedule.</p>
                    </div>
                  ) : (
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-white/10 bg-slate-950/60 text-slate-400 font-bold uppercase tracking-wider text-[9px]">
                          <th className="py-3.5 px-4">Batch ID</th>
                          <th className="py-3.5 px-4">Semester</th>
                          <th className="py-3.5 px-4">Created By</th>
                          <th className="py-3.5 px-4">Success Rate</th>
                          <th className="py-3.5 px-4">Created Date</th>
                          <th className="py-3.5 px-4">Status</th>
                          <th className="py-3.5 px-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5 text-slate-300">
                        {batches.map((batch) => {
                          const successRate = Math.round((batch.successfully_allocated / batch.total_sections) * 100) || 0;
                          return (
                            <tr key={batch.batch_id} className="hover:bg-white/[0.01] transition-colors">
                              <td className="py-4 px-4 font-mono text-cyan-400">{batch.batch_id.substring(0, 8)}...</td>
                              <td className="py-4 px-4 font-bold text-white">{batch.semester}</td>
                              <td className="py-4 px-4 text-slate-300">{batch.creator_name || "System Admin"}</td>
                              <td className="py-4 px-4">
                                <div className="flex items-center gap-2">
                                  <div className="w-20 bg-slate-900 rounded-full h-1.5">
                                    <div
                                      className={`h-1.5 rounded-full ${successRate === 100 ? "bg-emerald-450" : "bg-cyan-400"}`}
                                      style={{ width: `${successRate}%` }}
                                    />
                                  </div>
                                  <span className="font-bold text-slate-200">{successRate}% ({batch.successfully_allocated}/{batch.total_sections})</span>
                                </div>
                              </td>
                              <td className="py-4 px-4 text-slate-400">{new Date(batch.created_at).toLocaleString()}</td>
                              <td className="py-4 px-4">
                                <span className={`rounded-full px-2.5 py-0.5 text-[9px] uppercase font-bold border ${batch.status === "Confirmed"
                                  ? "bg-emerald-400/10 text-emerald-300 border-emerald-400/20"
                                  : "bg-amber-400/10 text-amber-300 border-amber-400/20"
                                  }`}>
                                  {batch.status}
                                </span>
                              </td>
                              <td className="py-4 px-4 text-right">
                                <div className="flex justify-end gap-2">
                                  <button
                                    onClick={() => fetchBatchDetails(batch.batch_id)}
                                    className="rounded-lg bg-cyan-400 px-3.5 py-1.5 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer"
                                  >
                                    View Details
                                  </button>
                                  <button
                                    onClick={() => handleDeleteBatch(batch.batch_id)}
                                    className="rounded-lg bg-rose-500/10 border border-rose-500/25 px-3 py-1.5 text-xs font-bold text-rose-400 hover:bg-rose-500/20 transition cursor-pointer"
                                    title="Delete Batch"
                                  >
                                    🗑️
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>
            )}
          </section>
        )}

        {/* MODAL: ONE-TIME / RECURRING BOOKING FORM */}
        {bookingRoom && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-sm">
            <div className="relative w-full max-w-xl rounded-3xl border border-white/10 bg-slate-950 p-6 shadow-2xl space-y-5">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-bold text-white">Create Booking Reservation</h3>
                  <p className="text-xs text-slate-400">Target: {bookingRoom.room_number} ({bookingRoom.capacity} seats, {bookingRoom.room_type})</p>
                </div>
                <button
                  onClick={() => {
                    setBookingRoom(null);
                    setRecurConflicts(null);
                  }}
                  className="text-slate-400 hover:text-white text-lg font-semibold cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {recurConflicts ? (
                /* RECURRING CONFLICT CHOICE PANEL */
                <div className="space-y-4 rounded-2xl border border-amber-400/25 bg-amber-400/[0.03] p-4 text-xs">
                  <h4 className="text-sm font-bold text-amber-300 flex items-center gap-1.5">
                    <span>⚠️ Partial Booking Conflict Detected</span>
                  </h4>
                  <p className="text-slate-300 leading-relaxed">
                    The requested recurring series contains <strong>{recurConflicts.conflictCount}</strong> conflicting slots out of {recurConflicts.instances.length} generated classes. Choose how to proceed:
                  </p>

                  <div className="space-y-2 border-y border-white/10 py-3 max-h-[160px] overflow-y-auto">
                    {recurConflicts.instances.map((inst: any, idx: number) => (
                      <div key={idx} className="flex justify-between leading-relaxed text-slate-400">
                        <span>Instance {idx + 1}: {new Date(inst.startDt).toLocaleDateString()} {new Date(inst.startDt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}</span>
                        {inst.hasConflict ? (
                          <span className="text-rose-400 font-bold">{inst.reason}</span>
                        ) : (
                          <span className="text-emerald-400 font-bold">Available</span>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2 pt-2">
                    <button
                      onClick={() => submitBooking("skip")}
                      className="flex-1 rounded-xl bg-amber-400 py-3 text-xs font-bold text-slate-950 hover:bg-amber-300 transition cursor-pointer"
                    >
                      Skip Conflicts & Book Available
                    </button>
                    <button
                      onClick={() => {
                        setBookingRoom(null);
                        setRecurConflicts(null);
                      }}
                      className="flex-1 rounded-xl border border-white/10 bg-white/5 py-3 text-xs font-bold text-white hover:bg-white/10 transition cursor-pointer"
                    >
                      Cancel Entire Series Request
                    </button>
                  </div>
                </div>
              ) : (
                /* DRAFT BOOKING REQUEST FORM */
                <div className="space-y-4">
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Course Code</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. CSE-299"
                        value={courseCode}
                        onChange={(e) => setCourseCode(e.target.value)}
                        className="mt-1.5 w-full rounded-xl border border-white/10 bg-slate-900 px-4 py-3 text-sm text-slate-200 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Course Name</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Junior Design Classroom"
                        value={courseName}
                        onChange={(e) => setCourseName(e.target.value)}
                        className="mt-1.5 w-full rounded-xl border border-white/10 bg-slate-900 px-4 py-3 text-sm text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Class Size Size</label>
                      <input
                        type="number"
                        required
                        placeholder="e.g. 35"
                        value={classSize}
                        onChange={(e) => setClassSize(e.target.value)}
                        className="mt-1.5 w-full rounded-xl border border-white/10 bg-slate-900 px-4 py-3 text-sm text-slate-200 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Booking Type</label>
                      <div className="mt-1.5 flex gap-2">
                        <button
                          type="button"
                          onClick={() => setBookingType("OneTime")}
                          className={`flex-1 rounded-xl py-2 text-xs font-bold transition ${bookingType === "OneTime" ? "bg-cyan-400 text-slate-950" : "border border-white/5 bg-white/5 text-white"
                            }`}
                        >
                          One-Time
                        </button>
                        <button
                          type="button"
                          onClick={() => setBookingType("Recurring")}
                          className={`flex-1 rounded-xl py-2 text-xs font-bold transition ${bookingType === "Recurring" ? "bg-cyan-400 text-slate-950" : "border border-white/5 bg-white/5 text-white"
                            }`}
                        >
                          Recurring Series
                        </button>
                      </div>
                    </div>
                  </div>

                  {bookingType === "OneTime" ? (
                    <div className="rounded-xl border border-white/5 bg-slate-900/40 p-4 text-xs space-y-1">
                      <p className="font-bold text-slate-300">Selected Schedule:</p>
                      <p className="text-cyan-400 font-mono">
                        Date: {searchDate} | {searchStartTime} to {searchEndTime}
                      </p>
                    </div>
                  ) : (
                    /* RECURRING OPTIONS */
                    <div className="rounded-xl border border-white/5 bg-slate-900/40 p-4 space-y-3.5 text-xs">
                      <div className="flex gap-2">
                        <div className="w-1/2">
                          <label className="text-[10px] font-bold text-slate-400 uppercase">Frequency</label>
                          <select
                            value={pattern}
                            onChange={(e) => setPattern(e.target.value as any)}
                            className="mt-1 w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-xs text-slate-200 outline-none"
                          >
                            <option value="Weekly">Weekly</option>
                            <option value="BiWeekly">Bi-Weekly</option>
                          </select>
                        </div>
                        <div className="w-1/2">
                          <label className="text-[10px] font-bold text-slate-400 uppercase">Days of Week</label>
                          <div className="mt-2 flex gap-1 flex-wrap">
                            {[
                              { label: "M", val: 1 },
                              { label: "T", val: 2 },
                              { label: "W", val: 3 },
                              { label: "T", val: 4 },
                              { label: "F", val: 5 },
                            ].map((day) => (
                              <button
                                key={day.val}
                                type="button"
                                onClick={() => handleDayOfWeekToggle(day.val)}
                                className={`h-6 w-6 rounded-md font-bold text-[10px] transition ${daysOfWeek.includes(day.val) ? "bg-cyan-400 text-slate-950" : "bg-slate-950 text-slate-300 border border-white/10"
                                  }`}
                              >
                                {day.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <div className="w-1/2">
                          <label className="text-[10px] font-bold text-slate-400 uppercase">Start Date</label>
                          <input
                            type="date"
                            required
                            value={recurStartDate}
                            onChange={(e) => setRecurStartDate(e.target.value)}
                            onClick={(e) => e.currentTarget.showPicker?.()}
                            className="mt-1 w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-xs text-slate-200 outline-none cursor-pointer"
                          />
                        </div>
                        <div className="w-1/2">
                          <label className="text-[10px] font-bold text-slate-400 uppercase">End Date</label>
                          <input
                            type="date"
                            required
                            value={recurEndDate}
                            onChange={(e) => setRecurEndDate(e.target.value)}
                            onClick={(e) => e.currentTarget.showPicker?.()}
                            className="mt-1 w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-xs text-slate-200 outline-none cursor-pointer"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {bookingType === "Recurring" && (() => {
                    if (!recurStartDate || !recurEndDate) return null;
                    const startD = new Date(recurStartDate);
                    const endD = new Date(recurEndDate);
                    if (startD > endD) return null;
                    
                    const dates = [];
                    const current = new Date(startD);
                    while (current <= endD) {
                      const day = current.getDay();
                      if (daysOfWeek.includes(day)) {
                        const diffTime = Math.abs(current.getTime() - startD.getTime());
                        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
                        const weekNum = Math.floor(diffDays / 7);
                        if (pattern === 'BiWeekly' && weekNum % 2 !== 0) {
                          current.setDate(current.getDate() + 1);
                          continue;
                        }
                        dates.push(new Date(current));
                      }
                      current.setDate(current.getDate() + 1);
                    }
                    return dates.length > 0 ? (
                      <div className="mt-3 rounded-xl border border-cyan-400/20 bg-cyan-400/5 p-3">
                        <p className="text-[10px] font-bold text-cyan-300 uppercase mb-2">Preview Instances ({dates.length})</p>
                        <div className="max-h-24 overflow-y-auto custom-scrollbar flex flex-col gap-1 text-[10px] text-slate-300 font-mono">
                          {dates.map((d, i) => (
                            <span key={i}>Instance {i + 1}: {d.toLocaleDateString()} {searchStartTime} - {searchEndTime}</span>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="mt-3 rounded-xl border border-rose-400/20 bg-rose-400/5 p-3 text-[10px] text-rose-300">
                        No dates matched your selected pattern.
                      </div>
                    );
                  })()}

                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Special Notes (access needs, etc.)</label>
                    <textarea
                      placeholder="Special instructions or equipments request..."
                      rows={2}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="mt-1.5 w-full rounded-xl border border-white/10 bg-slate-900 px-4 py-3 text-sm text-slate-200 outline-none"
                    />
                  </div>

                  {bookingError && (
                    <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-200 font-medium">
                      <span className="font-bold text-rose-400 mr-1">⚠️ Error:</span>
                      {bookingError}
                    </div>
                  )}

                  <div className="flex gap-3 pt-2">
                    <button
                      onClick={() => submitBooking(undefined, true)}
                      className="w-1/3 rounded-xl border border-white/10 bg-slate-900 py-3 text-xs font-bold text-white hover:bg-slate-800 transition cursor-pointer"
                    >
                      Save as Draft
                    </button>
                    <button
                      onClick={() => submitBooking()}
                      className="w-2/3 rounded-xl bg-cyan-400 py-3 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer"
                    >
                      Submit Reservation
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {editingBooking && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-sm">
            <div className="relative w-full max-w-md rounded-3xl border border-white/10 bg-slate-950 p-6 shadow-2xl space-y-5">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-bold text-white">Modify Booking Request</h3>
                  <p className="text-xs text-slate-400">ID: {editingBooking.booking_request_id}</p>
                </div>
                <button
                  onClick={() => setEditingBooking(null)}
                  className="text-slate-400 hover:text-white text-lg font-semibold cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleModifyBooking} className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Class Size</label>
                  <input
                    type="number"
                    required
                    value={editClassSize}
                    onChange={(e) => setEditClassSize(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-slate-900 px-4 py-3 text-sm text-slate-200 outline-none"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Special Notes</label>
                  <textarea
                    rows={3}
                    value={editNotes}
                    onChange={(e) => setEditNotes(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-slate-900 px-4 py-3 text-sm text-slate-200 outline-none"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingBooking(null)}
                    className="w-1/3 rounded-xl border border-white/10 bg-white/5 py-3 text-xs font-bold text-white hover:bg-white/10 transition cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="w-2/3 rounded-xl bg-cyan-400 py-3 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* MODAL: ADJUST ALLOCATION / RESOLVE CONFLICT */}
        {adjustingItem && (() => {
          const CLASS_SLOTS = [
            { start: "08:00", end: "09:30" },
            { start: "09:40", end: "11:10" },
            { start: "11:20", end: "12:50" },
            { start: "13:00", end: "14:30" },
            { start: "14:40", end: "16:10" },
            { start: "16:20", end: "17:50" },
            { start: "18:00", end: "19:30" },
            { start: "19:40", end: "21:10" },
          ];
          const isSlotOccupied = (slot: typeof CLASS_SLOTS[0]) => {
            if (!selectedBatchData || !selectedBatchData.allocations) return null;
            const match = selectedBatchData.allocations.find((a: any) => {
              if (adjustingItem && a.allocation_id === adjustingItem.allocation_id) return false;
              const sameRoom = a.room_id === adjustRoomId;
              const sameDay = a.allocated_day_of_week === adjustDayOfWeek;
              if (sameRoom && sameDay) {
                const aStart = a.allocated_start_time.substring(0, 5);
                const aEnd = a.allocated_end_time.substring(0, 5);
                return slot.start < aEnd && slot.end > aStart;
              }
              return false;
            });
            return match ? `${match.course_code} Sec ${match.section_number}` : null;
          };

          const selectedSlotIndex = CLASS_SLOTS.findIndex(s => s.start === adjustStartTime && s.end === adjustEndTime);

          return (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-sm">
              <div className="relative w-full max-w-lg rounded-3xl border border-white/10 bg-slate-950 p-6 shadow-2xl space-y-5">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-white">
                      {adjustingItem.allocation_id ? "Adjust Assigned Classroom Slot" : "Resolve Conflict Manually"}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Course: {adjustingItem.course_code} · Section {adjustingItem.section_number} (Enrollment: {adjustingItem.enrollment_size || adjustingItem.enrollment})
                    </p>
                  </div>
                  <button
                    onClick={() => setAdjustingItem(null)}
                    className="text-slate-400 hover:text-white text-lg font-semibold cursor-pointer"
                  >
                    ✕
                  </button>
                </div>

                {adjustingItem.description && (
                  <div className="rounded-xl border border-rose-500/25 bg-rose-500/[0.03] p-4 text-xs text-rose-300 leading-relaxed">
                    <p className="font-bold">Original Conflict reason:</p>
                    <p className="mt-1">{adjustingItem.description}</p>
                  </div>
                )}

                <form onSubmit={handleSaveAdjust} className="space-y-4 text-xs">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Assign Classroom</label>
                    <select
                      required
                      value={adjustRoomId}
                      onChange={(e) => {
                        const newRoomId = e.target.value;
                        setAdjustRoomId(newRoomId);
                        // Auto-select first available slot for new room
                        const firstAvailable = CLASS_SLOTS.find(slot => {
                          const conflict = (selectedBatchData?.allocations || []).find((a: any) => {
                            if (adjustingItem && a.allocation_id === adjustingItem.allocation_id) return false;
                            if (a.room_id !== newRoomId) return false;
                            if (a.allocated_day_of_week !== adjustDayOfWeek) return false;
                            const aStart = (a.allocated_start_time || '').substring(0, 5);
                            const aEnd = (a.allocated_end_time || '').substring(0, 5);
                            return slot.start < aEnd && slot.end > aStart;
                          });
                          return !conflict;
                        }) || CLASS_SLOTS[0];
                        setAdjustStartTime(firstAvailable.start);
                        setAdjustEndTime(firstAvailable.end);
                      }}
                      className="w-full rounded-xl border border-white/10 bg-slate-900 px-4 py-3 text-slate-200 outline-none"
                    >
                      {rooms.map((r) => (
                        <option key={r.room_id} value={r.room_id}>
                          {r.room_number} (Cap: {r.capacity} seats, {r.room_type})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Faculty Assignment */}
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                      Assign Faculty <span className="text-slate-600 normal-case font-normal">(optional — leave blank for TBA)</span>
                    </label>
                    <select
                      value={adjustFacultyId}
                      onChange={(e) => setAdjustFacultyId(e.target.value)}
                      className="w-full rounded-xl border border-white/10 bg-slate-900 px-4 py-3 text-slate-200 outline-none"
                    >
                      <option value="">— Unassigned (TBA) —</option>
                      {adminFaculties.filter((f: any) => f.status === "Active").map((f: any) => (
                        <option key={f.faculty_id} value={f.faculty_id}>
                          {f.full_name_en} ({f.designation})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid gap-3 grid-cols-2">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Day of Week</label>
                      <select
                        value={adjustDayOfWeek}
                        onChange={(e) => {
                          const newDay = parseInt(e.target.value, 10);
                          setAdjustDayOfWeek(newDay);
                          // Auto-select first available slot for new day
                          const firstAvailable = CLASS_SLOTS.find(slot => {
                            const conflict = (selectedBatchData?.allocations || []).find((a: any) => {
                              if (adjustingItem && a.allocation_id === adjustingItem.allocation_id) return false;
                              if (a.room_id !== adjustRoomId) return false;
                              if (a.allocated_day_of_week !== newDay) return false;
                              const aStart = (a.allocated_start_time || '').substring(0, 5);
                              const aEnd = (a.allocated_end_time || '').substring(0, 5);
                              return slot.start < aEnd && slot.end > aStart;
                            });
                            return !conflict;
                          }) || CLASS_SLOTS[0];
                          setAdjustStartTime(firstAvailable.start);
                          setAdjustEndTime(firstAvailable.end);
                        }}
                        className="w-full rounded-xl border border-white/10 bg-slate-900 px-4 py-3 text-slate-200 outline-none"
                      >
                        {adjustingItem && (adjustingItem.facility_type === 'Lab' || adjustingItem.course_code?.endsWith('L')) ? (
                          <>
                            <option value={0}>Sunday</option>
                            <option value={1}>Monday</option>
                            <option value={2}>Tuesday</option>
                            <option value={3}>Wednesday</option>
                            <option value={4}>Thursday</option>
                            <option value={6}>Saturday</option>
                          </>
                        ) : (
                          <>
                            <option value={0}>ST (Sunday & Tuesday)</option>
                            <option value={1}>MW (Monday & Wednesday)</option>
                            <option value={4}>RA (Thursday & Saturday)</option>
                          </>
                        )}
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Time Slot Interval (1.5h + 10m gap)</label>
                      <select
                        value={selectedSlotIndex >= 0 ? selectedSlotIndex : 0}
                        onChange={(e) => {
                          const idx = parseInt(e.target.value, 10);
                          const slot = CLASS_SLOTS[idx];
                          if (slot) {
                            setAdjustStartTime(slot.start);
                            setAdjustEndTime(slot.end);
                          }
                        }}
                        className="w-full rounded-xl border border-white/10 bg-slate-900 px-4 py-3 text-slate-200 outline-none"
                      >
                        {CLASS_SLOTS.map((slot, idx) => {
                          const occupiedBy = isSlotOccupied(slot);
                          return (
                            <option 
                              key={idx} 
                              value={idx} 
                              disabled={!!occupiedBy}
                            >
                              Slot {idx + 1}: {slot.start} - {slot.end} {occupiedBy ? `(Occupied - ${occupiedBy})` : "(Available)"}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                  </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="submit"
                    className="flex-1 rounded-xl bg-cyan-400 py-3 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer"
                  >
                    Save & Apply Override
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustingItem(null)}
                    className="flex-1 rounded-xl border border-white/10 bg-white/5 py-3 text-xs font-bold text-white hover:bg-white/10 transition cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
          );
        })()}

        {/* ROOM ISSUE REPORT MODAL */}
        {selectedIssueBooking && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/60 backdrop-blur-md p-4">
            <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-slate-950 p-6 shadow-2xl space-y-6 animate-in fade-in zoom-in duration-200">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  ⚠️ Report Classroom Issue
                </h3>
                <button
                  onClick={() => setSelectedIssueBooking(null)}
                  className="text-slate-400 hover:text-white transition font-bold text-lg"
                >
                  ✕
                </button>
              </div>

              <div>
                <p className="text-xs text-slate-300">
                  Filing an issue for <strong>Room {selectedIssueBooking.room_number}</strong> ({selectedIssueBooking.course_code} - {selectedIssueBooking.course_name}). This will notify the registrar administrators immediately.
                </p>
              </div>

              <form onSubmit={handleReportIssue} className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Issue Category
                  </label>
                  <select
                    value={issueType}
                    onChange={(e) => setIssueType(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-slate-900 px-3.5 py-2.5 text-sm text-slate-200 outline-none"
                  >
                    <option value="Projector / Display Issue">Projector / Display Issue</option>
                    <option value="Air Conditioning">Air Conditioning / Cooling Issue</option>
                    <option value="Room Cleanliness">Room Cleanliness / Maintenance</option>
                    <option value="Missing Markers / Whiteboard">Missing Markers / Whiteboard</option>
                    <option value="Electricity / Light Bulbs">Electricity / Light Bulbs</option>
                    <option value="Other Technical Issue">Other Technical Issue</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Describe the Problem
                  </label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Provide details about the issue (e.g. Projector power cord is missing, AC remote is not working...)"
                    value={issueDescription}
                    onChange={(e) => setIssueDescription(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-slate-900 px-3.5 py-2.5 text-sm text-slate-200 outline-none resize-none"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="submit"
                    className="flex-1 rounded-xl bg-cyan-400 py-3 text-xs font-bold text-slate-950 hover:bg-cyan-300 transition cursor-pointer"
                  >
                    Submit Issue Report
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedIssueBooking(null)}
                    className="flex-1 rounded-xl border border-white/10 bg-white/5 py-3 text-xs font-bold text-white hover:bg-white/10 transition cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
