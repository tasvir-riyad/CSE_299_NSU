"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";

function LobbyContent() {
  const searchParams = useSearchParams();
  const building = searchParams.get("building") || "";
  const backendBaseUrl = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:5001";
  
  const [bookings, setBookings] = useState<any[]>([]);
  const [currentTime, setCurrentTime] = useState(new Date());

  const fetchBookings = async () => {
    try {
      const url = building 
        ? `${backendBaseUrl}/api/bookings/lobby?building=${building}`
        : `${backendBaseUrl}/api/bookings/lobby`;
      const res = await fetch(url);
      const data = await res.json();
      if (Array.isArray(data)) {
        setBookings(data);
      } else {
        console.error("Lobby API returned non-array:", data);
        setBookings([]);
      }
    } catch (e) {
      console.error("Failed to fetch lobby bookings:", e);
    }
  };

  useEffect(() => {
    fetchBookings();
    
    // Auto-refresh data every 60 seconds
    const intervalData = setInterval(() => {
      fetchBookings();
    }, 60000);

    // Update clock every second
    const intervalClock = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => {
      clearInterval(intervalData);
      clearInterval(intervalClock);
    };
  }, [building]);

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans overflow-hidden flex flex-col">
      {/* Header */}
      <header className="bg-slate-900 border-b border-white/10 p-6 flex justify-between items-center shrink-0">
        <div>
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-emerald-400 uppercase tracking-wider">
            {building ? `${building} Building Lobby` : "Campus Lobby Display"}
          </h1>
          <p className="text-lg text-slate-400 mt-2 font-medium tracking-widest">TODAY'S SCHEDULE</p>
        </div>
        <div className="text-right">
          <div className="text-6xl font-black text-white font-mono tracking-tighter shadow-cyan-500/20 drop-shadow-2xl">
            {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
          <div className="text-xl text-cyan-400 font-bold uppercase mt-2">
            {currentTime.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-8 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 to-slate-950">
        {bookings.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <p className="text-3xl text-slate-500 font-bold animate-pulse">No scheduled classes for today.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6">
            <div className="grid grid-cols-5 text-xl font-black text-slate-400 uppercase tracking-widest border-b border-white/10 pb-4 mb-4 px-6">
              <div>Time</div>
              <div>Room</div>
              <div className="col-span-2">Course Name</div>
              <div className="text-right">Faculty</div>
            </div>
            
            <div className="space-y-4">
              {bookings.map((b, idx) => {
                const startTime = new Date(b.start_dt);
                const endTime = new Date(b.end_dt);
                
                // Highlight classes that are currently active
                const isActive = currentTime >= startTime && currentTime <= endTime;
                // Highlight classes that are starting very soon (within 15 mins)
                const isStartingSoon = !isActive && startTime.getTime() - currentTime.getTime() > 0 && startTime.getTime() - currentTime.getTime() <= 15 * 60000;

                let cardClass = "bg-slate-900/50 border-white/5";
                let badge = null;
                
                if (isActive) {
                  cardClass = "bg-emerald-950/40 border-emerald-500/50 shadow-[0_0_30px_rgba(16,185,129,0.1)]";
                  badge = <span className="ml-4 text-xs font-bold bg-emerald-500/20 text-emerald-400 px-3 py-1 rounded-full animate-pulse border border-emerald-500/30">IN PROGRESS</span>;
                } else if (isStartingSoon) {
                  cardClass = "bg-amber-950/40 border-amber-500/50 shadow-[0_0_30px_rgba(245,158,11,0.1)]";
                  badge = <span className="ml-4 text-xs font-bold bg-amber-500/20 text-amber-400 px-3 py-1 rounded-full animate-pulse border border-amber-500/30">STARTING SOON</span>;
                }

                return (
                  <div key={`${b.booking_id}-${idx}`} className={`grid grid-cols-5 items-center p-6 rounded-2xl border backdrop-blur-sm transition-all ${cardClass}`}>
                    <div className="text-3xl font-bold font-mono tracking-tighter text-white">
                      {startTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                    <div className="text-4xl font-black text-cyan-400 tracking-tighter flex items-center">
                      {!building && <span className="text-lg text-slate-500 mr-2">{b.building_code}</span>}
                      {b.room_number}
                    </div>
                    <div className="col-span-2">
                      <div className="text-2xl font-bold text-white flex items-center">
                        {b.course_code}
                        {badge}
                      </div>
                      <div className="text-lg text-slate-400 font-medium truncate">{b.course_name}</div>
                    </div>
                    <div className="text-right text-2xl font-bold text-slate-300">
                      {b.faculty_name}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>
      
      {/* Footer ticker */}
      <footer className="bg-cyan-950/30 border-t border-cyan-500/20 p-3 shrink-0 overflow-hidden">
        <div className="text-sm font-bold text-cyan-400 uppercase tracking-widest whitespace-nowrap animate-[marquee_20s_linear_infinite]">
          CLASSROOM BOOKING SYSTEM • AUTO-REFRESHING EVERY 60 SECONDS • PLEASE PROCEED TO YOUR ASSIGNED ROOM 5 MINUTES BEFORE START TIME
        </div>
      </footer>
      
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes marquee {
          0% { transform: translateX(100%); }
          100% { transform: translateX(-100%); }
        }
      `}} />
    </div>
  );
}

export default function LobbyScreen() {
  return (
    <Suspense fallback={<div>Loading lobby...</div>}>
      <LobbyContent />
    </Suspense>
  )
}
