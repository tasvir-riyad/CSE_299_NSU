'use client';

import React from 'react';

interface NavLink {
  href: string;
  label: string;
  icon?: React.ReactNode;
  active?: boolean;
}

interface HeaderProps {
  title?: string;
  subtitle?: string;
  user?: {
    name: string;
    email: string;
    role: string;
  };
  navLinks?: NavLink[];
  onNavClick?: (href: string) => void;
}

export function Header({ title, subtitle, user, navLinks, onNavClick }: HeaderProps) {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Bar */}
        <div className="flex items-center justify-between py-4">
          <div>
            {title && (
              <>
                <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
                {subtitle && <p className="text-sm text-gray-500 mt-1">{subtitle}</p>}
              </>
            )}
          </div>

          {/* User Info */}
          {user && (
            <div className="flex items-center space-x-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-semibold text-gray-900">{user.name}</p>
                <p className="text-xs text-gray-500">{user.role}</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold text-sm">{user.name.charAt(0)}</span>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        {navLinks && navLinks.length > 0 && (
          <nav className="flex space-x-1 border-t border-gray-100">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => onNavClick?.(link.href)}
                className={`
                  px-4 py-3 text-sm font-medium transition-colors border-b-2 -mb-px
                  ${
                    link.active
                      ? 'text-blue-600 border-blue-600'
                      : 'text-gray-600 border-transparent hover:text-gray-900'
                  }
                `}
              >
                <span className="flex items-center space-x-2">
                  {link.icon && <span>{link.icon}</span>}
                  <span>{link.label}</span>
                </span>
              </button>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}

export default Header;
