import re

file_path = "/Users/tawhid/Desktop/CSE299/Frontend/classroom_booking_system/app/page.tsx"
with open(file_path, "r") as f:
    content = f.read()

# 1. Add 'faculty' to the adminSubTab state type if it's strictly typed. Wait, in page.tsx:
# const [adminSubTab, setAdminSubTab] = useState("dashboard"); // dashboard, inventory

# 2. Add Faculty Creation State variables right after adminSubTab
state_injection = """
  // Faculty Creation State
  const [facultyForm, setFacultyForm] = useState({
    employee_id: "", full_name_en: "", full_name_bn: "", email: "", username: "",
    designation: "Lecturer", seniority_rank: 4, joining_date: "", dept_head_flag: false
  });
  const [facultyCreationStatus, setFacultyCreationStatus] = useState("");
  
  const handleFacultyCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFacultyCreationStatus("Creating...");
    try {
      const res = await fetch("http://localhost:5001/api/admin/faculty", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(facultyForm)
      });
      const data = await res.json();
      if (data.error) {
        setFacultyCreationStatus(`Error: ${data.error}`);
      } else {
        setFacultyCreationStatus("Successfully created faculty profile!");
        setFacultyForm({
          employee_id: "", full_name_en: "", full_name_bn: "", email: "", username: "",
          designation: "Lecturer", seniority_rank: 4, joining_date: "", dept_head_flag: false
        });
        setTimeout(() => setFacultyCreationStatus(""), 3000);
      }
    } catch (err: any) {
      setFacultyCreationStatus(`Error: ${err.message}`);
    }
  };
"""

content = content.replace(
    'const [adminSubTab, setAdminSubTab] = useState("dashboard");', 
    'const [adminSubTab, setAdminSubTab] = useState("dashboard");' + state_injection
)

# 3. Add the Tab button in the UI
tab_injection = """
              <button
                onClick={() => setAdminSubTab("faculty")}
                className={`pb-3 text-sm font-bold transition cursor-pointer relative ${adminSubTab === "faculty" ? "text-cyan-400 font-extrabold" : "text-slate-400 hover:text-white"}`}
              >
                Faculty Profiles
                {adminSubTab === "faculty" && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400" />}
              </button>
"""

content = content.replace(
    '{adminSubTab === "inventory" && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400" />}\n              </button>',
    '{adminSubTab === "inventory" && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400" />}\n              </button>' + tab_injection
)


# 4. Add the Faculty Management Panel
panel_injection = """
            {adminSubTab === "faculty" && (
              <div className="space-y-6">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm">
                  <h3 className="text-sm font-bold tracking-wider text-cyan-400 uppercase border-b border-white/10 pb-3 mb-4">Create New Faculty Profile</h3>
                  
                  {facultyCreationStatus && (
                    <div className={`mb-4 p-3 rounded-lg text-xs font-bold ${facultyCreationStatus.includes('Error') ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'}`}>
                      {facultyCreationStatus}
                    </div>
                  )}

                  <form onSubmit={handleFacultyCreate} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Employee ID</label>
                        <input type="text" required value={facultyForm.employee_id} onChange={e => setFacultyForm({...facultyForm, employee_id: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Username</label>
                        <input type="text" required value={facultyForm.username} onChange={e => setFacultyForm({...facultyForm, username: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Full Name (English)</label>
                        <input type="text" required value={facultyForm.full_name_en} onChange={e => setFacultyForm({...facultyForm, full_name_en: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Full Name (Bengali)</label>
                        <input type="text" value={facultyForm.full_name_bn} onChange={e => setFacultyForm({...facultyForm, full_name_bn: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div className="col-span-2">
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Email Address</label>
                        <input type="email" required value={facultyForm.email} onChange={e => setFacultyForm({...facultyForm, email: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Designation</label>
                        <select value={facultyForm.designation} onChange={e => setFacultyForm({...facultyForm, designation: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50">
                          <option value="Professor">Professor</option>
                          <option value="AssociateProfessor">Associate Professor</option>
                          <option value="AssistantProfessor">Assistant Professor</option>
                          <option value="Lecturer">Lecturer</option>
                          <option value="Adjunct">Adjunct</option>
                          <option value="Visiting">Visiting</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Seniority Rank (1=Highest, 4=Lowest)</label>
                        <input type="number" min="1" max="4" required value={facultyForm.seniority_rank} onChange={e => setFacultyForm({...facultyForm, seniority_rank: parseInt(e.target.value)})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase mb-1">Joining Date (Optional)</label>
                        <input type="date" value={facultyForm.joining_date} onChange={e => setFacultyForm({...facultyForm, joining_date: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-sm text-slate-400 outline-none focus:border-cyan-400/50" />
                      </div>
                      <div className="flex items-center gap-2 pt-6">
                        <input type="checkbox" id="deptHead" checked={facultyForm.dept_head_flag} onChange={e => setFacultyForm({...facultyForm, dept_head_flag: e.target.checked})} className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-cyan-400" />
                        <label htmlFor="deptHead" className="text-xs font-bold text-slate-300">Is Department Head?</label>
                      </div>
                    </div>
                    <div className="pt-4 border-t border-white/10 flex justify-end">
                      <button type="submit" className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-2 px-6 rounded-xl shadow-lg shadow-cyan-500/20 transition cursor-pointer">
                        Create Faculty Profile
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
"""

content = content.replace(
    '{adminSubTab === "inventory" && (',
    panel_injection + '\n            {adminSubTab === "inventory" && ('
)

with open(file_path, "w") as f:
    f.write(content)

print("Faculty UI Injection complete!")
