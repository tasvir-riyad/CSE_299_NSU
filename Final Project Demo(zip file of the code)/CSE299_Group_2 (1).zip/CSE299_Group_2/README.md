# University Classroom Booking System (CBS)

The Classroom Booking System is a full-stack, enterprise-grade solution designed to manage physical classroom inventory, faculty preferences, waitlists, and bulk semester allocations for a university.

## 📁 Repository Structure

This repository is structured as a monorepo for ease of development:

- `Frontend/`: The Next.js 14 (App Router) user interface.
- `Backend/`: The Node.js/Express backend server, containing the core PostgreSQL database logic and the Allocation Engine.
- `docs/`: All setup guides, API documentation, and architecture overviews.
- `data/seeds/`: CSV files containing demo data for testing bulk imports.



## 🚀 Quick Start (Guide)

Follow these exact steps to run the complete project locally:

**Prerequisites:** Ensure you have **Node.js** and **PostgreSQL** installed and running on your machine.

### Step 1: Install All Dependencies
From the root directory of the project, run:
```bash
npm run install:all
```

### Step 2: Database Configuration
1. Create a new PostgreSQL database (e.g., named `cbs_db`).
2. Navigate into the `Backend/` directory and create a file named `.env`. Add the following lines, replacing the `<placeholders>` with your actual PostgreSQL credentials:
```env
PORT=5001
DATABASE_URL=postgres://<username>:<password>@localhost:5432/cbs_db
```
3. Initialize the database schema. You can run this command from the root directory (adjusting your username/db name):
```bash
psql -U <username> -d cbs_db -f Backend/schema.sql
```

### Step 3: Seed Demo Data
To test the system, you need data (classrooms, admin accounts, calendar events). From the root directory, run:
```bash
cd Backend
npm run seed
cd ..
```

### Step 4: Start the Development Servers
From the root directory, launch both the Frontend and Backend simultaneously:
```bash
npm run dev
```
*(This will launch the Backend API on `http://localhost:5001` and the Frontend UI on `http://localhost:3000`)*

### Step 5: System Login
Open your browser and navigate to `http://localhost:3000`. You can log in using the seeded Admin credentials:
- **Email:** `admin@university.edu`
- **Password:** `admin123`

## 📚 Documentation

Detailed guides are available in the `docs/` folder:

- **[System Overview & Workflow](docs/system_overview.md)**
- **[Local Testing Guide](docs/LOCAL_TESTING_GUIDE.md)**
- **[Neon & Vercel Deployment](docs/neon_vercel_deployment_guide.md)**
